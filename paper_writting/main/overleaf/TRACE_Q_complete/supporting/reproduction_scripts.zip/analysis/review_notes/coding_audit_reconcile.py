#!/usr/bin/env python3
"""Rebuild the full-note LLM audit and reconciled categories from saved decisions.

This script records semantic decisions already made by the two LLM agents. It
does not infer categories from words, titles, or a rule-based text classifier.
"""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RECONCILIATION = {
    2: {
        "final": "TEST_INFERENCE",
        "resolution": "Both agents agreed to classify a bound-to-noninferiority-margin explanation as inferential reasoning. The conclusion remains correct. DIRECTION is restricted to signed contrasts, trends, residuals, and benefit/harm interpretation rather than all inequality wording.",
    },
    33: {
        "final": "INTERVAL_DISPERSION",
        "resolution": "Both agents agreed that interval coherence is the common mechanism across the difference and HR portions of the note. A distinct CI/P conflict remains. The primary choice is explicitly ambiguous because the candidate bundles independent uncertainty and inference concerns.",
    },
    98: {
        "final": "ATTRIBUTION",
        "resolution": "Both agents agreed that the fasting-glucose interval repeating the identified hsCRP interval satisfies the specific source-to-destination attribution rule. This describes the note's mapping without claiming that a copying operation was independently verified. The second broad width allegation is explicitly rejected in the note.",
    },
    104: {
        "final": "EFFECT_ESTIMAND",
        "resolution": "The audit agent accepted the provisional EFFECT_ESTIMAND category after clarifying that a transformed effect/contrast mislabeled as percent change is effect-scale identity. ANALYSIS_DEFINITION covers questionnaire scores, general units, and summary-statistic identity, not an effect's log-to-percent transformation.",
    },
}
AMBIGUOUS = {
    22: ["TEST_INFERENCE", "DIRECTION"],
    33: ["INTERVAL_DISPERSION", "TEST_INFERENCE"],
    115: ["ANALYSIS_DEFINITION", "ATTRIBUTION"],
}
SECONDARY = {
    3: ["EFFECT_ESTIMAND"], 22: ["DIRECTION", "INTERVAL_DISPERSION"],
    26: ["INTERVAL_DISPERSION"], 33: ["TEST_INFERENCE"],
    54: ["TEST_INFERENCE", "INTERVAL_DISPERSION"], 55: ["EFFECT_ESTIMAND"],
    56: ["EFFECT_ESTIMAND"], 86: ["ATTRIBUTION"],
    90: ["EFFECT_ESTIMAND"], 91: ["DIRECTION"], 95: ["ATTRIBUTION"],
    102: ["INTERVAL_DISPERSION"], 104: ["INTERVAL_DISPERSION"],
    106: ["DIRECTION", "ATTRIBUTION"], 109: ["TEST_INFERENCE"],
    112: ["ATTRIBUTION"], 115: ["ATTRIBUTION"],
    117: ["EFFECT_ESTIMAND"], 121: ["ANALYSIS_DEFINITION"],
    122: ["ANALYSIS_DEFINITION"],
}
METHOD = "LLM full-note semantic coding with complete second-agent audit and documented reconciliation"
PROVENANCE = (
    "The earlier Notes were authored by Claude Opus 5.5 high AI reviewer runs. "
    "The user confirmed subsequent human review of the copied workbook decisions. "
    "Those copied decisions determine selection and substantive status and are unchanged. "
    "The new semantic taxonomy and assignments are LLM-assisted content categories, "
    "not newly human-validated judgments or independent verification of trial errors."
)


def read_json(name):
    return json.loads((ROOT / name).read_text())


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def write_csv(name, rows):
    with (ROOT / name).open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else v
                             for k, v in row.items()})


def main():
    src = read_json("confirmed_statistical_notes.json")
    provisional = read_json("semantic_coding_v1.json")
    taxonomy = deepcopy(read_json("taxonomy_v1.json"))
    with (ROOT / "coding_audit_independent_seed.tsv").open() as f:
        audit_seed = list(csv.DictReader(f, delimiter="\t"))
    assert len(src) == len(provisional) == len(audit_seed) == 139
    taxonomy["version"] = "final_reconciled_2026-10-22"
    taxonomy["status"] = "reconciled_LLM_content_categories_not_human_validated"
    taxonomy["method"] = METHOD
    taxonomy["provenance"] = PROVENANCE
    taxonomy["audit_design"] = (
        "The second agent read all 139 full Notes and saved independent proposed categories, "
        "exact excerpts, and rationales before opening the v1 coding file. The agents shared "
        "the taxonomy and discussed boundary cases; the subsequent audit explicitly inspected "
        "v1 and reconciled differences. This is not a blinded interrater reliability study; "
        "no kappa or human-coder reliability statistic is claimed."
    )
    for category in taxonomy["categories"]:
        category["id"] = category["code"]
        category["label"] = category["label_en"]
    cat = {r["id"]: r for r in taxonomy["categories"]}
    cat["DIRECTION"]["inclusion"] = (
        "The point-estimate sign, contrast order, favorable axis, residual sign, trend direction, "
        "or benefit/harm interpretation conflicts with the numerical contrast or display."
    )
    cat["DIRECTION"]["exclusion_and_boundary"] = (
        "Includes a locally dropped point sign regardless of severity. An isolated interval-endpoint "
        "sign is INTERVAL_DISPERSION; transfers between treatment columns or outcome rows are "
        "ATTRIBUTION. Incorrect wording of an interval bound relative to an inferential decision "
        "margin is TEST_INFERENCE, even if the ultimate conclusion remains correct."
    )
    cat["TEST_INFERENCE"]["inclusion"] = (
        "Printed P values fail to reproduce or disagree with intervals; significance, decision-rule, "
        "or bound-to-decision-margin explanations conflict with the reported numerical evidence."
    )
    cat["TEST_INFERENCE"]["exclusion_and_boundary"] = (
        "Includes false no-significance summaries, the number of cases meeting a statistical "
        "decision rule, and an incorrectly worded noninferiority-bound comparison even when "
        "the conclusion is correct. Excludes an explicitly diagnosed undisclosed method/level "
        "mismatch (ANALYSIS_DEFINITION) and a localized corrected interval endpoint (INTERVAL_DISPERSION)."
    )
    cat["INTERVAL_DISPERSION"]["exclusion_and_boundary"] += (
        " For candidates combining several independent mechanisms, a shared uncertainty defect "
        "across estimates may be selected as primary; such unresolved priority choices remain "
        "explicitly ambiguous and the inferential mechanism is retained secondarily."
    )
    cat["COUNT_DENOM"]["exclusion_and_boundary"] += (
        " Analysis-population denominator/header swaps remain COUNT_DENOM; a direct outcome "
        "or treatment result transfer is ATTRIBUTION. Numerical fraction-to-percent conversion "
        "is included even when it describes composition rather than participant counts."
    )
    taxonomy["primary_selection_rules"].extend([
        "A comparison of an interval bound against an inferential decision margin is TEST_INFERENCE, not DIRECTION; the latter concerns signed contrasts, trends, residuals, or benefit/harm interpretation.",
        "A specific interval repeating another identified outcome's interval is ATTRIBUTION. The code records the mapping asserted in the Note and does not claim a copying operation was independently verified.",
        "Effect-scale transformation, including log-times-100 effects mislabeled as percentage changes, is EFFECT_ESTIMAND.",
        "Where independent mechanisms coexist and neither is uniquely primary, assign one counting category while retaining audit_status=ambiguous, alternatives, and secondary categories. This does not change confirmation or substantive status.",
    ])
    taxonomy["reconciliation"] = {
        "all_notes_audited": 139, "initial_category_differences_discussed": 4,
        "provisional_primary_labels_changed": 3, "ambiguous_primary_assignments_retained": 3,
        "ambiguous_means": "Only the primary content-category priority is ambiguous; the pre-existing human-reviewed confirmation and substantive status remain fixed.",
    }
    taxonomy["secondary_categories"] = (
        "Optional other mechanisms mentioned in the retained Note; some are tentative or "
        "symptoms of a diagnosed cause. See the full Note and flags. They overlap and are "
        "never summed as independent candidates; only the primary category enters totals."
    )
    write_json("taxonomy_final.json", taxonomy)

    final = []
    audits = []
    disputed = []
    for index, (s, v, a) in enumerate(zip(src, provisional, audit_seed), 1):
        assert int(a["index"]) == index
        assert s["key"] == v["key"]
        assert a["evidence_excerpt"] in s["notes"]
        assert s["notes"] == v["supporting_excerpt"]
        assert s["final_substantiveness"] == v["final_substantiveness"]
        before = v["primary_category"]
        after = RECONCILIATION.get(index, {}).get("final", before)
        is_changed = before != after
        ambiguous = index in AMBIGUOUS
        status = "ambiguous" if ambiguous else "revise" if is_changed else "agree"
        initially_different = a["independent_category_id"] != before
        resolution = RECONCILIATION.get(index, {}).get("resolution", "Independent full-note category agrees with v1; retained after audit.")
        if ambiguous and index not in RECONCILIATION:
            resolution = "Both agents retain the same counting category, but independent mechanisms coexist; primary-category priority remains explicitly ambiguous."
        rationale = a["audit_rationale"]
        if index == 104:
            rationale = "The retained issue is a transformed effect/contrast mislabeled as percent change, which belongs to effect-scale identity; the serum interval asymmetry remains secondary and plasma rows are explicitly correctly transformed."
        flags = [x for x in a["flags"].split(";") if x]
        confidence = v["confidence"]
        if ambiguous or any(x.startswith(("qualified", "boundary", "unresolved", "multiple")) for x in flags):
            confidence = "medium"
        secondary = sorted(set(v["secondary_tags"] + flags + ["secondary_mechanism:" + c for c in SECONDARY.get(index, [])]))
        f = {
            "key": s["key"], "year": s["year"],
            "period": "2018--2019" if s["year"] < 2020 else "2024--2025",
            "paper": s["paper"], "candidate": s["candidate"],
            "title_context_only": s["title"], "notes": s["notes"],
            "final_substantiveness": s["final_substantiveness"],
            "is_confirmed_substantive": s["is_confirmed_substantive"],
            "primary_category_id": after, "primary_category_label": cat[after]["label"],
            "evidence_excerpt": a["evidence_excerpt"], "rationale": rationale,
            "coding_confidence": confidence, "secondary_tags": secondary,
            "secondary_category_ids": SECONDARY.get(index, []),
            "audit_status": status, "primary_assignment_ambiguous": ambiguous,
            "alternative_primary_category_ids": [x for x in AMBIGUOUS.get(index, []) if x != after],
            "provisional_primary_category_id": before,
            "independent_audit_primary_category_id": a["independent_category_id"],
            "primary_changed_from_v1": is_changed,
            "reconciliation": resolution, "coding_method": METHOD,
            "coding_version": taxonomy["version"],
            "taxonomy_human_validated": False, "independent_trial_verification": False,
        }
        for field in ["final_disposition", "final_domain", "final_issue", "final_impact", "relationship",
                      "source_workbook", "source_sha256", "sheet", "excel_row", "notes_cell",
                      "notes_sha256_utf8", "copy_workbook", "copy_sha256", "notes_author_type",
                      "notes_author_model", "notes_author_reasoning_effort", "final_labels_source"]:
            f[field] = s[field]
        final.append(f)
        audit = {
            "key": s["key"], "year": s["year"], "paper": s["paper"], "candidate": s["candidate"],
            "audit_status": status,
            "initial_audit_status": "ambiguous" if ambiguous else "revise" if initially_different else "agree",
            "provisional_primary_category_id": before,
            "independent_audit_primary_category_id": a["independent_category_id"],
            "final_primary_category_id": after,
            "initial_category_difference": initially_different,
            "primary_changed_from_v1": is_changed,
            "primary_assignment_ambiguous": ambiguous,
            "alternative_primary_category_ids": f["alternative_primary_category_ids"],
            "evidence_excerpt": a["evidence_excerpt"],
            "audit_rationale": a["audit_rationale"],
            "final_rationale": rationale, "reconciliation": resolution,
            "flags": flags, "notes": s["notes"],
            "final_substantiveness": s["final_substantiveness"],
            "is_confirmed_substantive": s["is_confirmed_substantive"],
            "human_label_changed": False,
        }
        audits.append(audit)
        if initially_different or ambiguous:
            disputed.append(audit)
    assert sum(x["primary_changed_from_v1"] for x in final) == 3
    assert sum(x["initial_category_difference"] for x in audits) == 4
    assert sum(x["primary_assignment_ambiguous"] for x in final) == 3
    assert sum(x["is_confirmed_substantive"] for x in final) == 37
    write_json("semantic_coding_final.json", final)
    write_csv("semantic_coding_final.csv", final)
    write_json("coding_audit_all.json", audits)
    write_csv("coding_audit_all.csv", audits)
    write_json("coding_audit_reconciliation.json", disputed)
    write_csv("coding_audit_reconciliation.csv", disputed)
    metadata = {
        "method": METHOD, "provenance": PROVENANCE,
        "audit_design": taxonomy["audit_design"],
        "all_notes_read_and_audited": 139,
        "initial_category_differences_discussed": 4,
        "provisional_primary_labels_changed": 3,
        "audit_status_counts": dict(Counter(x["audit_status"] for x in final)),
        "ambiguous_keys": [x["key"] for x in final if x["primary_assignment_ambiguous"]],
        "all_source_notes_unchanged": True, "all_human_reviewed_labels_unchanged": True,
        "all_evidence_excerpts_exact_substrings": True,
        "input_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                         for name in ["confirmed_statistical_notes.json", "semantic_coding_v1.json", "taxonomy_v1.json", "coding_audit_independent_seed.tsv"]},
    }
    write_json("coding_audit_metadata.json", metadata)
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
