#!/usr/bin/env python3
"""Validate reconciled note coding and produce zero-inclusive descriptive tables.

Run from any directory with Python 3 (standard library only). All category shares
are issue-count shares, not proportions of papers. Means include all 44 papers,
including papers with zero confirmed issues in the relevant category.
"""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PAPER_INDEX = ROOT.parent / "paper_results.csv"
PERIODS = {2018: "2018--2019", 2019: "2018--2019", 2024: "2024--2025", 2025: "2024--2025"}


def read_json(name):
    return json.loads((ROOT / name).read_text())


def write_csv(name, rows):
    assert rows, name
    with (ROOT / name).open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def ratio(n, d):
    return n / d if d else 0.0


def main():
    source = read_json("confirmed_statistical_notes.json")
    coded = read_json("semantic_coding_final.json")
    taxonomy = read_json("taxonomy_final.json")
    with PAPER_INDEX.open() as f:
        papers = list(csv.DictReader(f))
    cats = taxonomy["categories"]
    labels = {c["id"]: c["label"] for c in cats}
    src = {r["key"]: r for r in source}
    paper_keys = {(int(p["year"]), p["paper"]) for p in papers}
    assert len(papers) == len(paper_keys) == 44
    assert len(coded) == len(src) == 139
    assert len({r["key"] for r in coded}) == 139
    assert {r["key"] for r in coded} == set(src)
    for r in coded:
        s = src[r["key"]]
        assert r["notes"] == s["notes"], r["key"]
        assert r["evidence_excerpt"] in s["notes"], r["key"]
        assert r["final_substantiveness"] == s["final_substantiveness"], r["key"]
        assert r["final_domain"] == s["final_domain"] == "statistical_results", r["key"]
        assert r["is_confirmed_substantive"] == s["is_confirmed_substantive"], r["key"]
        assert r["primary_category_id"] in labels, r["key"]
        assert r["primary_category_label"] == labels[r["primary_category_id"]], r["key"]
        assert (r["year"], r["paper"]) in paper_keys, r["key"]
        assert r["audit_status"] in {"agree", "revise", "ambiguous"}, r["key"]
    assert sum(r["is_confirmed_substantive"] for r in coded) == 37

    all_counts = Counter((r["year"], r["paper"], r["primary_category_id"]) for r in coded)
    sub_counts = Counter((r["year"], r["paper"], r["primary_category_id"]) for r in coded if r["is_confirmed_substantive"])
    ambiguous_counts = Counter((r["year"], r["paper"], r["primary_category_id"]) for r in coded if r["primary_assignment_ambiguous"])
    paper_rows = []
    for p in papers:
        year = int(p["year"])
        for c in cats:
            k = (year, p["paper"], c["id"])
            paper_rows.append({
                "domain": "statistical_results", "cohort": "final_human_confirmed_statistical_candidates",
                "year": year, "period": PERIODS[year], "paper": p["paper"],
                "primary_category_id": c["id"], "primary_category_label": c["label"],
                "all_count": all_counts[k], "substantive_count": sub_counts[k],
                "ambiguous_primary_count": ambiguous_counts[k],
            })
    assert len(paper_rows) == 44 * len(cats)
    assert sum(x["all_count"] for x in paper_rows) == 139
    assert sum(x["substantive_count"] for x in paper_rows) == 37
    write_csv("paper_category_counts.csv", paper_rows)

    def stats(category, selected_papers):
        selected = {(int(p["year"]), p["paper"]) for p in selected_papers}
        relevant = [r for r in coded if (r["year"], r["paper"]) in selected]
        rows = [r for r in relevant if r["primary_category_id"] == category]
        n_all = len(rows)
        n_sub = sum(r["is_confirmed_substantive"] for r in rows)
        total_all = len(relevant)
        total_sub = sum(r["is_confirmed_substantive"] for r in relevant)
        return {
            "n_papers": len(selected),
            "all_count": n_all, "substantive_count": n_sub,
            "all_share": ratio(n_all, total_all),
            "substantive_share": ratio(n_sub, total_sub),
            "mean_all_per_paper": ratio(n_all, len(selected)),
            "mean_substantive_per_paper": ratio(n_sub, len(selected)),
            "papers_with_any": len({(r["year"], r["paper"]) for r in rows}),
            "papers_with_substantive": len({(r["year"], r["paper"]) for r in rows if r["is_confirmed_substantive"]}),
            "within_category_substantive_fraction": ratio(n_sub, n_all),
            "ambiguous_primary_count": sum(r["primary_assignment_ambiguous"] for r in rows),
            "ambiguous_substantive_count": sum(r["primary_assignment_ambiguous"] and r["is_confirmed_substantive"] for r in rows),
            "all_share_denominator": total_all,
            "substantive_share_denominator": total_sub,
        }

    overall = []
    by_year = []
    by_period = []
    early_papers = [p for p in papers if int(p["year"]) in (2018, 2019)]
    late_papers = [p for p in papers if int(p["year"]) in (2024, 2025)]
    assert len(early_papers) == 19 and len(late_papers) == 25
    for c in cats:
        identity = {"domain": "statistical_results", "cohort": "final_human_confirmed_statistical_candidates",
                    "primary_category_id": c["id"], "primary_category_label": c["label"]}
        overall.append({**identity, **stats(c["id"], papers)})
        for year in sorted(PERIODS):
            by_year.append({**identity, "year": year, "period": PERIODS[year],
                            **stats(c["id"], [p for p in papers if int(p["year"]) == year])})
        early = stats(c["id"], early_papers)
        late = stats(c["id"], late_papers)
        row = {**identity, "early_period": "2018--2019", "late_period": "2024--2025",
               "early_count": early["all_count"], "late_count": late["all_count"],
               "early_substantive": early["substantive_count"], "late_substantive": late["substantive_count"]}
        for prefix, values in (("early", early), ("late", late)):
            for field, value in values.items():
                row[f"{prefix}_{field}"] = value
        row["late_minus_early_mean_all_per_paper"] = late["mean_all_per_paper"] - early["mean_all_per_paper"]
        row["late_minus_early_mean_substantive_per_paper"] = late["mean_substantive_per_paper"] - early["mean_substantive_per_paper"]
        row["late_minus_early_all_share"] = late["all_share"] - early["all_share"]
        row["late_minus_early_substantive_share"] = late["substantive_share"] - early["substantive_share"]
        by_period.append(row)
    write_csv("category_summary.csv", overall)
    write_csv("category_year_summary.csv", by_year)
    write_csv("category_period_summary.csv", by_period)
    assert sum(r["early_count"] for r in by_period) == 56
    assert sum(r["late_count"] for r in by_period) == 83
    assert sum(r["early_substantive"] for r in by_period) == 16
    assert sum(r["late_substantive"] for r in by_period) == 21

    # A sensitivity description excludes candidates for which one primary category
    # is a transparent tie-break between multiple independently present mechanisms.
    sensitivity = []
    for c in cats:
        rows = [r for r in coded if r["primary_category_id"] == c["id"]]
        clear = [r for r in rows if r["audit_status"] != "ambiguous"]
        sensitivity.append({"domain": "statistical_results", "cohort": "final_human_confirmed_statistical_candidates",
                            "primary_category_id": c["id"], "primary_category_label": c["label"],
                            "all_count": len(rows), "unambiguous_all_count": len(clear),
                            "ambiguous_primary_count": len(rows) - len(clear),
                            "substantive_count": sum(r["is_confirmed_substantive"] for r in rows),
                            "unambiguous_substantive_count": sum(r["is_confirmed_substantive"] for r in clear)})
    write_csv("category_primary_assignment_sensitivity.csv", sensitivity)
    validation = {
        "status": "passed", "coding_rows": len(coded), "substantive_rows": 37,
        "unique_keys": 139, "categories": len(cats), "papers": len(papers),
        "paper_category_rows": len(paper_rows), "year_category_rows": len(by_year),
        "early_papers": 19, "late_papers": 25,
        "early_issues": 56, "late_issues": 83,
        "early_substantive_issues": 16, "late_substantive_issues": 21,
        "audit_status_counts": dict(Counter(r["audit_status"] for r in coded)),
        "all_source_notes_unchanged": True,
        "all_final_substantive_labels_unchanged": True,
        "all_evidence_excerpts_exact_substrings": True,
        "zero_inclusive_means": True,
        "category_comparisons": "Descriptive only; no category-level hypothesis tests or causal interpretation.",
        "shares": "Issue-count shares; all denominator 139 overall / 56 early / 83 late, substantive denominator 37 overall / 16 early / 21 late.",
        "input_sha256": {str(p.relative_to(ROOT.parent)): hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in [ROOT / "confirmed_statistical_notes.json", ROOT / "semantic_coding_final.json", ROOT / "taxonomy_final.json", PAPER_INDEX]},
    }
    (ROOT / "semantic_aggregation_validation.json").write_text(json.dumps(validation, indent=2) + "\n")
    print(json.dumps(validation, indent=2))


if __name__ == "__main__":
    main()
