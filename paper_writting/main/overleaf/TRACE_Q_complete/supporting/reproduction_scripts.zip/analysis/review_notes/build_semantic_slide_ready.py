#!/usr/bin/env python3
"""Produce report-ready text/data from the reconciled statistical-results coding."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read_csv(name):
    with (ROOT / name).open() as f:
        return list(csv.DictReader(f))


def main():
    coding = json.loads((ROOT / "semantic_coding_final.json").read_text())
    lookup = {r["key"]: r for r in coding}
    summary = read_csv("category_summary.csv")
    period = read_csv("category_period_summary.csv")
    examples = [
        ("2019::jama.2019.14630::C007", "Repeated interval-versus-P conflicts across visits.",
         "The retained problem is a likely missing minus sign at the 12-month upper limit; the six-month rows are explicitly compatible with rounding.",
         "The 6-mo rows with an upper limit of 0 and P = .01/.02 can be reproduced by rounding"),
        ("2019::jama.2019.7505::C009", "An isolated interval-versus-test compatibility issue.",
         "The Note also identifies a nonestimable arm risk ratio and a pooled-risk construction, supporting EFFECT_ESTIMAND as primary.",
         "a finite RR with a narrow CI is not estimable from 1 vs 0 events."),
        ("2024::jama.2024.19585::C007", "A generic significant-P versus nonsignificant-CI contradiction.",
         "The Note identifies different undisclosed methods for the intervals and tests; method identity is primary.",
         "CI and P come from different, undisclosed methods."),
        ("2024::jama.2024.6063::C012", "Repeated contrast-interval width failures.",
         "The retained glucose interval repeats the identified hsCRP interval. The separate WOMAC width allegation is explicitly not established because modeled arm changes share coefficients.",
         "has exactly the interval of the hsCRP week-12 row"),
        ("2025::jama.2025.11178::C014", "Several generic coefficient CI-versus-P conflicts.",
         "The Note diagnoses approximately 68% intervals labeled 95%, while other ratio-row appearances are compatible with rounding.",
         "the 'CIs' are ~68% intervals."),
        ("2025::jama.2025.20765::C014", "Fourteen interval rows with a failed symmetry rule.",
         "The Note explicitly rejects asymmetry alone as an error when derivation is unstated, retaining a local endpoint typo and mixed precision.",
         "asymmetry is not itself an error."),
        ("2025::jama.2025.24175::C014", "An interval that does not contain its point estimate.",
         "The Note localizes the discrepancy to the point estimate: 0.11 is a typo for 1.11, while the interval and P value reproduce.",
         "'0.11' is a typo for 1.11."),
    ]
    example_rows = []
    for key, risk, clarification, excerpt in examples:
        c = lookup[key]
        assert excerpt in c["notes"]
        example_rows.append({
            "domain": "statistical_results", "key": key,
            "title": c["title_context_only"],
            "title_only_reading_risk": risk,
            "full_note_clarification": clarification,
            "primary_category_id": c["primary_category_id"],
            "evidence_excerpt": excerpt,
            "final_substantiveness": c["final_substantiveness"],
            "comparison_scope": "Illustrative title-versus-full-note interpretation, not a numerical audit of a prior title classifier.",
        })
    with (ROOT / "semantic_title_note_examples.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=example_rows[0])
        w.writeheader()
        w.writerows(example_rows)

    method = [
        "Scope: final human-reviewed statistical_results domain only; 139 confirmed candidate records, including 37 labeled substantive. Other domains are not included in this recategorization.",
        "The source Notes were authored by earlier Claude Opus 5.5 high AI review runs. Subsequent human-reviewed copied workbook decisions determine confirmation and substantive status; no Note is represented as human-written.",
        "LLM full-note semantic coding uses seven mutually exclusive primary categories plus separate overlapping secondary tags. Candidate titles provide context only; no judgments.json rationale is imported.",
        "Every full Note was read by the second agent and checked against v1; all 139 have exact evidence excerpts and rationales. Four category-boundary differences were discussed and three provisional primary labels changed.",
        "Three bundled candidates retain explicit ambiguous-primary flags. Their confirmation and substantive status are unchanged. One ambiguous candidate was also revised, so final audit statuses are 134 agree, 2 revise, 3 ambiguous while total primary revisions equal 3.",
        "This was an LLM coding audit with v1 available during reconciliation, not a blinded interrater reliability study. The new taxonomy is not human validated; no kappa or human-coder reliability statistic is claimed.",
        "Candidate records are the counting unit. Multiple linked candidates can share an underlying defect. Counts therefore do not estimate unique defects or trial prevalence.",
    ]
    conclusions = [
        "Counts/percentages/population accounting form the largest overall category: 39/139 (28.1%), but only 4/37 (10.8%) of substantive candidates. Effect/estimand identity is the largest substantive category: 8/37 (21.6%), followed by intervals/dispersion 7/37 (18.9%) and attribution 6/37 (16.2%). Categories and substantive status measure different features.",
        "The sampled later-period profile contains more analysis/measure-definition candidates per paper (0.16 to 0.68) and more count/denominator candidates (0.68 to 1.04), while interval/dispersion candidates decline (0.74 to 0.40). These are descriptive differences in this corpus, not evidence of a temporal or causal trend.",
        "Across all categories, counts rise from 56 to 83 confirmed candidates and from 16 to 21 substantive candidates as the paper denominator grows from 19 to 25. Zero-inclusive means are 2.95 to 3.32 for all confirmed candidates and 0.842 to 0.840 for substantive candidates. The substantive mean is essentially unchanged despite the larger later count.",
    ]
    ambiguity = [
        {"key": r["key"], "assigned_primary": r["primary_category_id"],
         "alternative_primary": r["alternative_primary_category_ids"],
         "final_substantiveness": r["final_substantiveness"],
         "explanation": r["rationale"]}
        for r in coding if r["primary_assignment_ambiguous"]
    ]
    output = {
        "title": "LLM-assisted semantic profile of final human-confirmed statistical-results candidates",
        "method_points": method, "careful_conclusions": conclusions,
        "overall_category_table": summary, "period_category_table": period,
        "title_note_examples": example_rows, "ambiguous_primary_assignments": ambiguity,
        "denominators": {"all_papers": 44, "early_papers": 19, "late_papers": 25,
                         "all_confirmed": 139, "all_substantive": 37,
                         "early_confirmed": 56, "late_confirmed": 83,
                         "early_substantive": 16, "late_substantive": 21},
        "mean_definition": "Candidate count divided by all sampled papers in that period; zero-inclusive.",
        "share_definition": "Category candidate count divided by all confirmed or substantive candidates within that period; not a paper proportion.",
        "inference": "Descriptive only; no category-level significance tests. Four sampled years, not a continuous annual trend. Small substantive cells and three ambiguous primary assignments limit interpretation.",
        "reproduce": ["python3 analysis/review_notes/coding_audit_reconcile.py",
                      "python3 analysis/review_notes/aggregate_semantic_categories.py",
                      "python3 analysis/review_notes/build_semantic_slide_ready.py"],
    }
    (ROOT / "semantic_slide_ready.json").write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n")
    lines = [output["title"], "", "METHOD AND PROVENANCE", *method, "", "OVERALL CATEGORY PROFILE",
             "Primary category | All count/share of 139 | Substantive count/share of 37 | All mean/44 papers | Substantive mean/44 papers"]
    for row in summary:
        lines.append(f"{row['primary_category_label']} | {row['all_count']} ({float(row['all_share']):.1%}) | "
                     f"{row['substantive_count']} ({float(row['substantive_share']):.1%}) | "
                     f"{float(row['mean_all_per_paper']):.3f} | {float(row['mean_substantive_per_paper']):.3f}")
    lines += ["", "DESCRIPTIVE PERIOD COMPARISON: 2018-2019 (19 PAPERS) VS 2024-2025 (25 PAPERS)",
              "Category | All early count/share/mean -> late count/share/mean | Substantive early count/share/mean -> late count/share/mean"]
    for row in period:
        segments = []
        for status in ("all", "substantive"):
            pair = []
            for p in ("early", "late"):
                pair.append(f"{row[p+'_'+status+'_count']} / {float(row[p+'_'+status+'_share']):.1%} / {float(row[p+'_mean_'+status+'_per_paper']):.3f}")
            segments.append(" -> ".join(pair))
        lines.append(row["primary_category_label"] + " | " + " | ".join(segments))
    lines += ["", output["share_definition"], output["mean_definition"], output["inference"],
              "", "THREE CAREFUL CONCLUSIONS", *conclusions,
              "", "WHAT FULL NOTES CHANGE RELATIVE TO A TITLE-ONLY READING",
              "These are illustrative interpretation differences, not measured reclassification rates from an earlier title classifier."]
    for row in example_rows:
        lines += [row["key"] + " | " + row["primary_category_id"],
                  "Title: " + row["title"], "Full Note: " + row["full_note_clarification"],
                  "Exact excerpt: " + row["evidence_excerpt"]]
    lines += ["", "AMBIGUOUS PRIMARY ASSIGNMENTS: INCLUDED ONCE IN MAIN COUNTS"]
    for row in ambiguity:
        lines += [row["key"] + " | " + row["assigned_primary"] + " | alternative " + ", ".join(row["alternative_primary"]), row["explanation"]]
    lines += ["Removing the three ambiguous assignments leaves 136 records, including 34 substantive records. The largest overall category (COUNT_DENOM) and largest substantive category (EFFECT_ESTIMAND) are unchanged; see category_primary_assignment_sensitivity.csv for all seven rows.",
              "", "REPRODUCTION", *output["reproduce"]]
    (ROOT / "semantic_slide_ready.txt").write_text("\n".join(lines) + "\n")
    print("Wrote semantic_slide_ready.json/txt and semantic_title_note_examples.csv.")


if __name__ == "__main__":
    main()
