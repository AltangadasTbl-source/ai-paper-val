#!/usr/bin/env python3
"""Deterministically extract original R_Bulun notes and audit frozen tables.

Python standard library only; run from any working directory. No source is
modified. Logical cell values, formulas, and original XML value text are kept
distinct. Notes are never stripped, normalized, or inferred in raw exports.
"""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import posixpath
import re
import statistics
import unicodedata
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile

NS = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
FIELDS = ["key", "title", "source_location", "disposition", "domain", "complete",
          "validation_hint", "issue", "substantiveness", "impact", "internal",
          "protocol", "unused13", "unused14", "unused15", "unused16", "unused17", "notes"]
COLUMNS = dict(zip("ABCDEFGHIJKLMNOPQR", FIELDS))
YEARS = (2018, 2019, 2024, 2025)
EXPECTED_COUNTS = {2018: 115, 2019: 79, 2024: 113, 2025: 133}
STOPWORDS = set("""a an and are as at be been being but by can could did do does doing
for from had has have having he her here hers him his how i if in into is it its
itself may me more most my no nor not of on once only or other our ours out over
own same she should so some such than that the their theirs them themselves then
there these they this those through to too under until up us very was we were
what when where which while who whom why will with would you your yours
also any both each either neither all just about above after again against
before below between during further off because without within per versus vs
""".split())
# Source-location boilerplate, kept separate and fully exported for review.
LOCATION_STOPWORDS = set("""p pp page pages main table tables etable etables figure
figures efigure efigures supplement supplements supp suppl supplementary
appendix appendices fig figs fn footnote footnotes line lines pdf docx xlsx
see shown shows showing states stated says said row rows col cols column columns
section sections text note notes report reports reported reporting protocol sap
""".split())
TOKEN_RE = re.compile(r"[a-z]+(?:'[a-z]+)?")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows, fields=None):
    fields = fields or list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, lineterminator="\n", extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False, separators=(",", ":"))
                             if isinstance(v, (dict, list)) else v for k, v in row.items()})


def load_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def unique_index(rows, name):
    result = {x["key"]: x for x in rows}
    assert len(result) == len(rows), f"Duplicate keys in {name}"
    return result


def rich_text(element):
    """Concatenate text runs, excluding optional phonetic annotation runs."""
    if element is None:
        return ""
    chunks = []
    for child in element:
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "t":
            chunks.append(child.text or "")
        elif tag == "r":
            chunks.extend(t.text or "" for t in child.findall("s:t", NS))
    return "".join(chunks)


def parse_workbook(path):
    sheets = {}
    with ZipFile(path) as archive:
        strings = []
        if "xl/sharedStrings.xml" in archive.namelist():
            strings = [rich_text(x) for x in ET.fromstring(archive.read("xl/sharedStrings.xml"))]
        wb = ET.fromstring(archive.read("xl/workbook.xml"))
        rel = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        targets = {x.attrib["Id"]: x.attrib["Target"] for x in rel}
        for sheet in wb.findall("s:sheets/s:sheet", NS):
            target = targets[sheet.attrib["{" + NS["r"] + "}id"]]
            target = target.lstrip("/") if target.startswith("/") else posixpath.normpath("xl/" + target)
            cells = {}
            for cell in ET.fromstring(archive.read(target)).findall("s:sheetData/s:row/s:c", NS):
                kind = cell.attrib.get("t", "n")
                xml_v = cell.find("s:v", NS)
                xml_v = xml_v.text if xml_v is not None else None
                formula = cell.find("s:f", NS)
                formula = formula.text if formula is not None else None
                value = xml_v
                if kind == "s":
                    value = strings[int(xml_v)] if xml_v is not None else None
                elif kind == "inlineStr":
                    value = rich_text(cell.find("s:is", NS))
                elif kind == "b" and xml_v is not None:
                    value = xml_v == "1"
                elif kind == "n" and xml_v is not None:
                    value = float(xml_v) if any(c in xml_v.lower() for c in ".e") else int(xml_v)
                cells[cell.attrib["r"]] = {"value": value, "formula": formula,
                                          "xml_type": kind, "xml_value": xml_v}
            sheets[sheet.attrib["name"]] = cells
    return sheets


def value(cells, ref):
    return cells.get(ref, {}).get("value")


def logical_blank(v):
    return "" if v is None else v


def cell_sort(ref):
    m = re.fullmatch(r"([A-Z]+)([0-9]+)", ref)
    return int(m[2]), len(m[1]), m[1]


def derived(row):
    eligible = row["disposition"] == "retain" and row["relationship"] in {"S_C", "S_W"}
    statistical = eligible and row["domain"] == "statistical_results"
    primary = statistical and row["issue"] in {"confirmed_issue", "probable_issue"} and row["substantiveness"] == "substantive"
    secondary = eligible and row["domain"] == "report_internal_inconsistency" and row["internal"] == "substantive_inconsistency"
    confirmed = statistical and row["issue"] == "confirmed_issue"
    return {"report_relationship": row["relationship"] in {"S_C", "S_W"},
            "primary": primary, "strict": primary and row["issue"] == "confirmed_issue",
            "secondary": secondary, "combined": primary or secondary,
            "confirmed_report": confirmed or (eligible and row["domain"] == "report_internal_inconsistency" and row["internal"] in {"substantive_inconsistency", "minor_presentation"}),
            "is_confirmed_statistical": confirmed,
            "is_confirmed_substantive": confirmed and row["substantiveness"] == "substantive"}


def normalized_note(note):
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", note or "").casefold()).strip()


def text_mining(out, subsets):
    assert set(subsets) == {"confirmed_statistical", "confirmed_substantive"}
    normalized, stats_rows, term_rows = [], [], []
    for row in subsets["confirmed_statistical"]:
        text = normalized_note(row["notes"])
        tokens = TOKEN_RE.findall(text)
        normalized.append({"key": row["key"], "year": row["year"], "paper": row["paper"],
                           "normalized_notes": text, "tokens": tokens,
                           "content_tokens": [t for t in tokens if len(t) > 1 and t not in STOPWORDS | LOCATION_STOPWORDS]})
    write_json(out / "text_normalized_notes.json", normalized)
    index = {x["key"]: x for x in normalized}
    for subset_name, rows in subsets.items():
        for year in ("all",) + YEARS:
            group = [r for r in rows if year == "all" or r["year"] == year]
            lengths = [len(index[r["key"]]["tokens"]) for r in group]
            nonempty = [r for r in group if r["notes"] is not None and r["notes"].strip()]
            stats_rows.append({"subset": subset_name, "year": year, "candidates": len(group),
                               "papers": len({r["paper"] for r in group}), "notes_nonempty": len(nonempty),
                               "notes_null": sum(r["notes"] is None for r in group),
                               "notes_empty_string": sum(r["notes"] == "" for r in group),
                               "notes_whitespace_only": sum(isinstance(r["notes"], str) and r["notes"] != "" and not r["notes"].strip() for r in group),
                               "tokens_total": sum(lengths), "tokens_mean": round(statistics.mean(lengths), 6) if lengths else None,
                               "tokens_median": statistics.median(lengths) if lengths else None,
                               "tokens_min": min(lengths) if lengths else None,
                               "tokens_max": max(lengths) if lengths else None})
            for view, stop in (("english_stopwords", STOPWORDS), ("english_and_location_stopwords", STOPWORDS | LOCATION_STOPWORDS)):
                for ngram in (1, 2):
                    df, tf = collections.Counter(), collections.Counter()
                    for row in group:
                        text = index[row["key"]]["normalized_notes"]
                        # Work within punctuation-delimited segments; do not form artificial
                        # bigrams after stopword deletion or across numbers/punctuation.
                        segments = re.findall(r"[a-z]+(?:'[a-z]+)?(?:[ \t]+[a-z]+(?:'[a-z]+)?)*", text)
                        grams = []
                        for segment in segments:
                            toks = TOKEN_RE.findall(segment)
                            grams.extend(" ".join(toks[i:i+ngram]) for i in range(len(toks)-ngram+1)
                                         if all(len(t) > 1 and t not in stop for t in toks[i:i+ngram]))
                        tf.update(grams); df.update(set(grams))
                    for term in sorted(df, key=lambda t: (-df[t], -tf[t], t)):
                        term_rows.append({"subset": subset_name, "year": year, "view": view, "ngram": ngram,
                                          "term": term, "document_frequency": df[term], "term_frequency": tf[term],
                                          "documents_total": len(group), "nonempty_documents": len(nonempty),
                                          "fraction_all_documents": round(df[term] / len(group), 6) if group else None})
    write_csv(out / "text_note_statistics.csv", stats_rows)
    write_csv(out / "text_word_bigram_frequencies.csv", term_rows)
    write_json(out / "text_mining_specification.json", {
        "normalization": "NFKC, Unicode casefold, whitespace collapsed, outer whitespace stripped; applied only to separate normalized export",
        "raw_notes": "Exact extracted logical cell text, including whitespace; null, empty string and whitespace-only distinguished",
        "token_pattern": TOKEN_RE.pattern, "stemming": False, "lemmatization": False,
        "numbers": "Excluded from lexical frequency counts; preserved in raw and normalized notes",
        "ngrams": "Unigrams and adjacent bigrams within alphabetic punctuation-delimited segments; reject grams with stopwords or one-character tokens; do not join tokens over deletions",
        "english_stopwords": sorted(STOPWORDS), "location_stopwords": sorted(LOCATION_STOPWORDS),
        "frequency_unit": "One candidate note; document frequency counts each term at most once per note",
        "sorting": "Descending document frequency, descending term frequency, ascending term",
        "denominators": "All selected candidate rows including missing notes; nonempty document counts also supplied",
        "scope": "Only final-human-reviewed statistical_results candidates with confirmed_issue, retained disposition, and original S_C/S_W relationship: 139 confirmed statistical notes and the overlapping 37 confirmed-substantive notes. No preprocessing or lexical mining of other candidates. Excludes protocol_report, report_internal_inconsistency, and plan_material. Descriptive vocabulary only; no topics, errors, or categories inferred from keyword frequencies",
        "independence": "Candidate notes cluster within papers; no independent-document statistical inference performed"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    project, out = args.project.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    provenance_path = project / "analysis/candidate_provenance.csv"
    analysis_path = project / "analysis/candidate_results.csv"
    readme_path = project / "reviewer_runs_raw/README.md"
    provenance = unique_index(load_csv(provenance_path), "candidate_provenance.csv")
    analysis = unique_index(load_csv(analysis_path), "candidate_results.csv")
    readme = readme_path.read_text(encoding="utf-8")
    assert "Claude Opus 5.5 agent sessions (high reasoning effort), not by people" in readme
    assert "No person reviewed any candidate" in readme
    input_hashes = [{"role": role, "path": str(path.relative_to(project)), "sha256": sha(path)}
                    for role, path in [("reviewer provenance", readme_path), ("frozen candidate provenance", provenance_path), ("existing candidate analysis", analysis_path)]]
    all_rows, diff_values, diff_formulas, analysis_diffs, copy_analysis_diffs = [], [], [], [], []
    year_audits = []
    cell_archive = {}
    for year in YEARS:
        candidates = sorted((project / f"reviewer_runs_raw/{year}/R_Bulun").glob("*.xlsx"))
        assert len(candidates) == 1, (year, candidates)
        raw_path = candidates[0]
        copy_path = project / "review_results_2_4_1_Rbulun_copy" / raw_path.name
        raw_sha, copy_sha = sha(raw_path), sha(copy_path)
        raw, copied = parse_workbook(raw_path), parse_workbook(copy_path)
        assert set(raw) == set(copied), f"Sheet mismatch: {year}"
        input_hashes.extend([{"role": role, "path": str(path.relative_to(project)), "sha256": digest}
                             for role, path, digest in [("raw reviewer workbook", raw_path, raw_sha), ("copied review workbook", copy_path, copy_sha)]])
        value_start, formula_start, row_start = len(diff_values), len(diff_formulas), len(all_rows)
        cell_archive[str(year)] = {"source_workbook": str(raw_path.relative_to(project)), "source_sha256": raw_sha, "sheets": raw}
        for sheet in raw:
            a, b = raw[sheet], copied[sheet]
            for ref in sorted(set(a) | set(b), key=cell_sort):
                old, new = value(a, ref), value(b, ref)
                key = value(a, "A" + re.search(r"[0-9]+$", ref)[0]) if sheet.startswith("C_") else None
                if logical_blank(old) != logical_blank(new):
                    diff_values.append({"year": year, "sheet": sheet, "cell": ref, "key": key,
                                        "field": COLUMNS.get(re.sub(r"[0-9]+", "", ref), "") if sheet.startswith("C_") else "",
                                        "raw_value": old, "copy_value": new})
                fa, fb = a.get(ref, {}).get("formula"), b.get(ref, {}).get("formula")
                if fa != fb:
                    diff_formulas.append({"year": year, "sheet": sheet, "cell": ref,
                                          "raw_formula": fa, "copy_formula": fb})
            if not sheet.startswith("C_"):
                continue
            assert value(a, "A1") == "Candidate key"
            assert value(a, "R1") == "Notes (optional)"
            for ref in sorted(a, key=cell_sort):
                if not re.fullmatch(r"A[0-9]+", ref) or ref == "A1" or not value(a, ref):
                    continue
                excel_row = int(ref[1:])
                key = value(a, ref)
                key_year, paper, candidate = key.split("::")
                assert key_year == str(year) and sheet == "C_" + paper
                assert re.fullmatch(r"C[0-9]{3}", candidate)
                assert key in provenance and key in analysis, f"Unmatched key: {key}"
                prov = provenance[key]
                row = {field: value(a, col + str(excel_row)) for col, field in COLUMNS.items()}
                # User confirms copied labels were subsequently human-reviewed.
                # Eligibility therefore uses those final labels, independently of
                # whether the earlier AI labels happen to have identical values.
                label_fields = ["disposition", "domain", "complete", "validation_hint", "issue", "substantiveness", "impact", "internal", "protocol"]
                for col, field in COLUMNS.items():
                    if field in label_fields:
                        row["raw_" + field] = row[field]
                        row["final_" + field] = value(b, col + str(excel_row))
                        row[field] = row["final_" + field]
                row.update({"year": year, "paper": paper, "candidate": candidate,
                            "sheet": sheet, "excel_row": excel_row, "notes_cell": "R" + str(excel_row),
                            "notes_cell_present": "R" + str(excel_row) in a,
                            "notes_cell_type": a.get("R" + str(excel_row), {}).get("xml_type"),
                            "notes_sha256_utf8": hashlib.sha256(row["notes"].encode("utf-8")).hexdigest() if row["notes"] is not None else None,
                            "source_workbook": str(raw_path.relative_to(project)), "source_sha256": raw_sha,
                            "copy_workbook": str(copy_path.relative_to(project)), "copy_sha256": copy_sha,
                            "reviewer_label": "R_Bulun", "notes_author_type": "AI agent", "notes_author_model": "Claude Opus 5.5",
                            "notes_author_reasoning_effort": "high", "notes_provenance_source": str(readme_path.relative_to(project)),
                            "final_labels_source": "copied workbooks; subsequent human review confirmed by user 2026-10-22",
                            "original_domain": prov["domain"], "relationship": prov["relationship_type"],
                            "report_path": prov["report_path"], "report_sha256": prov["report_sha256"],
                            "provenance_csv_sha256": sha(provenance_path)})
                row.update(derived(row))
                for col, field in COLUMNS.items():
                    for dest, observed, label in [(analysis_diffs, value(a, col + str(excel_row)), "raw"), (copy_analysis_diffs, value(b, col + str(excel_row)), "copy")]:
                        if logical_blank(observed) != analysis[key][field]:
                            dest.append({"key": key, "field": field, "source_value": observed,
                                         "analysis_value": analysis[key][field], "source": label,
                                         "year": year, "sheet": sheet, "cell": col + str(excel_row)})
                for field in ["year", "paper", "sheet", "excel_row", "original_domain", "relationship"]:
                    assert str(row[field]) == analysis[key][field], (key, field, row[field], analysis[key][field])
                assert raw_path.name == analysis[key]["workbook"]
                for field, expected in derived(row).items():
                    if field in analysis[key]:
                        assert analysis[key][field] == str(expected).upper(), (key, field)
                all_rows.append(row)
        assert len(all_rows) - row_start == EXPECTED_COUNTS[year]
        year_audits.append({"year": year, "candidate_count": len(all_rows) - row_start,
                            "raw_sha256": raw_sha, "copy_sha256": copy_sha,
                            "binary_identical": raw_sha == copy_sha,
                            "cell_value_differences": len(diff_values) - value_start,
                            "formula_differences": len(diff_formulas) - formula_start})
    all_rows.sort(key=lambda r: (r["year"], r["paper"], r["candidate"]))
    assert len(all_rows) == 440
    index = unique_index(all_rows, "raw workbooks")
    assert set(index) == set(provenance) == set(analysis)
    confirmed = [r for r in all_rows if r["is_confirmed_statistical"]]
    substantive = [r for r in all_rows if r["is_confirmed_substantive"]]
    subsets = {"all": all_rows, "confirmed_statistical": confirmed, "confirmed_substantive": substantive}
    for name, rows in [("all_notes", all_rows), ("confirmed_statistical_notes", confirmed), ("confirmed_substantive_notes", substantive)]:
        write_json(out / (name + ".json"), rows)
        write_csv(out / (name + ".csv"), rows, list(all_rows[0]))
    write_json(out / "extraction_raw_cell_archive.json", cell_archive)
    write_csv(out / "source_input_hashes.csv", input_hashes)
    write_csv(out / "raw_copy_cell_value_differences.csv", diff_values, ["year", "sheet", "cell", "key", "field", "raw_value", "copy_value"])
    write_csv(out / "raw_copy_formula_differences.csv", diff_formulas, ["year", "sheet", "cell", "raw_formula", "copy_formula"])
    for filename, diffs in [("raw_analysis_value_differences.csv", analysis_diffs), ("raw_copy_analysis_value_differences.csv", copy_analysis_diffs)]:
        write_csv(out / filename, diffs, ["key", "field", "source_value", "analysis_value", "source", "year", "sheet", "cell"])
    audit = {"counts": {name: len(rows) for name, rows in subsets.items()},
             "years": year_audits,
             "all_keys_unique_and_equal_to_both_frozen_tables": True,
             "metadata_and_derived_analysis_flags_match_final_copied_labels": True,
             "raw_copy_value_differences_by_field": dict(sorted(collections.Counter(d["field"] for d in diff_values).items())),
             "raw_copy_formula_differences": len(diff_formulas),
             "raw_analysis_differences_by_field": dict(sorted(collections.Counter(d["field"] for d in analysis_diffs).items())),
             "copy_analysis_value_differences": len(copy_analysis_diffs),
             "notes_missing": sum(r["notes"] is None or not r["notes"].strip() for r in all_rows),
             "confirmed_statistical_filter": "FINAL COPIED HUMAN-REVIEWED LABELS: disposition=retain AND domain=statistical_results AND issue=confirmed_issue AND frozen relationship IN (S_C,S_W)",
             "confirmed_substantive_filter": "confirmed_statistical_filter AND substantiveness=substantive",
             "value_comparison": "All worksheets/all XML cell addresses; None and empty string treated as equal logical blanks. Formatting, ZIP metadata, and empty-cell presence do not count as cell-value changes. Formulas compared separately; no recalculation.",
             "reviewer_provenance": "Raw-run notes and raw-run labels were authored by Claude Opus 5.5 high AI sessions, with no person reviewing candidates at that stage, per reviewer_runs_raw/README.md. User subsequently confirmed that copied workbooks underwent later human review; final copied human-reviewed labels are authoritative for eligibility.",
             "provenance_inference_limit": "Raw Notes are earlier AI-run rationales, not human-authored explanations. Later human review is established by the user's explicit confirmation, not inferred from label equality. Its independent extent is not established by workbook comparison."}
    write_json(out / "extraction_audit.json", audit)
    corpus = ["Confirmed statistical review notes for semantic classification", "",
              audit["confirmed_statistical_filter"],
              "Notes authorship: earlier R_Bulun Claude Opus 5.5 high AI sessions; not human-authored rationales.",
              "Selection labels: copied final human-reviewed workbooks, as confirmed by user 2026-10-22.",
              "Review complete candidate notes semantically. Lexical frequencies do not determine categories.",
              "Notes below are exact extracted text; titles and labels provide context.", ""]
    for r in confirmed:
        corpus.extend(["=" * 80, f"KEY: {r['key']}",
                       f"Year: {r['year']} | Paper: {r['paper']} | Candidate: {r['candidate']}",
                       f"Title: {r['title']}",
                       f"FINAL HUMAN-REVIEWED: Disposition: {r['disposition']} | Final domain: {r['domain']} | Original catalog domain: {r['original_domain']} | Relationship: {r['relationship']}",
                       f"FINAL HUMAN-REVIEWED: Issue: {r['issue']} | Substantiveness: {r['substantiveness']} | Impact: {r['impact'] or '[blank]'}",
                       f"EARLIER RAW AI LABELS: Disposition: {r['raw_disposition']} | Domain: {r['raw_domain']} | Issue: {r['raw_issue']} | Substantiveness: {r['raw_substantiveness']}",
                       f"Source workbook: {r['source_workbook']} | Sheet: {r['sheet']} | Row: {r['excel_row']} | Notes: {r['notes_cell']}",
                       "NOTES (verbatim):", r["notes"] if r["notes"] is not None else "[NULL CELL]", ""])
    (out / "confirmed_corpus_for_semantic_review.txt").write_text("\n".join(corpus) + "\n", encoding="utf-8")
    text_mining(out, {name: rows for name, rows in subsets.items() if name != "all"})
    report = ["R_Bulun raw review-notes extraction and provenance audit", "",
              "Reproduce: python3 analysis/review_notes/extract_review_notes.py", "",
              f"All candidates: {len(all_rows)} across {len({r['paper'] for r in all_rows})} papers.",
              f"Confirmed statistical subset: {len(confirmed)}; confirmed substantive subset: {len(substantive)}.",
              f"Missing or whitespace-only raw notes: {audit['notes_missing']}.",
              "", "Subset definitions:", audit["confirmed_statistical_filter"], audit["confirmed_substantive_filter"],
              "", "Source provenance:", audit["reviewer_provenance"], audit["provenance_inference_limit"],
              "", "Value comparisons:",
              f"Raw vs copied workbooks: {len(diff_values)} cell-value differences; fields = {audit['raw_copy_value_differences_by_field']}; formula differences = {len(diff_formulas)}.",
              f"Raw vs candidate_results.csv: {len(analysis_diffs)} field differences; fields = {audit['raw_analysis_differences_by_field']}.",
              f"Copied workbooks vs candidate_results.csv: {len(copy_analysis_diffs)} field differences.",
              "All 440 keys match both frozen CSV tables exactly; metadata, original relationship/domain, and derived endpoint flags checked.",
              audit["value_comparison"],
              "", "Raw preservation:",
              "all_notes.json preserves JSON null versus empty strings and exact logical Notes text. CSV empty fields can represent either; notes_cell_type and notes_cell_present retain cell metadata, and the full XML-value archive retains exact value/type/formula representations.",
              "Each candidate carries year, paper, candidate key, source workbook and SHA-256, sheet, row, note-cell address, original label values, frozen relationship/domain and report hash. Original_domain means the frozen candidate catalog. The base label fields and final_* fields come from copied human-reviewed workbooks; raw_* fields retain earlier AI-run labels. Notes always come from raw workbooks.",
              "", "Descriptive text mining:",
              "Normalization and lexical analysis are restricted to the 139 final-human-confirmed statistical_results notes and their overlapping 37 confirmed-substantive notes. Other candidates remain only in the verbatim source extraction; protocol_report, report_internal_inconsistency, and plan_material are excluded from text mining. The specification exports all stopwords, tokenization rules, denominators and sorting. Word and adjacent-bigram document frequencies and term frequencies are given for these two subsets and each year in two transparent stopword views.",
              "These frequencies describe vocabulary, not validated issue categories. Candidate notes cluster within papers and share an AI authoring process; no inferential tests are performed."]
    (out / "extraction_report.txt").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps(audit, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
