"""Materialize a manual, full-note semantic coding; no lexical classifier is used."""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'confirmed_statistical_notes.json'
EXPECTED_SOURCE_SHA256 = 'c46042cfc61eb4357e9644198cc9ea2bd62626fc9fff6f53478a3f709d51ab04'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED_SOURCE_SHA256, 'Source/order changed: manually reconcile stable-key assignments before regenerating.'
rows = json.loads(SOURCE.read_text())

CATEGORIES = [
    ('COUNT_DENOM', 'Counts, percentages, and population accounting', '计数、百分比与人群分母',
     'Counts, percentages, denominators, totals, missingness accounting, or population-stage counts fail to reconcile.',
     'Includes local percent/decimal typos and mislabeled analysis-stage counts. Excludes an identified row/group/outcome transfer (ATTRIBUTION), and score-scale definitions (ANALYSIS_DEFINITION).'),
    ('EFFECT_ESTIMAND', 'Effect estimates and estimand identity', '效应估计与估计目标',
     'The effect estimate, its construction, scale, or identity is inconsistent or insufficiently specified; includes ratios asserted in the Notes to be nonestimable.',
     'Includes RR versus OR, transposed/pooled risks, SMD construction, effect-scale transformation and point-estimate typos. Excludes pure contrast sign (DIRECTION), isolated uncertainty bounds (INTERVAL_DISPERSION), and direct row swaps (ATTRIBUTION).'),
    ('INTERVAL_DISPERSION', 'Interval and distribution-summary coherence', '区间与分布摘要的数值一致性',
     'Confidence/credible intervals or distribution summaries have inconsistent bounds, order, location, precision, width, or cross-location values.',
     'Includes interval-endpoint sign/decimal typos and impossible median/IQR relations. Excludes diagnosed confidence-level/method misdefinition (ANALYSIS_DEFINITION); a central CI/P significance conflict is TEST_INFERENCE unless a localized bound defect is explicitly resolved.'),
    ('TEST_INFERENCE', 'P values and inferential consistency', 'P值与推断一致性',
     'Printed P values fail to reproduce, disagree with intervals, or contradict significance/decision-rule statements in the narrative.',
     'Includes false no-significance summaries and count of cases meeting a statistical decision rule. Excludes diagnosed undisclosed mixed methods (ANALYSIS_DEFINITION) and an otherwise correct inference with reversed directional wording (DIRECTION).'),
    ('DIRECTION', 'Contrast sign and benefit direction', '对比符号与获益方向',
     'The point-estimate sign, contrast order, favorable axis, inequality wording, or benefit/harm interpretation conflicts with the numerical contrast.',
     'Includes a locally dropped point sign regardless of severity. Excludes an isolated interval-endpoint sign (INTERVAL_DISPERSION) and transfers between treatment columns or outcome rows (ATTRIBUTION).'),
    ('ATTRIBUTION', 'Result attribution, swaps, and duplication', '结果归属、错置与复制',
     'The Notes identify values assigned to the wrong arm, outcome, row, or categorical bin, or copied from a different identified row/panel.',
     'A specifically identified source-to-destination mapping takes precedence over generic count, CI, or P inconsistency. Excludes population-stage naming alone (COUNT_DENOM), estimate/scale names (EFFECT_ESTIMAND), or merely suspected transfers with no specific mapping.'),
    ('ANALYSIS_DEFINITION', 'Analysis and measure definitions', '分析方法与测量定义',
     'Conflicting or missing definitions of models, tests, predictors, censoring, eligibility, confidence levels, priors, summary statistics, units, or questionnaire scoring.',
     'Includes explicitly diagnosed method/level mismatch even when first noticed via CI/P discordance. Effect-estimator identity goes to EFFECT_ESTIMAND; arithmetic analysis-population accounting goes to COUNT_DENOM.'),
]

# Each assignment below was made after reading the complete source Notes.
# Index is only a transport convenience; each expected stable key is checked below.
# Fields: index | category short code | confidence | secondary tags | rationale.
MANUAL = '''
0|D|high|sign_convention;cross_location|The residual definition and the caption reverse the same positive/negative interpretation.
1|D|high|localized_wording;conclusion_unchanged|The Note explicitly says the inequality wording is reversed while the noninferiority conclusion is correct.
2|I|high|recomputed_comparator;multiple_rows|Per-protocol confidence limits differ from the Note's reconstructed intervals; reproduced ITT rows serve only as comparators.
3|N|high|localized_typo;comparator_reproduces;direction_secondary|The retained defect is a printed percentage inconsistent with its count/denominator; the effect difference and P reproduce.
4|I|high|mirrored_bounds;comparator_reproduces|The affected interval limits look mirrored; the companion row is explicitly a successful comparator.
5|E|high|transposed_table;comparator_reproduces|The reported RRs identify a transposed conditional risk ratio rather than the stated between-arm risk ratio; P values are described as correct.
6|I|high|localized_typo;impossible_quartile|The third quartile is below the median; the suggested replacement is tentative, but the numerical defect is explicit.
7|M|high|test_name;cross_location|The same P value is attributed to Gray and log-rank tests without the Note adjudicating which was actually used.
8|N|high|wrong_denominator;comparator_reproduces|Four count/percentage pairs use 338 instead of the printed 388 denominator.
9|D|high|reciprocal_contrast;favors_axis|The forest ratios use the reciprocal arm contrast while its favorable-side labels retain the opposite interpretation.
10|I|high|precision;comparator_reproduces|The infection HR interval implies much greater precision than the event-based construction used successfully for comparator rows.
11|A|medium|pooled_counts;wrong_arm;uncertain_underlying_mapping|The Note identifies pooled therapy quantities assigned to treatment arms; its exact underlying therapy mapping is qualified as apparent.
12|D|high|localized_typo;cross_location|A point-estimate minus sign is omitted in the abstract while the body and reconstruction agree.
13|M|high|censoring_window;cross_location|The displayed follow-up extends beyond the stated censoring window; flat late curves limit the stated concern.
14|A|high|outcome_row_swap;comparator_reproduces|Entire RR/CI/P tuples are assigned to the opposite bleeding outcome; the RDs and supplemental P values are correct comparators.
15|A|high|outcome_identity;plotted_series|The Y line follows unfavorable cumulative counts despite its favorable-outcome designation; the X line reproduces.
16|N|high|count_percent_order;multiple_issues|Counts and percentages are transposed within count/percentage cells; a second cell also fails its arithmetic relation.
17|I|high|localized_typo;stray_token|A stray token interrupts an otherwise identifiable odds-ratio interval; this is not a broad interval-construction allegation.
18|N|high|count_as_percentage;cross_location|The abstract percentage conflicts with enrolled and completer counts; the Note suggests the count was printed as a percent.
19|P|high|decision_rule;judgment_stop_distinguished|Three stops are described as meeting a Bayesian rule although only two posterior probabilities meet it; the third was judgment based.
20|I|high|scale_bound;impossible_quartile|The printed upper quartiles exceed the explicitly stated 0–100 scale.
21|P|high|ci_p_discordance;direction_secondary;multiple_issues|The CI includes zero while P is significant; the Note separately identifies a contrary treatment-benefit interpretation.
22|D|high|contrast_order;comparator_reproduces|The lower-section contrast header reverses the differences represented by the printed numbers; the upper section is a distinct correct comparator.
23|P|high|ci_implied_p;inference_unchanged|The interval implies a P value about ten times larger than the printed value while retaining significance.
24|I|high|localized_typo;descending_bounds;point_outside|The placebo interval is descending and excludes its mean; the treatment contrast itself reproduces.
25|P|high|ci_p_discordance;asymmetry;comparator_reproduces|The effect matches period data but the interval includes zero and conflicts with the significant printed P.
26|I|high|point_outside;comparator_reproduces|The point estimate exceeds its interval upper bound while the treatment contrast reproduces.
27|P|high|ci_implied_p;inference_unchanged|The CI implies a larger P than the reported threshold, with no change to nominal significance.
28|N|high|missingness;wrong_denominator|Saturation denominators align with heart-rate rather than saturation missingness.
29|N|high|mixed_denominators;unstated_denominator|Nested percentages alternate between arm totals and medical subtotals without stating the denominator.
30|I|high|reversed_bounds;cross_location|The printed duration interval reverses its limits, while the supplemental interval supplies their coherent order.
31|N|high|population_stage;cross_location|The flow diagram assigns completer counts to the primary-analysis population, which the text and outcome table count differently.
32|P|medium|ci_p_discordance;precision;multiple_issues|The first identified problem is a death-difference CI crossing zero despite significant P; an implausibly precise adjacent HR is an additional interval issue.
33|D|medium|likely_sign_typo;comparator_reproduces|The Note diagnoses a likely point-sign error from the interval center and P, rather than asserting a generic CI-construction failure.
34|M|high|eligibility_threshold;cross_location;actual_process_uncertain|Online screening is described with incompatible BMI cutoffs; the Note leaves which cutoff was applied unresolved.
35|N|high|sample_size;factorial_cells|The stated total does not equal four cell sizes; the Note identifies confusion between main-effect arm size and total sample size.
36|A|medium|rotated_interval_limits;cross_row_mapping|The three upper CI limits appear rotated among specifically identified site rows; the Note qualifies the mechanism as apparent.
37|P|high|recomputed_p;summary_input_ambiguity;clinical_difference_small|The printed summaries cannot yield the stated Welch P; the Note leaves whether a summary or P was misreported unresolved.
38|N|high|wrong_denominator;comparator_reproduces|The affected percentage uses the other treatment column's denominator, whereas neighboring entries use the printed denominator.
39|I|high|localized_sign_typo;negated_broad_claim;rounding_explanation|The retained 12-month upper-limit defect is supported across locations; apparent 6-month conflicts are explicitly explained by rounding.
40|I|high|impossible_quartile;localized_typo|The median exceeds the upper quartile; the proposed corrected median remains only a suggestion.
41|A|medium|arm_label_swap;unresolved_residual;multiple_pairs|Most bar labels appear assigned to the opposite arm; the dessert discrepancy is explicitly not resolved by the swap.
42|N|high|complement_percentage;comparator_reproduces|Printed percentages are the complements of the count-based percentages; the counts reconcile with main-table totals.
43|A|high|treatment_column_swap;comparator_reproduces|Forest-plot counts are under opposite treatment headings; the mean changes remain correctly placed.
44|A|high|copied_panel_counts;cross_location|Omega-3 panels repeat vitamin-D participant counts despite distinct omega-3 counts in the table.
45|N|high|denominator_reconstruction;comparator_reproduces|Medication count/percent pairs fail against the nonmissing denominator range supported by neighboring rows.
46|N|high|population_accounting;cross_location|The table population and stated paired-sample inclusions/exclusions cannot share the reported total.
47|D|high|favors_axis;inference_unchanged|Active/placebo albuminuria ratios are given reversed benefit-side labels; all intervals still cross the null.
48|D|high|hr_interpretation;cross_location|The HR footnote reverses the benefit direction used in the report's numerical interpretation.
49|E|high|effect_label;cross_location;unresolved_derivation|An identical effect tuple receives RR and OR labels and matches neither crude calculation; the Note does not resolve its actual derivation.
50|I|high|localized_sign_typo;cross_location|A minus sign is lost from the abstract CI upper limit while the main table and reconstruction agree.
51|E|high|pooled_risk_estimand;multiple_rows|The reported risk-ratio column generally identifies an arm-to-pooled-risk ratio rather than the between-arm risk ratio.
52|N|high|mixed_denominators;comparator_reproduces|Printed percentages use blockade denominators while differences use the displayed denominators.
53|E|medium|sparse_nonestimability;ci_p_discordance;linked_candidate|The Note asserts that the finite narrow ratio is not estimable from the one-versus-zero counts and identifies a pooled-risk construction; CI/P discordance is secondary.
54|I|high|precision;asymmetry;effect_estimate_secondary;comparator_reproduces|The local claim concerns an asymmetric, excessively narrow mortality interval; the P matches the event counts while the effect also differs.
55|P|medium|ci_p_discordance;pooled_risk_estimand_secondary;linked_candidate|The focal row has a CI excluding the null with P above .05; the Note also links its estimate to the separately described pooled-risk construction.
56|D|high|localized_sign_typo;cross_location;direction_text_clear|Positive reported changes conflict with negative signed table estimates and the stated decrease; the Note identifies mixed sign convention.
57|P|high|cross_location;ci_implied_p;inference_unchanged|The same outcome/model/interval has conflicting printed P values with unchanged nominal inference.
58|N|high|pooled_percentage;count_reproduces|The death count and arm percentages reproduce; the pooled abstract percentage fails for the stated enrolled population.
59|N|high|count_percentage;population_total;multiple_issues|The Other-race percentage and race-count total fail to reconcile, with a one-person White-count discrepancy across locations.
60|N|high|analysis_population;cross_location|Follow-up MRI counts describe incompatible sizes of the post hoc infarct-growth population.
61|E|high|all_zero_nonestimability;comparator_reproduces|Finite risk ratios and intervals are printed for two all-zero subgroups, whereas other zero-cell rows are marked nonestimable.
62|A|high|ordinal_category_shift;plotted_distribution|Figure segment values fit a one-category shift in mRS labels rather than the printed bins.
63|D|high|narrative_curve_direction;cross_location|The text states increasing EVT probabilities while the plotted EVT curves decrease.
64|D|high|favors_axis;comparator_reproduces|The unfavorable-outcome RR is correctly favorable to EVT below one but the axis labels reverse that interpretation.
65|A|medium|treatment_arm_swap;disjoint_totals;multiple_issues|Favorable counts appear assigned to the wrong arms, producing impossible sums of disjoint outcomes; the attribution mechanism remains qualified.
66|M|high|test_population;method_reconstruction;inference_unchanged|The retention P values reproduce three-group tests including waitlist, contradicting the stated exclusion from significance tests.
67|I|high|log_symmetry;comparator_reproduces|A single weighted OR upper limit fails the log-symmetry relation followed by all other ratio cells.
68|N|high|population_header_swap;cross_location|Primary and per-protocol population-size headers appear exchanged; the counts identify the analysis populations.
69|N|high|population_count;likely_transcription;comparator_reproduces|A primary-analysis event count/percentage is copied from the per-protocol population even though the HR matches the primary analysis.
70|I|high|localized_sign_typo;point_outside;ci_p_discordance_secondary|The Note identifies a signed upper-bound error that puts the point outside its CI and makes the interval exclude zero.
71|N|high|localized_typo;category_total|N=50 fails the stated percentage and category total, while N=5 reconciles both.
72|E|high|empty_group_nonestimability;undisclosed_correction|Finite corrected odds ratios are shown despite an empty comparison group; the correction is identified but not described in the report.
73|M|high|mixed_ci_p_methods;undisclosed_method;ci_p_discordance_secondary|The Notes diagnose corrected Wald CIs paired with Fisher P values rather than the stated logistic model, so method identity is the primary mechanism.
74|N|high|population_stage;cross_location|The abstract uses the post-withdrawal population count as the number of infants with operative repair.
75|P|high|significance_summary;unadjusted_multiple_endpoints|A blanket no-significance summary contradicts a specified nominally significant secondary endpoint; the Note states no multiplicity adjustment.
76|M|high|confidence_level;cross_location|The same plotted/numeric limits are described as both 99% and 95% CIs, and the Note identifies their agreement with the 95% overall interval.
77|N|high|population_stage;multiple_issues|Analyzed and retained counts are mislabeled as randomized and completed counts in the abstract.
78|N|high|subgroup_partition;wrong_denominator|A subgroup denominator fails both percentage and complementary subgroup accounting; the Note proposes the denominator that reconciles them.
79|N|high|count_percentage;multiple_rows|Receiving-center percentages fail against printed counts and denominators even though the count totals reconcile.
80|N|high|localized_decimal_typo;category_total|The walk-in percentage is off by a decimal place while category totals confirm the count.
81|N|high|zero_numerator;denominator_transposition;multiple_issues|A positive percentage accompanies a zero count; another row has a mismatched denominator.
82|N|high|denominator_definition;population_exclusions;multiple_issues|Percentages represent shares of excluded patients rather than the printed denominators, with an additional exclusion-total discrepancy.
83|N|high|mixed_denominators;cross_location|A single allocation sentence switches denominators, causing inconsistent percentages.
84|I|high|cross_location;credible_interval|The abstract credible-interval lower bound differs from the values given in the Results and supplemental table.
85|D|high|benefit_reversal;point_sign;attribution_secondary;multiple_issues|The principal comparison reverses switching-versus-continuing benefit and effect sign; abstract intervention attribution is also inconsistent.
86|N|high|analysis_population;cross_location|The continuation analysis denominator excludes assigned participants in one location but includes them in the figure and other analyses.
87|E|high|risk_difference_vs_arm_rate;summary_misstatement|The narrative treats a between-arm risk difference as an arm event rate and misstates the continuation rate.
88|M|high|variance_vs_sd;prior_parameter|The stated variance and the printed odds interval imply different Normal prior parameterizations.
89|I|high|decimal_scale;cross_location;point_estimate_secondary|Several interval bounds and some point values have decimal-scale discrepancies against figures/tables; malformed interval ranges dominate the retained Note.
90|I|high|decimal_scale;cross_location;direction_ambiguous|The narrative credible interval has the wrong scale relative to the table; the Note additionally leaves contrast sign ambiguous.
91|D|high|point_sign;cross_location;undefined_contrast|One summary flips the point sign while keeping the CI; the Note notes the convention is unstated but reconstructs the dominant contrast.
92|N|high|unit_to_percentage;localized_decimal_typo|The mg/g-to-percent conversion is wrong by a factor of ten in one location.
93|M|high|questionnaire_scoring;item_count|The stated item count and response description conflict with the scoring ranges and resulting total.
94|E|medium|contrast_arithmetic;multiple_rows;copied_values_secondary|Several reported contrasts fail the arm-change arithmetic used elsewhere; one row also duplicates another outcome's arm values.
95|A|high|treatment_arm_swap;cross_location;residual_count_discrepancy|Several adverse-event counts are assigned to opposite arms in the main table; one additional count difference does not fit a swap.
96|M|medium|event_relatedness_definition;cross_location|The report gives incompatible classifications of SAE relatedness, so the issue is the reported classification/definition rather than effect arithmetic.
97|I|high|copied_interval_suspected;negated_broad_claim;shared_coefficients_explanation|The retained fasting-glucose interval is implausibly wide and duplicates hsCRP; the Note explicitly rejects the separate WOMAC width allegation as insufficient.
98|N|high|pooled_denominator;arm_percentages|Both arms display pooled percentages instead of their own count-based proportions.
99|P|high|significance_summary;unadjusted_multiple_endpoints|The no-quality-of-life-difference summary contradicts a significant planned day-specific contrast described without multiplicity correction.
100|M|high|covariate_set;actual_model_uncertain|Two descriptions of the same Cox model differ by sex; the Note cannot determine the fitted model.
101|E|medium|cross_location;interval_secondary;multiple_issues|Model mortality-rate estimates conflict across locations, with additional slope credible-limit differences; the source Note does not resolve which values are correct.
102|N|high|event_vs_exclusion;population_accounting|The text describes four events as exclusions, producing a population-accounting discrepancy.
103|E|high|effect_scale;back_transformation;interval_secondary|A serum contrast is labeled percent change but remains on the log-times-100 scale; an additional CI asymmetry is noted separately.
104|N|high|count_percentage;comparator_reproduces|The adherence percentage fails the stated randomized denominator while neighboring percentages reproduce.
105|E|high|smd_construction;point_sign_secondary;timepoint_attribution_secondary;multiple_issues|Reported SMDs cannot share the prescribed within-row SD; opposite signs and misattributed time-point values provide additional discrepancies.
106|I|high|nnt_nnh_infinity;lost_sign;interval_semantics|Finite positive NNT bounds omit the NNH sign and hide a confidence set passing through infinity; the Note distinguishes this from ordinary positive bounds.
107|I|high|nnt_nnh_infinity;lost_sign;linked_candidate|The apparent out-of-interval NNT is explained by a missing NNH sign and an interval passing through infinity, as in the linked candidate.
108|I|high|point_outside;descending_bounds;null_coverage;multiple_cells|Many SMD points fall outside CIs, bounds descend, and interval null coverage conflicts with the corresponding MD intervals.
109|M|high|covariate_set;subset_model|Subset analyses are described as restricted primary analyses but omit covariates from the stated primary model.
110|M|high|predictor_membership;cross_location|The listed response-weight predictors include education while the fitted model contains employment instead.
111|M|medium|categorical_coding;duplicated_label_secondary;multiple_issues|The declared binary education coding conflicts with three nonreference terms; a duplicated term label is an additional attribution issue.
112|M|high|confidence_level;one_se_vs_95ci;negated_comparator_claim|The Note diagnoses intervals near one SE rather than 95% CIs; separate ratio-row apparent conflicts are explicitly compatible with rounding.
113|N|high|population_stage;followup_counts|Randomized counts are labeled as three-month counts and exceed the number with any follow-up.
114|M|medium|summary_statistic_identity;arm_order_secondary;multiple_issues|The table labels median/IQR while text and narrow bounds support mean/CI; a likely treatment-column permutation is a separate substantial issue.
115|N|high|count_percentage;comparator_reproduces|The depression percentage fails its nonmissing denominator while the count and neighboring columns reconcile.
116|M|high|undefined_scoring;undefined_direction;cross_location_secondary|A single PROMIS-29 aggregate is reported without its aggregation, transformation, or favorable direction despite mixed-direction domains.
117|M|high|exact_vs_wald;method_reconstruction|Intervals labeled exact reproduce log-Wald intervals rather than exact conditional intervals.
118|N|high|count_percentage;comparator_reproduces|Two exposure percentages fail the common participant denominator while the other rows reproduce.
119|M|high|covariate_set;cross_location|Descriptions of the same primary model disagree about adjustment for center.
120|E|high|logistic_to_rr;unreported_conversion;cross_location|The report gives RRs from logistic models without a conversion and contradictory crude/unadjusted effect estimates for the same outcome.
121|D|high|narrative_direction;severity_threshold|The prose reverses the any-symptom comparison; moderate/severe symptoms are a different threshold and do not justify that direction statement.
122|I|high|localized_decimal_typo;mixed_precision;negated_broad_claim|The Note explicitly rejects asymmetry alone as proof of error and retains a 42-versus-4.2 upper-limit typo plus inconsistent precision.
123|N|high|count_percentage;rounding_secondary|Two cause-of-death percentages fail the common denominator; small rounding slips are additional descriptive errors.
124|N|high|wrong_percentage;count_total_reproduces|The site death percentage fails the stated cluster size while site counts sum to the correct total.
125|D|high|inconsistent_contrast_order;multiple_rows|Death and failure differences reverse the mHealth-minus-usual-care sign used in other rows.
126|E|high|localized_point_typo;interval_reproduces|The Note specifically resolves the point estimate as a typographic error using counts and an otherwise matching CI.
127|D|high|nnh_vs_nnb;benefit_harm|A risk reduction is called number needed to harm although the same reciprocal magnitude represents benefit.
128|I|high|nnt_nnh_infinity;null_coverage|Finite NNH bounds are incompatible with underlying risk-difference intervals crossing zero, which require a confidence set through infinity.
129|P|high|recomputed_p;comparator_reproduces;inference_unchanged|Several subgroup P values fail the companion-row Fisher reconstruction; none change nominal significance.
130|P|medium|ci_p_estimate_tuple;possible_cell_transposition|The coefficient/CI/P tuple is inconsistent; a cell transposition is suggested but no complete source-to-destination swap is established.
131|E|high|localized_point_typo;comparator_reproduces|The point is a decimal/significant-digit typo: count-based OR, CI and P together support 1.11 rather than 0.11.
132|M|high|quantity_units;person_time_vs_rate|A column labeled rate actually contains person-time in hundreds, so the reported quantity and unit are misdefined.
133|P|high|recomputed_p;comparator_reproduces|The chronotype P does not reproduce from the counts while other test rows do.
134|A|high|duplicated_row;impossible_total|The Other ethnicity row repeats the specifically identified White row, which inflates category totals.
135|P|high|identical_counts_different_p;unresolved_source_value|Identical count tables have different P values, leaving either counts or one P incorrect without a resolved source cell.
136|N|high|count_percentage;comparator_reproduces|The ARB percentage fails its printed fraction while neighboring fractions reproduce.
137|N|high|sample_bound;subpopulation|The sample size claimed for a unilateral-only measurement exceeds the unilateral population in both arms.
138|M|high|censoring_time;cross_location|The same missing-duration censoring rule is reported as one hour and one day across tables.
'''.strip()

short = dict(N='COUNT_DENOM', E='EFFECT_ESTIMAND', I='INTERVAL_DISPERSION', P='TEST_INFERENCE', D='DIRECTION', A='ATTRIBUTION', M='ANALYSIS_DEFINITION')
taxonomy = {
    'version': 'v1',
    'status': 'provisional_manual_semantic_coding_for_independent_audit',
    'created_date': '2026-10-22',
    'source': str(SOURCE.relative_to(BASE.parent.parent)),
    'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'unit': 'One final-human-confirmed statistical candidate, not one unique underlying defect or paper.',
    'selection': 'Copied final human-reviewed workbook labels: retain, statistical_results, confirmed_issue; frozen report relationship S_C or S_W.',
    'provenance': 'Notes were authored in earlier R_Bulun Claude Opus 5.5 high AI reviewer runs. Subsequent human-reviewed copied workbook labels are authoritative for selection and substantive status. This coding is semantic analysis of those earlier Notes, not independent verification of trial errors.',
    'categories': [dict(code=c, label_en=e, label_zh=z, inclusion=i, exclusion_and_boundary=x) for c,e,z,i,x in CATEGORIES],
    'primary_selection_rules': [
        'Read the full Notes, including negation and qualifying explanations; titles supply context only. Do not import judgments.json or other rationales.',
        'Choose the mechanism supported by the retained claim. Successful comparator rows and rejected broader allegations are not issues to be coded.',
        'A specifically identified row, arm, outcome, or bin transfer takes ATTRIBUTION over a generic numeric discrepancy; mere suspected copying does not.',
        'Point-contrast sign or benefit interpretation takes DIRECTION; isolated interval-endpoint signs remain INTERVAL_DISPERSION.',
        'Population-stage counts and headers remain COUNT_DENOM; effect-estimator/scale identity is EFFECT_ESTIMAND; model/test/scoring/summary-statistic identity is ANALYSIS_DEFINITION.',
        'An explicitly diagnosed confidence-level or CI/P method mismatch takes ANALYSIS_DEFINITION over a generic inferential contradiction.',
        'For genuinely independent issues bundled in one candidate, choose the central retained issue from the full note, record secondary mechanisms and multiple_issues, and lower confidence where primary selection remains contestable.',
        'Local transcription/formatting is a secondary tag; it does not replace a statistical mechanism category or determine severity.',
        'If no supported primary mechanism is recoverable, use UNCLASSIFIABLE with the reason. Do not infer a category from a title alone.',
    ],
    'substantive_status': 'Copied without change from final human-reviewed labels; never inferred from category, wording, or confidence.',
    'confidence': {'high': 'Mechanism is directly supported by the full Notes; certainty concerns classification, not truth of the alleged trial error.', 'medium': 'Primary choice has competing mechanisms or relies on an explicitly tentative diagnostic mapping.', 'low': 'Mechanism is weakly supported; retain explicit uncertainty rather than invent specificity.'},
    'secondary_tags': 'Optional descriptive tags may overlap. They are not mutually exclusive issue counts and must not be summed as candidates.',
    'periods': {'earlier': [2018, 2019], 'later': [2024, 2025]},
    'limitations': ['Candidate records may overlap in underlying cause, especially explicitly linked candidates.', 'Four sampled publication years are available, not a continuous annual series.', 'Counts profile confirmed candidate records and do not estimate prevalence among all trials.', 'A narrative explanation in an earlier AI note is evidence for coding its meaning, not newly verified evidence of a trial error.'],
}

definitions = {r['code']: r for r in taxonomy['categories']}
assignments = {}
for line in MANUAL.splitlines():
    index, category, confidence, tags, rationale = line.split('|', 4)
    assignments[int(index)] = (short[category], confidence, tags.split(';'), rationale)
assert set(assignments) == set(range(len(rows))), (len(assignments), len(rows))
assert len(rows) == 139 and sum(r['is_confirmed_substantive'] for r in rows) == 37

output = []
for index, row in enumerate(rows):
    category, confidence, tags, rationale = assignments[index]
    assert row['key'] == f"{row['year']}::{row['paper']}::{row['candidate']}"
    assert row['notes'] and hashlib.sha256(row['notes'].encode()).hexdigest() == row['notes_sha256_utf8']
    rec = {
        'key': row['key'], 'year': row['year'], 'period': '2018–2019' if row['year'] < 2020 else '2024–2025',
        'paper': row['paper'], 'candidate': row['candidate'], 'title_context_only': row['title'],
        'primary_category': category, 'primary_category_label': definitions[category]['label_en'],
        'confidence': confidence, 'secondary_tags': tags, 'coding_rationale': rationale,
        'supporting_excerpt': row['notes'], 'supporting_excerpt_scope': 'Entire verbatim Notes cell retained to preserve negations and comparator explanations.',
        'final_disposition': row['final_disposition'], 'final_domain': row['final_domain'],
        'final_issue': row['final_issue'], 'final_substantiveness': row['final_substantiveness'],
        'substantiveStatus': row['final_substantiveness'], 'final_impact': row['final_impact'],
        'is_confirmed_substantive': row['is_confirmed_substantive'],
        'relationship': row['relationship'], 'source_workbook': row['source_workbook'],
        'sheet': row['sheet'], 'excel_row': row['excel_row'], 'notes_cell': row['notes_cell'],
        'notes_sha256_utf8': row['notes_sha256_utf8'], 'source_sha256': row['source_sha256'],
        'copy_workbook': row['copy_workbook'], 'copy_sha256': row['copy_sha256'],
        'notes_author_type': row['notes_author_type'], 'notes_author_model': row['notes_author_model'],
        'notes_author_reasoning_effort': row['notes_author_reasoning_effort'],
        'final_labels_source': row['final_labels_source'], 'coding_version': 'v1',
        'coding_method': 'manual_full_note_semantic_reading', 'independent_trial_verification': False,
    }
    output.append(rec)

(BASE / 'taxonomy_v1.json').write_text(json.dumps(taxonomy, indent=2, ensure_ascii=False) + '\n')
(BASE / 'semantic_coding_v1.json').write_text(json.dumps(output, indent=2, ensure_ascii=False) + '\n')
with (BASE / 'semantic_coding_v1.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(output[0]))
    writer.writeheader()
    for row in output:
        writer.writerow({**row, 'secondary_tags': ';'.join(row['secondary_tags'])})

counts = Counter(r['primary_category'] for r in output)
sub = Counter(r['primary_category'] for r in output if r['is_confirmed_substantive'])
decisions = [
    'SEMANTIC CODING V1 — MANUAL FULL-NOTE REVIEW',
    '',
    'Read all 139 eligible full Notes. All have classifiable semantic content; no empty/unsupported category was inferred from a title.',
    '37 substantive and 102 minor_presentation labels are retained exactly from the final human-reviewed copies.',
    'Raw Notes authorship: Claude Opus 5.5 high AI reviewer runs. Later human confirmation does not make the Notes human-authored.',
    'Evidence excerpts retain the entire exact Notes cell, so rejected claims and comparators remain visible.',
    'This analysis recategorizes candidate mechanisms; it does not re-adjudicate or independently verify published trial errors.',
    '',
    'PROVISIONAL PROFILE (candidate counts; not independent unique defects):',
]
for c,e,_,_,_ in CATEGORIES:
    decisions.append(f'{c}: {counts[c]} total; {sub[c]} substantive. {e}.')
decisions.extend(['', 'DECISION LOG (candidate-specific rationale and caveats):'])
for row in output:
    decisions.append(f"{row['key']} | {row['primary_category']} | {row['confidence']} | final={row['final_substantiveness']} | {row['coding_rationale']} Tags: {', '.join(row['secondary_tags'])}")
(BASE / 'semantic_coding_decisions.txt').write_text('\n'.join(decisions) + '\n')
print(json.dumps({'records': len(output), 'substantive': sum(r['is_confirmed_substantive'] for r in output), 'category_counts': counts, 'substantive_counts': sub, 'confidence': Counter(r['confidence'] for r in output)}, indent=2))
