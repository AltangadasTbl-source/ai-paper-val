#!/usr/bin/env Rscript
# Run from paper_writting/main. Standalone descriptive extension; original endpoints unchanged.
options(stringsAsFactors = FALSE)
Sys.setenv(TZ='America/Phoenix')
suppressPackageStartupMessages(library(readxl))
out <- 'analysis/domain_comparisons'
dir.create(out, recursive = TRUE, showWarnings = FALSE)
years <- c(2018L, 2019L, 2024L, 2025L)
cols <- c('key','title','source_location','disposition','domain','complete',
          'validation_hint','issue','substantiveness','impact','internal','protocol',
          paste0('unused',13:17),'notes')
read_collection <- function(final_copy=TRUE) {
pieces <- list()
for (year in years) {
  path <- if(final_copy) sprintf('review_results_2_4_1_Rbulun_copy/human_adjudication_v_2_4_1_%s_R_Bulun_completed.xlsx',year) else
    sprintf('reviewer_runs_raw/%s/R_Bulun/human_adjudication_v_2_4_1_%s_R_Bulun_completed.xlsx',year,year)
  ix <- as.data.frame(read_excel(path,sheet='Papers',col_types='text'))
  ix <- ix[!is.na(ix[[1]]) & nzchar(ix[[1]]),1:3]
  names(ix) <- c('paper','sheet','expected')
  for (i in seq_len(nrow(ix))) {
    x <- as.data.frame(suppressMessages(read_excel(path,sheet=ix$sheet[i],range=cell_cols('A:R'),col_types='text')))
    names(x) <- cols; x[is.na(x)] <- ''; x <- x[nzchar(x$key),]
    stopifnot(nrow(x)==as.integer(ix$expected[i]))
    x$year <- year; x$paper <- ix$paper[i]; x$source <- path
    x$sheet <- ix$sheet[i]; x$excel_row <- seq_len(nrow(x))+1L
    pieces[[length(pieces)+1L]] <- x
  }
}
result <- do.call(rbind,pieces); rownames(result) <- NULL; result
}
d <- read_collection(TRUE)
raw <- read_collection(FALSE)
sources <- unique(c(d$source,raw$source))
old <- read.csv('analysis/candidate_results.csv',na.strings=NULL)
p <- read.csv('analysis/paper_results.csv',na.strings=NULL)
prov <- read.csv('analysis/candidate_provenance.csv',na.strings=NULL)
stopifnot(nrow(d)==440L,!anyDuplicated(d$key),nrow(p)==44L,!anyDuplicated(p$paper),
          setequal(d$key,old$key),setequal(d$paper,p$paper),all(d$complete=='primary_done'))
mm <- match(d$key,old$key); pm <- match(d$key,prov$key); stopifnot(!anyNA(pm))
d$original_domain <- prov$domain[pm]; d$relationship <- prov$relationship_type[pm]
d$report_relationship <- d$relationship %in% c('S_C','S_W')
d$period <- ifelse(d$year<2020,'2018--2019','2024--2025')
judgment_fields <- c('disposition','domain','complete','issue','substantiveness','impact','internal','protocol','notes')
discrepancies <- data.frame(key=character(),field=character(),final_workbook=character(),existing_csv=character())
for (field in judgment_fields) {
  bad <- which(d[[field]] != old[[field]][mm])
  if(length(bad)) discrepancies <- rbind(discrepancies,data.frame(key=d$key[bad],field,
    final_workbook=d[[field]][bad],existing_csv=old[[field]][mm][bad]))
}
write.csv(discrepancies,file.path(out,'judgment_discrepancies.csv'),row.names=FALSE)
raw_discrepancies <- data.frame(key=character(),field=character(),raw_workbook=character(),final_workbook=character())
rm <- match(d$key,raw$key); stopifnot(!anyNA(rm),setequal(d$key,raw$key))
for (field in judgment_fields) {
  bad <- which(d[[field]] != raw[[field]][rm])
  if(length(bad)) raw_discrepancies <- rbind(raw_discrepancies,data.frame(key=d$key[bad],field,
    raw_workbook=raw[[field]][rm][bad],final_workbook=d[[field]][bad]))
}
write.csv(raw_discrepancies,file.path(out,'raw_vs_final_discrepancies.csv'),row.names=FALSE)
ret <- d$disposition=='retain'
report <- ret & d$domain=='report_internal_inconsistency'
plan <- ret & d$domain=='plan_material'
protocol <- ret & d$domain=='protocol_report'
established <- d$internal %in% c('substantive_inconsistency','minor_presentation')
substantive <- d$internal=='substantive_inconsistency'
flags <- list(report_retained=report, report_established=report & established,
              report_substantive=report & substantive,
              report_substantive_SC_SW=report & substantive & d$report_relationship,
              plan_retained=plan, plan_established=plan & established,
              plan_substantive=plan & substantive,
              protocol_retained=protocol,
              protocol_substantive_difference=protocol & d$protocol=='substantive_difference',
              protocol_missing_L=protocol & d$protocol=='')
# Recompute and check the ORIGINAL endpoints; do not redefine or overwrite them.
st <- ret & d$domain=='statistical_results'
original_primary <- st & d$report_relationship & d$issue %in% c('confirmed_issue','probable_issue') & d$substantiveness=='substantive'
original_strict <- original_primary & d$issue=='confirmed_issue'
if(nrow(discrepancies)==0L) {
  stopifnot(identical(original_primary,old$primary[mm]),identical(original_strict,old$strict[mm]),
            identical(flags$report_substantive_SC_SW,old$secondary[mm]))
}
paper <- p[c('year','paper','period')]
for (metric in names(flags)) {
  d[[metric]] <- flags[[metric]]
  paper[[metric]] <- vapply(paper$paper,function(id)sum(flags[[metric]][d$paper==id]),integer(1))
}
write.csv(d,file.path(out,'candidate_domain_results.csv'),row.names=FALSE)
write.csv(paper,file.path(out,'paper_domain_results.csv'),row.names=FALSE)
write.csv(d[d$domain!=d$original_domain,c('key','original_domain','domain','relationship','internal','protocol')],
          file.path(out,'domain_edits.csv'),row.names=FALSE)
write.csv(d[flags$report_substantive & !d$report_relationship,c('key','original_domain','domain','relationship','internal')],
          file.path(out,'report_substantive_extension_only.csv'),row.names=FALSE)

# Exact two-sided paper-label permutation distribution via integer-subset-sum DP.
exact_mean_permutation <- function(x,earlier) {
  stopifnot(all(x>=0),all(x==round(x)),length(x)==length(earlier))
  n <- length(x); k <- sum(earlier); total <- sum(x)
  dp <- matrix(0,k+1,total+1); dp[1,1] <- 1; seen <- 0L
  for (v in x) {
    for (j in seq.int(min(k,seen+1L),1L)) {
      s <- 0:(total-v)
      dp[j+1L,s+v+1L] <- dp[j+1L,s+v+1L]+dp[j,s+1L]
    }
    seen <- seen+1L
  }
  weights <- dp[k+1L,]; denom <- choose(n,k)
  stopifnot(abs(sum(weights)/denom-1)<1e-10)
  observed <- mean(x[!earlier])-mean(x[earlier])
  null <- (total-(0:total))/(n-k)-(0:total)/k
  c(difference=observed,p=sum(weights[abs(null)>=abs(observed)-1e-12])/denom)
}
toy <- c(0,0,1,1,3,4); early_toy <- seq_along(toy)<=3
obs <- mean(toy[!early_toy])-mean(toy[early_toy])
brute <- combn(seq_along(toy),3,function(i)mean(toy[-i])-mean(toy[i]))
stopifnot(abs(exact_mean_permutation(toy,early_toy)['p']-mean(abs(brute)>=abs(obs)-1e-12))<1e-12,
          exact_mean_permutation(rep(0,44),seq_len(44)<=19)['p']==1)
earlier <- paper$year<2020
stopifnot(sum(earlier)==19L,sum(!earlier)==25L,identical(paper$paper,p$paper))
RNGkind('Mersenne-Twister','Inversion','Rejection'); set.seed(20261022)
B <- 20000L
boot_early <- replicate(B,sample(which(earlier),sum(earlier),replace=TRUE))
boot_later <- replicate(B,sample(which(!earlier),sum(!earlier),replace=TRUE))
rows <- list()
for (metric in names(flags)) for (scale in c('count','any')) {
  x <- paper[[metric]]; if(scale=='any')x <- as.integer(x>0)
  test <- exact_mean_permutation(x,earlier)
  bootdiff <- colMeans(matrix(x[boot_later],nrow=sum(!earlier)))-colMeans(matrix(x[boot_early],nrow=sum(earlier)))
  ci <- quantile(bootdiff,c(.025,.975),names=FALSE,type=7)
  rows[[length(rows)+1L]] <- data.frame(metric,scale,early_n=19,late_n=25,
    early_total=sum(x[earlier]),late_total=sum(x[!earlier]),early_mean=mean(x[earlier]),late_mean=mean(x[!earlier]),
    difference=unname(test['difference']),lower=ci[1],upper=ci[2],p=unname(test['p']))
}
cmp <- do.call(rbind,rows)
existing_cmp <- read.csv('analysis/period_comparisons.csv')
check_fields <- c('scale','early_total','late_total','early_mean','late_mean','difference','lower','upper','p')
stopifnot(isTRUE(all.equal(cmp[cmp$metric=='report_substantive_SC_SW',check_fields],
  existing_cmp[existing_cmp$metric=='secondary',check_fields],check.attributes=FALSE)))
write.csv(cmp,file.path(out,'period_domain_comparisons.csv'),row.names=FALSE)
labels <- c(report_established='Report: established inconsistency',report_substantive='Report: substantive subset',
            protocol_retained='Protocol-report: all retained differences',protocol_substantive_difference='Protocol-report: substantive differences',
            plan_established='Plan: established inconsistency',plan_substantive='Plan: substantive subset')
fmt <- function(x,digits=2) formatC(ifelse(abs(x)<.5*10^-digits,0,x),format='f',digits=digits)
slides <- list()
for (scale in c('count','any')) {
  z <- cmp[cmp$scale==scale,]; z <- z[match(names(labels),z$metric),]
  factor <- if(scale=='any')100 else 1
  a <- if(scale=='count')paste0(fmt(z$early_mean),' [',z$early_total,']') else paste0(z$early_total,'/19 (',fmt(100*z$early_mean,1),'%)')
  b <- if(scale=='count')paste0(fmt(z$late_mean),' [',z$late_total,']') else paste0(z$late_total,'/25 (',fmt(100*z$late_mean,1),'%)')
  tab <- data.frame(Outcome=unname(labels),Earlier=a,Later=b,
    Difference_CI=paste0(fmt(factor*z$difference),' (',fmt(factor*z$lower),', ',fmt(factor*z$upper),')'),P=fmt(z$p,3))
  write.csv(tab,file.path(out,paste0('slide_table_',scale,'.csv')),row.names=FALSE)
  slides[[scale]] <- c(if(scale=='count')'SLIDE 1: Mean counts per paper [total candidates]' else 'SLIDE 2: Papers with at least one finding, n/N (%)',
                      'Earlier: publication cohorts 2018-2019 (n=19); later: 2024-2025 (n=25).',
                      paste('Outcome','Earlier','Later','Later minus earlier (95% CI)','Exact P',sep=' | '),
                      apply(tab,1,paste,collapse=' | '),
                      if(scale=='count')'Difference units: findings per paper.' else 'Difference units: percentage points.')
}
notes <- c('OTHER THREE REVIEW DOMAINS: DESCRIPTIVE PUBLICATION-PERIOD EXTENSION',
  'Authoritative source: review_results_2_4_1_Rbulun_copy/*R_Bulun_completed.xlsx, read directly with R readxl.',
  'The user confirms these copied workbooks contain later HUMAN-reviewed final decisions. The earlier reviewer_runs_raw workbooks were produced by Claude Opus 5.5 high agent sessions; their rationales are AI-origin evidence, not human rationales.',
  sprintf('Validation: %d candidate rows, 44 papers; %d discrepancies across %d judgment fields versus analysis/candidate_results.csv.',nrow(d),nrow(discrepancies),length(judgment_fields)),
  'Compared fields: D disposition, E final domain, F completion, H issue, I substantiveness, J impact, K internal, L protocol, R notes.',
  sprintf('Raw AI versus final human workbooks: %d differing cells, including %d decision-code cells and %d notes cells; see raw_vs_final_discrepancies.csv.',nrow(raw_discrepancies),sum(raw_discrepancies$field!='notes'),sum(raw_discrepancies$field=='notes')),
  'Use recorded publication cohort year, not DOI year. All 44 papers contribute, including zero counts.',
  '',slides$count,'',slides$any,'',
  'ENDPOINTS AND SCOPE',
  'Every endpoint requires D=retain and uses the FINAL E domain.',
  'Report/plan established inconsistency: K=substantive_inconsistency or minor_presentation; substantive subset: K=substantive_inconsistency only.',
  'Retained candidates coded indeterminate/non_inconsistency are not established inconsistencies.',
  'Protocol-report all retained includes every L state; substantive difference requires L=substantive_difference. These are differences, not confirmed errors.',
  'L is optional: missing in 2/102 earlier and 3/112 later retained protocol-report candidates. A blank L does not enter the substantive-difference subset.',
  'Descriptive extension explicitly includes original P_R/P_P relationships and domain-edited cases. It is NOT the existing report-only secondary endpoint.',
  'Original primary/strict statistical and S_C/S_W report-only restrictions are preserved; no original files were rewritten.',
  'Validation reproduces the original report-only secondary counts, exact P values and bootstrap confidence limits on both scales.',
  'Report substantive extension totals 1 earlier + 4 later = 5; S_C/S_W sensitivity totals 1 earlier + 3 later = 4.',
  'The additional case is listed in report_substantive_extension_only.csv. Domain edits are listed in domain_edits.csv.',
  'All retained report candidates: 4 earlier, 8 later; established: 3 and 8 (one earlier indeterminate).',
  'All retained plan candidates: 12 earlier, 20 later; established: 12 and 17 (three later indeterminate).',
  '', 'METHOD',
  'Effects are later minus earlier. Exact two-sided paper-label permutation tests use all allocations of 19 of 44 papers and absolute mean differences, retaining ties.',
  '95% percentile bootstrap intervals: 20,000 independent within-period paper resamples, seed 20261022; original analysis/paper_results.csv paper order.',
  'Any-finding tests use binary paper outcomes. P-values are exploratory, unadjusted, and descriptive; no confirmatory family was declared.',
  '', 'INTERPRETATION',
  'This is an availability-selected comparison of publication cohorts before the pandemic and in a later period; it does not estimate a pandemic effect.',
  'Detected counts depend on AI candidate generation, document availability, final domain assignment and human adjudication. Endpoint changes must not be read as changes in research quality.',
  'Intervals quantify paper-resampling uncertainty conditional on this candidate set and final review; they do not incorporate missed findings or adjudication uncertainty.',
  'Sparse report/plan substantive endpoints require caution. Protocol-report retained/substantive counts are descriptive differences and cannot be pooled with confirmed reporting errors.',
  '', 'ALL COMPARISONS (unrounded machine-readable values in period_domain_comparisons.csv)',capture.output(cmp))
writeLines(notes,file.path(out,'slide_ready_results.txt'))
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
all_sources <- c(sources,'analysis/candidate_results.csv','analysis/paper_results.csv','analysis/candidate_provenance.csv','analysis/period_comparisons.csv')
write.csv(data.frame(path=all_sources,md5=unname(tools::md5sum(all_sources))),file.path(out,'input_hashes.csv'),row.names=FALSE)
cat(paste(notes[1:6],collapse='\n'),'\n'); print(cmp)
