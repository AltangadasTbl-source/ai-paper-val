#!/usr/bin/env Rscript
dir.create('slides/figures',showWarnings=FALSE)
y <- read.csv('slides/data/year_summary.csv')
c <- read.csv('slides/data/period_comparisons.csv')
navy <- '#17324D'; teal <- '#007F82'; blue <- '#4178B5'; gray <- '#586878'
pdf('slides/figures/annual_rates.pdf',width=8.4,height=3.7,family='Helvetica',useDingbats=FALSE)
par(mar=c(3.3,3.6,.8,.5),mgp=c(2.1,.5,0),las=1,bty='n',fg=navy,col.axis=gray,col.lab=gray)
mat <- rbind(y$all_mean,y$substantive_mean)
xx <- barplot(mat,beside=TRUE,col=c(blue,teal),border=NA,ylim=c(0,5.25),axes=FALSE,
 names.arg=paste0(y$year,'\n(n = ',y$papers,')'),ylab='Confirmed issues per paper',cex.names=.95)
axis(2,at=0:5,tick=FALSE)
abline(h=0,col='#C4CDD5')
text(as.vector(xx),as.vector(mat)+.18,sprintf('%.2f',as.vector(mat)),cex=.9,col=navy)
legend('topright',legend=c('Confirmed all','Confirmed substantive'),fill=c(blue,teal),border=NA,bty='n',cex=.95)
dev.off()

pdf('slides/figures/period_differences.pdf',width=9.3,height=2.65,family='Helvetica',useDingbats=FALSE)
par(mar=c(3.4,1.0,.4,.5),mgp=c(2.1,.5,0),las=1,bty='n',fg=navy,col.axis=gray,col.lab=gray)
z <- c[c$scale=='count' & c$metric %in% c('confirmed_all','confirmed_substantive'),]
plot(NA,xlim=c(-1.65,2.4),ylim=c(.5,2.5),xaxt='n',yaxt='n',xlab='Later minus earlier: issues per paper (95% bootstrap CI)',ylab='')
abline(v=0,col='#A9B5C0',lty=2)
axis(1,at=seq(-1.5,2,.5),tick=FALSE)
for(i in 1:2){
 yy <- 3-i; cc <- c(blue,teal)[i]
 segments(z$lower[i],yy,z$upper[i],yy,lwd=3,col=cc)
 segments(c(z$lower[i],z$upper[i]),yy-.08,c(z$lower[i],z$upper[i]),yy+.08,col=cc,lwd=2)
 points(z$difference[i],yy,pch=21,bg=cc,col='white',cex=1.65)
 text(-1.6,yy+.31,c('Confirmed all','Confirmed substantive')[i],adj=0,cex=1,col=cc)
 diff <- sprintf(if(abs(z$difference[i])<.005) '%+.3f' else '%+.2f',z$difference[i])
 text(2.35,yy+.31,sprintf('%s [%+.2f, %+.2f];  P = %.3f',diff,z$lower[i],z$upper[i],z$p[i]),adj=1,cex=.92,col=navy)
}
dev.off()
