#!/usr/bin/env python3
"""Check presentation structure, layout, source codebooks and new exact tests."""
import csv
import hashlib
import json
import math
import re
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from zipfile import ZipFile

import pymupdf as fitz

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}

def read_csv(path):
    with path.open() as f:
        return list(csv.DictReader(f))

# Compare actual workbook codebooks with the snapshot used to read definitions.
snapshot = json.loads((ROOT / 'analysis/workbook_cells.json').read_text())
inputs = []
for path in sorted((ROOT / 'review_results_2_4_1_Rbulun_copy').glob('*.xlsx')):
    with ZipFile(path) as z:
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        sheet = next(s for s in wb.find('s:sheets', NS) if s.attrib['name']=='Codebook')
        rid = sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target = next(r.attrib['Target'] for r in rels if r.attrib['Id']==rid)
        target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
        shared = []
        if 'xl/sharedStrings.xml' in z.namelist():
            shared = [''.join(s.itertext()) for s in ET.fromstring(z.read('xl/sharedStrings.xml'))]
        cells = []
        for row in ET.fromstring(z.read(target)).find('s:sheetData',NS):
            record = {}
            for cell in row:
                value = cell.find('s:v',NS)
                kind = cell.attrib.get('t')
                if kind=='inlineStr':
                    text = ''.join(cell.find('s:is',NS).itertext())
                elif value is not None:
                    text = shared[int(value.text)] if kind=='s' else value.text
                else:
                    continue
                if text is not None:
                    record[cell.attrib['r']] = text
            if record:
                cells.append(record)
        assert cells==snapshot[path.name]['Codebook'], path.name
    inputs.append({'path':str(path.relative_to(ROOT)), 'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})

p = read_csv(HERE / 'data/paper_results.csv')
c = read_csv(HERE / 'data/period_comparisons.csv')
def check_permutations(papers, comparisons):
    for result in comparisons:
        values = [int(q[result['metric']]) for q in papers]
        if result['scale']=='any':
            values = [int(v>0) for v in values]
        dp = [Counter() for _ in range(20)]
        dp[0][0] = 1
        for v in values:
            for k in range(19,0,-1):
                for s,n in list(dp[k-1].items()):
                    dp[k][s+v] += n
        total = sum(values)
        observed = abs(19*total-44*sum(v for v,q in zip(values,papers) if int(q['year'])<2020))
        exact = sum(n for s,n in dp[19].items() if abs(19*total-44*s)>=observed)/math.comb(44,19)
        assert abs(exact-float(result['p']))<1e-12, result
check_permutations(p,c)
domain_p=read_csv(ROOT/'analysis/domain_comparisons/paper_domain_results.csv')
domain_c=read_csv(ROOT/'analysis/domain_comparisons/period_domain_comparisons.csv')
check_permutations(domain_p,domain_c)

notes_root=ROOT/'analysis/review_notes'
notes=json.loads((notes_root/'confirmed_statistical_notes.json').read_text())
coding=json.loads((notes_root/'semantic_coding_final.json').read_text())
assert len(notes)==len(coding)==139
assert {r['key'] for r in notes}=={r['key'] for r in coding}
source={r['key']:r for r in notes}
for r in coding:
    src=source[r['key']]
    assert src['final_domain']==r['final_domain']=='statistical_results'
    assert src['final_issue']==r['final_issue']=='confirmed_issue'
    assert src['final_substantiveness']==r['final_substantiveness']
    assert r['notes']==src['notes']
    assert r['evidence_excerpt'] in src['notes']
assert sum(r['final_substantiveness']=='substantive' for r in coding)==37
lexical=read_csv(notes_root/'text_word_bigram_frequencies.csv')
assert {r['subset'] for r in lexical}=={'confirmed_statistical','confirmed_substantive'}

tex = (HERE / 'trace_q_slides.tex').read_text()
assert len(re.findall(r'\\section\{', tex))==3
assert len(re.findall(r'\\begin\{frame\}', tex))==17
log = (HERE / 'trace_q_slides.log').read_text()
assert not re.search(r'Overfull \\[hv]box|Missing character|Undefined control sequence|undefined references',log)
doc = fitz.open(HERE / 'trace_q_slides.pdf')
assert len(doc)==17
assert len(doc.get_toc())==3
outside=[]
for i,page in enumerate(doc):
    for word in page.get_text('words'):
        if not page.rect.contains(fitz.Rect(word[:4])):
            outside.append((i+1,word))
assert not outside, outside
report = {
    'pages':len(doc), 'sections':doc.get_toc(),
    'compiler':'XeLaTeX', 'tex_layout_warnings':0, 'out_of_bounds_words':0,
    'workbooks_verified_against_analysis_by_R':4, 'codebooks_verified':4,
    'original_comparisons_reproduced':8, 'independent_exact_tests_verified':len(c)+len(domain_c),
    'bootstrap_resamples':20000, 'seed':20261022,
    'all_confirmed_statistical_issues':139, 'confirmed_substantive_statistical_issues':37,
    'notes_mining_scope':'final human-reviewed statistical_results, confirmed only',
    'notes_extracted_total':440,'semantic_coding_records':len(coding),
    'final_human_labels_preserved':True,'raw_notes_authorship':'earlier Claude Opus 5.5 review runs',
    'input_hashes':inputs,
}
(HERE / 'validation_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='input_hashes'},indent=2))
