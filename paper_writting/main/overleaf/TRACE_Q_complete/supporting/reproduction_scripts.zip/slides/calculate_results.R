#!/usr/bin/env Rscript
# Run from the project root. Only files under slides/ are written.
options(stringsAsFactors = FALSE)
Sys.setenv(TZ='America/Phoenix')
suppressPackageStartupMessages(library(readxl))
dir.create('slides/data', recursive=TRUE, showWarnings=FALSE)
d <- read.csv('analysis/candidate_results.csv', na.strings=NULL)
d[is.na(d)] <- ''
p <- read.csv('analysis/paper_results.csv')

# Verify the fields used here against the authoritative final Excel workbooks.
fields <- c('key','title','source_location','disposition','domain','complete',
 'validation_hint','issue','substantiveness','impact','internal','protocol',
 paste0('unused',13:17),'notes')
for (year in c(2018,2019,2024,2025)) {
 path <- sprintf('review_results_2_4_1_Rbulun_copy/human_adjudication_v_2_4_1_%s_R_Bulun_completed.xlsx',year)
 for (sheet in excel_sheets(path)[startsWith(excel_sheets(path),'C_')]) {
  a <- as.data.frame(suppressMessages(read_excel(path,sheet=sheet,range=cell_cols('A:R'),col_types='text')))
  names(a) <- fields; a[is.na(a)] <- ''; a <- a[nzchar(a$key),]
  m <- match(a$key,d$key); stopifnot(!anyNA(m))
  for (f in fields) stopifnot(identical(a[[f]],as.character(d[[f]][m])))
 }
}
stopifnot(nrow(p)==44, nrow(d)==440, !anyDuplicated(d$key), all(d$complete=='primary_done'))
prov <- read.csv('analysis/candidate_provenance.csv')
pm <- match(d$key,prov$key)
stopifnot(!anyNA(pm),all(d$relationship==prov$relationship_type[pm]),all(d$original_domain==prov$domain[pm]))
eligible <- d$disposition=='retain' & d$domain=='statistical_results' & d$relationship %in% c('S_C','S_W')
d$confirmed_all <- eligible & d$issue=='confirmed_issue'
d$confirmed_substantive <- d$confirmed_all & d$substantiveness=='substantive'
d$confirmed_presentation <- d$confirmed_all & d$substantiveness=='minor_presentation'
stopifnot(sum(d$confirmed_all)==139, sum(d$confirmed_substantive)==37,
 all(d$confirmed_substantive==d$strict),sum(d$confirmed_presentation)==102)
metrics <- c('confirmed_all','confirmed_substantive','confirmed_presentation')
for (metric in metrics) p[[metric]] <- vapply(p$paper,function(id)sum(d[[metric]][d$paper==id]),numeric(1))
stopifnot(all(p$confirmed_all==p$confirmed_substantive+p$confirmed_presentation))
write.csv(p,'slides/data/paper_results.csv',row.names=FALSE)
write.csv(d[,c('key','paper','year','disposition','domain','relationship','issue','substantiveness',metrics)],
 'slides/data/endpoint_membership.csv',row.names=FALSE)

# Same exact paper-level permutation definition as the manuscript; integer arithmetic.
exact_test <- function(x, early) {
 n <- length(x); k <- sum(early); total <- sum(x)
 dp <- matrix(0,k+1,total+1); dp[1,1] <- 1; seen <- 0L
 for (v in x) {
  for (j in seq.int(min(k,seen+1L),1L)) {
   s <- 0:(total-v)
   dp[j+1L,s+v+1L] <- dp[j+1L,s+v+1L]+dp[j,s+1L]
  }
  seen <- seen+1L
 }
 stopifnot(abs(sum(dp[k+1,])/choose(n,k)-1)<1e-10)
 observed <- abs(k*total-n*sum(x[early]))
 extreme <- abs(k*total-n*(0:total)) >= observed
 sum(dp[k+1,extreme])/choose(n,k)
}
early <- p$year<2020
set.seed(20261022); B <- 20000L
be <- replicate(B,sample(which(early),sum(early),replace=TRUE))
bl <- replicate(B,sample(which(!early),sum(!early),replace=TRUE))
out <- list()
for(metric in c(metrics,'primary','secondary','combined')) for(scale in c('count','any')) {
 x <- p[[metric]]; if(scale=='any') x <- as.integer(x>0)
 bd <- colMeans(matrix(x[bl],nrow=sum(!early)))-colMeans(matrix(x[be],nrow=sum(early)))
 ci <- quantile(bd,c(.025,.975),names=FALSE,type=7)
 out[[paste(metric,scale)]] <- data.frame(metric,scale,
  early_total=sum(x[early]),late_total=sum(x[!early]),
  early_mean=mean(x[early]),late_mean=mean(x[!early]),
  difference=mean(x[!early])-mean(x[early]),lower=ci[1],upper=ci[2],p=exact_test(x,early))
}
out <- do.call(rbind,out); rownames(out)<-NULL
# Ensure the extension exactly reproduces every pre-existing manuscript comparison.
old <- read.csv('analysis/period_comparisons.csv'); old$metric[old$metric=='strict'] <- 'confirmed_substantive'
for(i in seq_len(nrow(old))) {
 a <- out[out$metric==old$metric[i] & out$scale==old$scale[i],]
 stopifnot(max(abs(unlist(a[3:10])-unlist(old[i,3:10])))<1e-12)
}
write.csv(out,'slides/data/period_comparisons.csv',row.names=FALSE)
annual <- do.call(rbind,lapply(c(2018,2019,2024,2025),function(y){
 a <- p[p$year==y,]
 data.frame(year=y,papers=nrow(a),confirmed_all=sum(a$confirmed_all),
 confirmed_substantive=sum(a$confirmed_substantive),presentation=sum(a$confirmed_presentation),
 all_mean=mean(a$confirmed_all),substantive_mean=mean(a$confirmed_substantive),
 all_any=sum(a$confirmed_all>0),substantive_any=sum(a$confirmed_substantive>0))
}))
write.csv(annual,'slides/data/year_summary.csv',row.names=FALSE)
writeLines(c(capture.output(sessionInfo()),'',
 'All source fields verified against four completed Excel workbooks.',
 'All eight original manuscript comparisons reproduced to tolerance 1e-12.',
 'Confirmed all is retained statistical_results, confirmed_issue, original S_C/S_W, any substantiveness.',
 'Confirmed substantive additionally requires substantive.',
 'The all-confirmed comparison is an exploratory extension for this presentation.'), 'slides/data/computation_notes.txt')
print(out,digits=5)
