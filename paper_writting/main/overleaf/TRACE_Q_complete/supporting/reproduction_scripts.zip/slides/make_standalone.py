#!/usr/bin/env python3
"""Inline slide tables and draw the period chart from embedded TikZ coordinates."""
import csv
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent


def make_standalone(source):
    # Allow the small math/script sizes used in the flowchart and source notes.
    if r'\RequirePackage{fix-cm}' not in source:
        source = source.replace(r'\documentclass',
            '% Allow Computer Modern math at the exact requested sizes.\n'
            r'\RequirePackage{fix-cm}' + '\n' + r'\documentclass', 1)
    # Latin Modern Mono's regular file alone does not declare a bold face.
    source = source.replace(
        r'\setmonofont[Scale=0.88]{lmmono10-regular.otf}',
        r'\setmonofont[Scale=0.88,BoldFont=lmmonolt10-bold.otf,'
        r'ItalicFont=lmmono10-italic.otf,BoldItalicFont=lmmonolt10-boldoblique.otf]'
        r'{lmmono10-regular.otf}')
    # Short labels in narrow fixed-width cells should not be fully justified.
    source = source.replace(r'@{}p{1.65cm}Y@{}',
        r'@{}>{\raggedright\arraybackslash}p{1.65cm}Y@{}')

    def inline(match):
        path = HERE / match[1]
        return '% Embedded: ' + match[1] + '\n' + path.read_text().rstrip() + '\n'

    source = re.sub(r'\\input\{([^}]+)\}', inline, source)
    graphic = r'\includegraphics[width=.96\linewidth]{figures/period_differences.pdf}'
    if graphic in source:
        with (HERE / 'data/period_comparisons.csv').open() as stream:
            rows = {r['metric']: r for r in csv.DictReader(stream) if r['scale'] == 'count'}
        chart = [r'''% All coordinates are embedded; no external plot or data file is read.
\begin{tikzpicture}[x=3.35cm,y=1.45cm,
  every node/.style={font=\fontsize{8}{10}\selectfont,inner sep=0pt}]
\path[use as bounding box] (-1.75,-.52) rectangle (2.7,2.5);
\draw[Slate!45,densely dashed] (0,.15) -- (0,2.4);''']
        for y, metric, label, color in [(2, 'confirmed_all', 'Confirmed all', 'Blue'),
                                        (1, 'confirmed_substantive', 'Confirmed substantive', 'Teal')]:
            r = rows[metric]
            low, high, diff, p = (float(r[k]) for k in ['lower', 'upper', 'difference', 'p'])
            estimate = f'{diff:+.3f}' if abs(diff) < .005 else f'{diff:+.2f}'
            chart.extend([
                rf'\draw[{color},line width=1.1pt] ({low:.14f},{y}) -- ({high:.14f},{y});',
                rf'\draw[{color},line width=.7pt] ({low:.14f},{y}-.08) -- ({low:.14f},{y}+.08)',
                rf'  ({high:.14f},{y}-.08) -- ({high:.14f},{y}+.08);',
                rf'\filldraw[fill={color},draw=white,line width=.3pt] ({diff:.14f},{y}) circle[radius=2.2pt];',
                rf'\node[anchor=west,text={color}] at (-1.6,{y}+.3) {{{label}}};',
                rf'\node[anchor=east,text=Navy] at (2.35,{y}+.3) {{$ {estimate}\;[{low:+.2f},\,{high:+.2f}];\quad P={p:.3f} $}};',
            ])
        chart.append(r'''\foreach \tick in {-1.5,-1,-0.5,0,0.5,1,1.5,2}
  \node[text=Slate] at (\tick,.02) {$\pgfmathprintnumber[fixed,precision=1]{\tick}$};
\node[text=Slate] at (.35,-.35) {Later minus earlier: issues per paper (95\% bootstrap CI)};
\end{tikzpicture}\par''')
        source = source.replace(graphic, '\n'.join(chart))
    assert not re.search(r'\\(?:input|include|includegraphics|bibliography|addbibresource)\b', source)
    if '% Self-contained Beamer' not in source:
        source = source.replace('% !TeX program = xelatex',
            '% !TeX program = xelatex\n% Self-contained Beamer deck: copy this file alone and run XeLaTeX twice.\n'
            '% Uses standard TeX Live packages and fonts; no project assets or shell escape.')
    # Keep the complete speaking script with the single-file deck. Beamer hides
    # notes by default, so the normal English deck needs no CJK font package.
    notes_path = HERE / 'speech_notes_cn.json'
    if notes_path.exists():
        notes = json.loads(notes_path.read_text())['slides']
        source = re.sub(r'\n% BEGIN EMBEDDED SPEECH NOTE\n.*?% END EMBEDDED SPEECH NOTE\n', '\n', source, flags=re.S)
        assert source.count(r'\end{frame}') == len(notes)
        escaped = {'\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '$': r'\$',
                   '#': r'\#', '_': r'\_', '{': r'\{', '}': r'\}'}
        def esc(text):
            return ''.join(escaped.get(c, c) for c in text)
        iterator = iter(notes)
        def insert_note(match):
            note = next(iterator)
            paragraphs = [note['title_cn'], *note['paragraphs']]
            if note['transition']:
                paragraphs.append('转场：' + note['transition'])
            return ('% BEGIN EMBEDDED SPEECH NOTE\n'
                    '% Final judgments: review_results_2_4_1_Rbulun_copy/*.xlsx.\n'
                    '\\note{\n' + '\n\\par\n'.join(map(esc, paragraphs)) + '\n}\n'
                    '% END EMBEDDED SPEECH NOTE\n' + match[0])
        source = re.sub(r'\\end\{frame\}', insert_note, source)
    return source


if __name__ == '__main__':
    path = HERE / 'trace_q_slides.tex'
    path.write_text(make_standalone(path.read_text()))
    print('Prepared self-contained Beamer source.')
