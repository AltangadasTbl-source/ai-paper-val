#!/usr/bin/env python3
"""Read final XLSX judgments directly and audit the results used in the speech."""
import csv
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path
from zipfile import ZipFile
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ARCHIVE = ROOT / 'overleaf/TRACE_Q_complete/data'
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
FIELDS = dict(A='key', B='title', C='source_location', D='disposition', E='domain',
              F='complete', H='issue', I='substantiveness', J='impact', K='internal',
              L='protocol', R='notes')


def readcsv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def read_sheets(path):
    with ZipFile(path) as z:
        strings = [''.join(s.itertext()) for s in ET.fromstring(z.read('xl/sharedStrings.xml'))] \
            if 'xl/sharedStrings.xml' in z.namelist() else []
        rels = {r.attrib['Id']: r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
        for sheet in ET.fromstring(z.read('xl/workbook.xml')).find('s:sheets', NS):
            target = rels[sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']]
            target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
            rows = []
            for row in ET.fromstring(z.read(target)).find('s:sheetData', NS):
                values = {'row': int(row.attrib['r'])}
                for cell in row:
                    kind = cell.attrib.get('t')
                    value = cell.find('s:v', NS)
                    if kind == 'inlineStr':
                        value = ''.join(cell.find('s:is', NS).itertext())
                    elif value is not None and value.text is not None:
                        value = strings[int(value.text)] if kind == 's' else value.text
                    else:
                        value = ''
                    values[re.sub(r'\d+', '', cell.attrib['r'])] = value
                rows.append(values)
            yield sheet.attrib['name'], rows


def exact_test(values, years):
    k = sum(y < 2020 for y in years)
    dp = [Counter() for _ in range(k + 1)]
    dp[0][0] = 1
    for v in values:
        for j in range(k, 0, -1):
            for total, n in list(dp[j - 1].items()):
                dp[j][total + v] += n
    total = sum(values)
    observed = abs(k * total - len(values) * sum(v for v, y in zip(values, years) if y < 2020))
    return sum(n for s, n in dp[k].items() if abs(k * total - len(values) * s) >= observed) / math.comb(len(values), k)


def main():
    provenance = {r['key']: r for r in readcsv(ARCHIVE / 'candidate_provenance.csv')}
    frozen = {r['key']: r for r in readcsv(ARCHIVE / 'candidate_results.csv')}
    candidates, papers, inputs = [], {}, []
    for path in sorted((ROOT / 'review_results_2_4_1_Rbulun_copy').glob('*.xlsx')):
        year = int(re.search(r'_(2018|2019|2024|2025)_', path.name)[1])
        inputs.append({'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
        for name, rows in read_sheets(path):
            if name == 'Papers':
                for row in rows[1:]:
                    if row.get('A'):
                        papers[(year, row['A'])] = Counter()
            if not name.startswith('C_'):
                continue
            for row in rows[1:]:
                if not row.get('A'):
                    continue
                r = {field: row.get(col, '') for col, field in FIELDS.items()}
                for field in FIELDS.values():
                    assert r[field] == frozen[r['key']][field], (r['key'], field, 'workbook differs from frozen analysis')
                r.update(year=year, paper=name[2:], workbook=path.name, sheet=name, row=row['row'],
                         relationship=provenance[r['key']]['relationship_type'])
                candidates.append(r)
    assert len(inputs) == 4 and len(papers) == 44 and len(candidates) == 440
    assert len({r['key'] for r in candidates}) == 440
    assert all(r['complete'] == 'primary_done' for r in candidates)
    for r in candidates:
        p = papers[(r['year'], r['paper'])]
        p['candidates'] += 1
        if r['disposition'] != 'retain':
            continue
        p['retained'] += 1
        report = r['relationship'] in ('S_C', 'S_W')
        statistical = r['domain'] == 'statistical_results' and report
        confirmed = statistical and r['issue'] == 'confirmed_issue'
        p['confirmed_all'] += confirmed
        p['confirmed_substantive'] += confirmed and r['substantiveness'] == 'substantive'
        p['confirmed_presentation'] += confirmed and r['substantiveness'] == 'minor_presentation'
        p['primary'] += statistical and r['issue'] in ('confirmed_issue', 'probable_issue') and r['substantiveness'] == 'substantive'
        p['secondary'] += report and r['domain'] == 'report_internal_inconsistency' and r['internal'] == 'substantive_inconsistency'
        for domain, prefix in [('report_internal_inconsistency', 'report'), ('plan_material', 'plan')]:
            eligible = r['domain'] == domain
            p[prefix + '_retained'] += eligible
            p[prefix + '_established'] += eligible and r['internal'] in ('substantive_inconsistency', 'minor_presentation')
            p[prefix + '_substantive'] += eligible and r['internal'] == 'substantive_inconsistency'
        p['protocol_retained'] += r['domain'] == 'protocol_report'
        p['protocol_substantive_difference'] += r['domain'] == 'protocol_report' and r['protocol'] == 'substantive_difference'
        p['protocol_missing_L'] += r['domain'] == 'protocol_report' and not r['protocol']
    for p in papers.values():
        p['combined'] = p['primary'] + p['secondary']
        p['report_substantive_SC_SW'] = p['secondary']
    for path in [HERE / 'data/paper_results.csv', ARCHIVE / 'domain_comparisons/paper_domain_results.csv']:
        for row in readcsv(path):
            p = papers[(int(row['year']), row['paper'])]
            for metric in p.keys() & row.keys():
                assert p[metric] == int(row[metric]), (row['paper'], metric)
    checks = []
    for path in [HERE / 'data/period_comparisons.csv', ARCHIVE / 'domain_comparisons/period_domain_comparisons.csv']:
        for row in readcsv(path):
            values = [p[row['metric']] for p in papers.values()]
            if row['scale'] == 'any':
                values = [int(v > 0) for v in values]
            years = [year for year, _ in papers]
            early = [v for v, y in zip(values, years) if y < 2020]
            late = [v for v, y in zip(values, years) if y >= 2020]
            for prefix, group in [('early', early), ('late', late)]:
                assert sum(group) == int(row[prefix + '_total'])
                assert abs(sum(group) / len(group) - float(row[prefix + '_mean'])) < 1e-12
            p = exact_test(values, years)
            assert abs(p - float(row['p'])) < 1e-12, row
            checks.append({'metric': row['metric'], 'scale': row['scale'], 'exact_p': p})
    coding = json.loads((ARCHIVE / 'review_notes/semantic_coding_final.json').read_text())
    bykey = {r['key']: r for r in candidates}
    eligible_keys = {r['key'] for r in candidates if r['disposition'] == 'retain' and r['domain'] == 'statistical_results'
                     and r['relationship'] in ('S_C', 'S_W') and r['issue'] == 'confirmed_issue'}
    assert {r['key'] for r in coding} == eligible_keys
    for r in coding:
        assert r['final_substantiveness'] == bykey[r['key']]['substantiveness']
    annual = {str(year): dict(sum((p for (y, _), p in papers.items() if y == year), Counter()))
              for year in [2018, 2019, 2024, 2025]}
    for year in annual:
        annual[year]['papers'] = sum(y == int(year) for y, _ in papers)
    report = {
        'authoritative_judgments': 'review_results_2_4_1_Rbulun_copy/*.xlsx',
        'inputs': inputs, 'candidate_count': len(candidates), 'paper_count': len(papers),
        'dispositions': dict(Counter(r['disposition'] for r in candidates)),
        'annual': annual,
        'retained_notes_blank': sum(r['disposition'] == 'retain' and not r['notes'] for r in candidates),
        'nonempty_notes': sum(bool(r['notes']) for r in candidates),
        'judgment_fields_match_packaged_analysis': True,
        'paper_counts_match_existing_comparisons': True,
        'exact_tests_verified': checks,
        'bootstrap_intervals': 'Existing percentile intervals retained: their paper-level inputs match the workbooks exactly; no new bootstrap run.',
        'original_relationship_source': 'overleaf/TRACE_Q_complete/data/candidate_provenance.csv (not a field in final workbooks)',
        'mechanism_taxonomy': 'Supplementary prior Notes-based coding; its 139 memberships and 37 substantive labels match the final workbooks. Mechanisms and raw rationales are not fields in these workbooks.',
    }
    (HERE / 'review_results_verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    with (HERE / 'data/final_workbook_judgments.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(candidates[0]))
        writer.writeheader()
        writer.writerows(candidates)
    print(json.dumps({k: v for k, v in report.items() if k not in ('inputs', 'exact_tests_verified')}, ensure_ascii=False, indent=2))
    print(f'Verified {len(checks)} exact tests from the final workbook judgments.')


if __name__ == '__main__':
    main()
