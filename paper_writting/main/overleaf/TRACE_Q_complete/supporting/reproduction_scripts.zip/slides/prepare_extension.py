#!/usr/bin/env python3
"""Assemble the 17-slide extension from archived base, audited notes and new analyses."""
import csv
import json
import re
from pathlib import Path
from zipfile import ZipFile
from make_standalone import make_standalone

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
TABLES=HERE/'tables'
TABLES.mkdir(exist_ok=True)

def readcsv(path):
    with path.open() as f:
        return list(csv.DictReader(f))

def esc(s):
    return ''.join({'&':r'\&','%':r'\%','_':r'\_','#':r'\#'}.get(c,c) for c in str(s))

def num(x, n=2, plus=False):
    x=float(x)
    if abs(x)<.5*10**(-n): x=0.
    return f'{x:+.{n}f}' if plus else f'{x:.{n}f}'

def row(items):
    return ' & '.join(items)+r' \\'

comparisons=readcsv(ROOT/'analysis/domain_comparisons/period_domain_comparisons.csv')
bykey={(r['metric'],r['scale']):r for r in comparisons}
for name, metrics in [
    ('other_domains_broad', [('Report-internal: established','report_established'),
                            ('Plan material: established','plan_established'),
                            ('Protocol--report: retained','protocol_retained')]),
    ('other_domains_substantive',[('Report-internal: substantive','report_substantive'),
                                  ('Plan material: substantive','plan_substantive'),
                                  ('Protocol--report: substantive difference','protocol_substantive_difference')])]:
    lines=[r'\begin{tabularx}{\linewidth}{@{}Yrrrr@{}}',r'\toprule',
           row(['Domain / eligible state','Before ($n=19$)','After ($n=25$)',r'$\Delta$ (95\% CI)','$P$']),r'\midrule']
    for label, metric in metrics:
        a=bykey[metric,'count']
        lines.append(row([label,f"{num(a['early_mean'])} [{a['early_total']}]",f"{num(a['late_mean'])} [{a['late_total']}]",
                          f"${num(a['difference'],plus=True)}$ (${num(a['lower'])}$, ${num(a['upper'])}$)",num(a['p'],3)]))
    lines += [r'\bottomrule',r'\end{tabularx}']
    (TABLES/f'{name}.tex').write_text('\n'.join(lines)+'\n')

# Copy the exact original source into the deliverable so rebuild does not depend
# on changing the archive. The original rendered 15-slide version remains archived.
basepath=HERE/'templates/base_15.tex'
basepath.parent.mkdir(exist_ok=True)
if not basepath.exists():
    with ZipFile(ROOT/'archive/TRACE_Q_slides_15pages_with_CN_notes.zip') as z:
        basepath.write_bytes(z.read('slides/trace_q_slides.tex'))
base=basepath.read_text()
frames=re.findall(r'\\begin\{frame\}\[t\].*?\\end\{frame\}',base,re.S)
assert len(frames)==15
header=base.split(r'\begin{document}')[0]
header=header.replace('Review Codebook and Changes in Confirmed Statistical Findings',
                      'Study Design, Review Notes and Before/After Publication-Cohort Comparisons')

intro=frames[0].replace('TRACE-Q: from review flags to statistical findings',
                       'TRACE-Q: study design, review evidence and period changes')
intro=intro.replace('Paper and study design: what TRACE-Q checks and what was sampled.',
                    'Study design: 44 trial packages and final human review.')
intro=intro.replace('Review codebook: how a candidate becomes an eligible finding.',
                    'Codebook and text mining: link raw notes to final human decisions.')
intro=intro.replace('Statistical results: confirmed all versus confirmed substantive over time.',
                    'Before/after cohorts: statistical findings and the other three domains.')
cohort=frames[2].replace('One recorded reviewer: \\code{R_Bulun}. No independent second ratings.',
                       r'Final copied workbooks were later human-reviewed (user-confirmed). Raw \code{R_Bulun} notes came from earlier AI review runs.')
cohort=cohort.replace(r'\takeaway{Retention includes descriptive differences and uncertain findings.}',
                     r'\takeaway{Before = 2018--2019; after = 2024--2025 publication cohorts.}')
cohort=cohort.replace('Retention is not an accuracy estimate.',
                     'Raw notes are AI-authored; final labels are human-reviewed. Period labels do not identify a pandemic effect.')

othercodebook=frames[6].replace('Original P\\_R / P\\_P findings are excluded from temporal endpoints.',
                              'Original P\\_R / P\\_P findings are excluded from the original report-only endpoints; new domain comparisons are explicitly descriptive extensions.')
endpoints=frames[7].replace('original \\code{P_R}/\\code{P_P} candidates remain outside temporal endpoints.',
                           'original \\code{P_R}/\\code{P_P} candidates stay outside the original report-only endpoints. New domain comparisons explicitly include them.')

mining=r'''\begin{frame}[t]{Recover raw notes, then add a separate mechanism taxonomy}
\begin{columns}[T,onlytextwidth]
\column{.48\textwidth}
\textbf{1. Extract without losing provenance}\par\medskip
\smalltext
\textbf{440/440 nonempty Notes} from the four raw \code{R_Bulun} workbooks. Preserve exact text and \textbf{year / paper / candidate / Notes}, plus workbook, sheet, row and hashes.\par\medskip
\textbf{2. Join the final human-reviewed labels}\par\medskip
Select \textbf{139 confirmed statistical candidates}; \textbf{37} are substantive. Final labels and original relationships determine eligibility.\par\medskip
Raw and final decision codes match. All \textbf{413 retained notes are blank in the copied workbooks}; the raw files preserve their rationales.
\column{.48\textwidth}
\textbf{3. Mine only confirmed statistical notes}\par\medskip
\smalltext
For the \textbf{139 statistical candidates only}, normalize a separate text copy and count word/bigram document frequencies. Other review domains are not mined or recategorized.\par\medskip
Read every complete note; assign one primary mechanism plus optional secondary tags. Preserve negations, alternative explanations and localized corrections.\par\medskip
\textbf{4. Audit every coding decision}\par\medskip
A second Astra reviewer checks all 139 records against notes and taxonomy; reconcile differences with an exact excerpt and rationale for every assignment.
\end{columns}
\takeaway{New mechanism labels are LLM-assisted analysis; human confirmation and substantiveness stay unchanged.}
\src{Sources: reviewer\_runs\_raw/20xx/R\_Bulun/*.xlsx, Notes (R); final copied workbooks; analysis/review\_notes/. Raw notes were written by Claude review runs, not by the later human reviewer. Extraction independently checked with R readxl; no source PDF re-adjudication in this text-mining task.}
\end{frame}'''

taxonomy=r'''\begin{frame}[t]{Recategorize confirmed statistical issues by mechanism}
\begin{columns}[T,onlytextwidth]
\column{.60\textwidth}
\small
\input{tables/notes_taxonomy.tex}
\medskip\par
\smalltext
Each candidate has exactly one primary mechanism. Typo, cross-location disagreement and multiple concerns can be secondary tags.\par\medskip
\textbf{139 confirmed = 37 substantive + 102 presentation only.} The new mechanism labels preserve this split.
\column{.36\textwidth}
\smalltext
\textbf{Read the note, not only the title}\par\medskip
\input{tables/notes_examples.tex}
\end{columns}
\src{Source: final reconciled coding in analysis/review\_notes/semantic\_coding\_final.csv and taxonomy\_final.json. Counts are candidate-level; a repeated pattern may span several source locations. Mechanism coding is an exploratory content analysis of raw rationales, not an additional human error judgment.}
\end{frame}'''

method=frames[9].replace('Compare papers, preserving their clustered findings',
                        'Compare publication cohorts at the paper level')
method=method.replace('For each eligible outcome, include all 44 papers, including papers with zero findings.',
                      'Before-pandemic cohorts: 2018--2019. After-pandemic cohorts: 2024--2025. Include all 44 papers, including zero counts.')
method=method.replace('Exploratory, unadjusted $P$ values. Exchangeability is an assumption, not guaranteed by availability sampling.',
                      'Exploratory, unadjusted $P$ values. Exchangeability is not guaranteed; publication period does not identify a pandemic effect.')

domainbroad=r'''\begin{frame}[t]{Extend the comparison to the other three review domains}
\small
\input{tables/other_domains_broad.tex}
\smallskip\par
\smalltext Mean findings per paper [total findings]; $\Delta$ = after minus before. Before: 2018--2019; after: 2024--2025.
\medskip
\begin{columns}[T,onlytextwidth]
\column{.48\textwidth}
\textbf{What ``all'' means in each domain}\par\medskip
\smalltext
\textbf{Report / plan:} retained and \code{substantive_inconsistency} or \code{minor_presentation}; indeterminate is excluded.\par\medskip
Report retained totals: 4 / 8; established: 3 / 8. Plan retained totals: 12 / 20; established: 12 / 17.
\column{.48\textwidth}
\textbf{Protocol--report remains descriptive}\par\medskip
\smalltext
All 102 / 112 retained differences are included here, regardless of optional interpretation. Interpretation is blank for 2 / 3 candidates.\par\medskip
Final human domains are used; original plan-related codes are allowed in this new extension.
\end{columns}
\takeaway{These are domain-specific outcomes; protocol differences are not confirmed errors.}
\src{Source: analysis/domain\_comparisons/. Exact two-sided paper permutation tests; separate 20,000-resample bootstrap CIs. Original statistical/report-only endpoints are unchanged. All comparisons are exploratory and do not estimate a pandemic effect.}
\end{frame}'''

domainsub=r'''\begin{frame}[t]{Substantive findings are sparse outside the statistical domain}
\small
\input{tables/other_domains_substantive.tex}
\smallskip\par
\smalltext Mean findings per paper [total findings]; before = 2018--2019, after = 2024--2025. CI units: findings per paper.
\medskip
\begin{columns}[T,onlytextwidth]
\column{.48\textwidth}
\textbf{Papers with at least one substantive finding}\par\medskip
\smalltext
Report-internal: 1/19 $\rightarrow$ 4/25.\par
Plan material: 0/19 $\rightarrow$ 2/25.\par
Protocol--report: 18/19 $\rightarrow$ 24/25.\par\medskip
Four substantive plan findings are concentrated in \textbf{two later papers}; the earlier sample has zero.
\column{.48\textwidth}
\textbf{Reconcile with the paper's original endpoint}\par\medskip
\smalltext
Final-domain report-internal total: \textbf{5}. Original report-only eligible total: \textbf{4}.\par\medskip
\code{2024::jama.2024.11057::C003} was edited into the report-internal domain but retains original \code{P_R}; it enters this extension, not the original secondary endpoint.
\end{columns}
\takeaway{No clear period difference emerges; sparse counts and wide intervals limit interpretation.}
\src{Source: analysis/domain\_comparisons/. Substantive inconsistency for report/plan; substantive\_difference for protocol--report. A zero earlier sample produces a boundary bootstrap interval for plan findings; it does not establish absence in the underlying population.}
\end{frame}'''

periodtaxonomy=r'''\begin{frame}[t]{Which statistical mechanisms differ between publication cohorts?}
\small
\input{tables/notes_category_period.tex}
\smallskip\par
\smalltext Each cell shows count / mean per paper. Before: 19 papers; after: 25 papers. All = confirmed; Sub. = confirmed substantive.
\medskip
\input{tables/notes_period_takeaway.tex}
\src{Source: reconciled candidate-level Notes coding; all 44 papers retained in the denominators. Primary categories are mutually exclusive. These post hoc mechanism comparisons are descriptive; classification uncertainty and shared-model blind spots are not included in the original statistical intervals.}
\end{frame}'''

closing=r'''\begin{frame}[t]{Keep evidence, mechanism and period interpretation distinct}
\begin{tabularx}{\linewidth}{@{}p{.55cm}Y@{}}
\textcolor{Teal}{\Large\textbf{1}} & \textbf{Study design:} compare 44 selected trial packages across the 2018--2019 and 2024--2025 publication cohorts, using final human-reviewed workbook decisions.\\[2mm]
\textcolor{Blue}{\Large\textbf{2}} & \textbf{Statistical findings:} confirmed all rises from 2.95 to 3.32 per paper; confirmed substantive remains about 0.84. Adding four earlier probable cases produces the paper's apparent decline.\\[2mm]
\textcolor{Navy}{\Large\textbf{3}} & \textbf{Broader comparison:} the other three domains show no clear period differences. Protocol--report differences remain descriptive; they are not pooled with confirmed statistical errors.\\[2mm]
\textcolor{Teal}{\Large\textbf{4}} & \textbf{Notes-based recategorization:} preserve all 440 raw notes; connect 139 confirmed cases to final human labels; classify mechanisms separately from the 37 substantive judgments.
\end{tabularx}
\medskip
\smalltext
Availability sampling, shared-model review histories and unmeasured missed findings limit generalization. Before/after are publication-cohort labels, not a causal estimate of pandemic effects. New mechanism coding needs human assessment before use as a validated taxonomy.
\src{Sources: raw reviewer Notes, final copied workbooks and reproducible extension analyses. User confirmed later human review of copied workbooks; raw Notes remain AI-authored. The prior 15-slide version is archived.}
\end{frame}'''

header=header.replace('arrows.meta,positioning,calc}', 'arrows.meta,positioning,calc,shapes.geometric}')
assembled=[intro,cohort,frames[3],frames[4],frames[5],othercodebook,endpoints,
           mining,taxonomy,method,frames[11],frames[12],frames[13],domainbroad,domainsub,periodtaxonomy,closing]
assert len(assembled)==17
parts=[header,r'\begin{document}']
sections={0:'Paper and study design',2:'Review codebook and Notes mining',9:'Before and after publication-cohort comparisons'}
for i,frame in enumerate(assembled):
    if i in sections: parts.append(r'\section{'+sections[i]+'}')
    parts.append(frame)
parts.append(r'\end{document}')
(HERE/'trace_q_slides.tex').write_text(make_standalone('\n\n'.join(parts)+'\n'))
print('Prepared 17-slide source and domain comparison tables.')
