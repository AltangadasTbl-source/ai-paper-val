#!/usr/bin/env python3
"""Prepare slide tables and a reviewable XLSX from the final statistical-only coding."""
import csv
import json
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
N=ROOT/'analysis/review_notes'
T=HERE/'tables';T.mkdir(exist_ok=True)
records=json.loads((N/'semantic_coding_final.json').read_text())
taxonomy=json.loads((N/'taxonomy_final.json').read_text())
categories=taxonomy['categories']
meta={c['code']:c for c in categories}
assert len(records)==139 and all(r['final_domain']=='statistical_results' for r in records)
assert sum(r['final_substantiveness']=='substantive' for r in records)==37
short={
 'COUNT_DENOM':'Counts / denominators',
 'EFFECT_ESTIMAND':'Effect estimates / estimands',
 'INTERVAL_DISPERSION':'Intervals / distribution summaries',
 'TEST_INFERENCE':'P values / inference',
 'DIRECTION':'Contrast sign / direction',
 'ATTRIBUTION':'Attribution / swaps / duplication',
 'ANALYSIS_DEFINITION':'Analysis / measure definitions',
}
def esc(s):
 return ''.join({'&':r'\&','%':r'\%','_':r'\_','#':r'\#'}.get(c,c) for c in str(s))
def row(vals):return ' & '.join(vals)+r' \\'
def csvrows(path):
 with path.open() as f:return list(csv.DictReader(f))
summary=csvrows(N/'category_summary.csv')
period=csvrows(N/'category_period_summary.csv')
order=[c['code'] for c in categories]
allcounts=Counter(r['primary_category_id'] for r in records)
subcounts=Counter(r['primary_category_id'] for r in records if r['final_substantiveness']=='substantive')
for r in summary:
 assert allcounts[r['primary_category_id']]==int(r['all_count'])
 assert subcounts[r['primary_category_id']]==int(r['substantive_count'])
lines=[r'\begin{tabularx}{\linewidth}{@{}Yrr@{}}',r'\toprule',row(['Primary mechanism','All','Sub.']),r'\midrule']
for code in order:
 lines.append(row([short[code],str(allcounts[code]),str(subcounts[code])]))
lines.extend([r'\midrule',row([r'\textbf{Total}',r'\textbf{139}',r'\textbf{37}']),r'\bottomrule',r'\end{tabularx}'])
(T/'notes_taxonomy.tex').write_text('\n'.join(lines)+'\n')
(T/'notes_examples.tex').write_text(r'''\textbf{Effect identity; substantive}\par
\code{2018 / jama.2018.14280 / C001}\par
The note says all printed risk ratios reproduce from a transposed $2\times2$ table, while the $P$ values are correct.\par\medskip
\textbf{Interval bound; presentation only}\par
\code{2025 / jama.2025.20765 / C014}\par
The note says asymmetry is not itself an error; it identifies a printed upper bound of 42 with 4.2 intended.\par\medskip
\textbf{Audit:} 139 notes checked; 3 primary labels revised. Three multi-mechanism cases retain explicit ambiguity flags.
''')
lines=[r'\begin{tabularx}{\linewidth}{@{}Yrrrr@{}}',r'\toprule',
 row(['Statistical mechanism','Before: All','After: All','Before: Sub.','After: Sub.']),r'\midrule']
bp={r['primary_category_id']:r for r in period}
for code in order:
 r=bp[code]
 vals=[short[code]]
 for prefix,n in [('early',19),('late',25)]:
  k=int(r[f'{prefix}_count']);vals.append(f'{k} / {k/n:.2f}')
 for prefix,n in [('early',19),('late',25)]:
  k=int(r[f'{prefix}_substantive']);vals.append(f'{k} / {k/n:.2f}')
 lines.append(row(vals))
lines.extend([r'\midrule',row([r'\textbf{Total}',r'\textbf{56 / 2.95}',r'\textbf{83 / 3.32}',r'\textbf{16 / 0.84}',r'\textbf{21 / 0.84}']),r'\bottomrule',r'\end{tabularx}'])
(T/'notes_category_period.tex').write_text('\n'.join(lines)+'\n')
(T/'notes_period_takeaway.tex').write_text(r'''\smalltext
\textbf{Composition changes beneath the similar substantive mean:} analysis/measure-definition candidates rise from 0.16 to 0.68 per paper; interval candidates fall from 0.74 to 0.40.\par\medskip
\textcolor{Teal}{\textbf{Mechanisms are post hoc descriptive categories, not evidence that pandemic exposure caused a change.}}
''')

# Minimal source index requested by the user, kept separate from text-mining scope.
source=json.loads((N/'all_notes.json').read_text())
with (N/'notes_year_paper_candidate.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['year','paper','candidate','Notes']);w.writeheader()
 for r in source:w.writerow({**{k:r[k] for k in ['year','paper','candidate']},'Notes':r['notes']})
with (N/'confirmed_statistical_notes_year_paper_candidate.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['year','paper','candidate','Notes']);w.writeheader()
 for r in records:w.writerow({**{k:r[k] for k in ['year','paper','candidate']},'Notes':r['notes']})

# A plain OOXML workbook is sufficient and avoids installing new packages.
# Every text cell is inlineStr, so source note text cannot become a formula.
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
ET.register_namespace('',NS)
def tag(n):return f'{{{NS}}}{n}'
def letter(n):
 s=''
 while n:n,r=divmod(n-1,26);s=chr(65+r)+s
 return s
headers=['year','paper','candidate','Notes','primary_category','category_cn','final_substantiveness',
         'secondary_tags','evidence_excerpt','coding_rationale','coding_confidence','ambiguous_primary',
         'source_workbook','notes_cell']
def reviewrow(r):
 return [r['year'],r['paper'],r['candidate'],r['notes'],r['primary_category_id'],
         meta[r['primary_category_id']]['label_zh'],r['final_substantiveness'],
         '; '.join(r['secondary_tags']),r['evidence_excerpt'],r['rationale'],r['coding_confidence'],
         str(r['primary_assignment_ambiguous']),r['source_workbook'],r['notes_cell']]
sheets=[('Confirmed statistical',headers,[reviewrow(r) for r in records]),
        ('Substantive subset',headers,[reviewrow(r) for r in records if r['final_substantiveness']=='substantive']),
        ('Taxonomy',['code','label_en','label_zh','inclusion','exclusion_and_boundary'],
         [[c.get(k,'') for k in ['code','label_en','label_zh','inclusion','exclusion_and_boundary']] for c in categories]),
        ('Overall summary',list(summary[0]),[list(r.values()) for r in summary]),
        ('Period summary',list(period[0]),[list(r.values()) for r in period])]
def worksheet(h, rows):
 root=ET.Element(tag('worksheet'))
 views=ET.SubElement(root,tag('sheetViews'));view=ET.SubElement(views,tag('sheetView'),workbookViewId='0')
 ET.SubElement(view,tag('pane'),ySplit='1',topLeftCell='A2',activePane='bottomLeft',state='frozen')
 cols=ET.SubElement(root,tag('cols'))
 for i,name in enumerate(h,1):
  width=12 if name in ('year','candidate','notes_cell') else 75 if name in ('Notes','evidence_excerpt','coding_rationale') else 28
  ET.SubElement(cols,tag('col'),min=str(i),max=str(i),width=str(width),customWidth='1')
 data=ET.SubElement(root,tag('sheetData'))
 for ri,values in enumerate([h,*rows],1):
  rowel=ET.SubElement(data,tag('row'),r=str(ri))
  for ci,value in enumerate(values,1):
   c=ET.SubElement(rowel,tag('c'),r=f'{letter(ci)}{ri}',t='inlineStr',s='1' if ri==1 else '2')
   isel=ET.SubElement(c,tag('is'));t=ET.SubElement(isel,tag('t'));t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=str(value)
 ET.SubElement(root,tag('autoFilter'),ref=f'A1:{letter(len(h))}{len(rows)+1}')
 return ET.tostring(root,encoding='utf-8',xml_declaration=True)
contenttypes='<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
for i in range(1,len(sheets)+1):contenttypes+=f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
contenttypes+='</Types>'
styles='''<?xml version="1.0"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/><color rgb="FFFFFFFF"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF17324D"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/><xf fontId="1" fillId="2" borderId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf><xf fontId="0" fillId="0" borderId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'''
wb=ET.Element(tag('workbook'));ss=ET.SubElement(wb,tag('sheets'))
for i,(name,_,_) in enumerate(sheets,1):ET.SubElement(ss,tag('sheet'),name=name,sheetId=str(i),attrib={f'{{{REL}}}id':f'rId{i}'})
relationships='<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
for i in range(1,len(sheets)+1):relationships+=f'<Relationship Id="rId{i}" Type="{REL}/worksheet" Target="worksheets/sheet{i}.xml"/>'
relationships+=f'<Relationship Id="rId{len(sheets)+1}" Type="{REL}/styles" Target="styles.xml"/></Relationships>'
with ZipFile(N/'statistical_issue_recategorization.xlsx','w',ZIP_DEFLATED) as z:
 z.writestr('[Content_Types].xml',contenttypes)
 z.writestr('_rels/.rels',f'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="{REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
 z.writestr('xl/workbook.xml',ET.tostring(wb,encoding='utf-8',xml_declaration=True))
 z.writestr('xl/_rels/workbook.xml.rels',relationships);z.writestr('xl/styles.xml',styles)
 for i,(_,h,rows) in enumerate(sheets,1):z.writestr(f'xl/worksheets/sheet{i}.xml',worksheet(h,rows))
print('Prepared statistical-only slide tables, 440-row source index and 139/37-case review workbook.')
