TRACE-Q — Overleaf project

Upload TRACE-Q_Overleaf.zip using New Project > Upload Project.
In project settings, select:
  Main document: main.tex
  Compiler: XeLaTeX
Use a current TeX Live version offered by Overleaf, then Recompile.

All LaTeX dependencies specific to this manuscript are included:
  main.tex        Main manuscript
  references.bib  Bibliography, processed with BibTeX
  sections/       Editable manuscript sections
  tables/         Generated result tables
  figures/        TikZ workflow source and vector PDF results figure
  latexmkrc       XeLaTeX preference for latexmk

The fonts (TeX Gyre Termes, TeX Gyre Heros, Latin Modern Mono) and
LaTeX packages are standard TeX Live resources. No absolute local paths,
external data processing, shell escape, or R installation are needed to
compile this manuscript. The result tables and plot are already generated.

Keep the subfolder structure when editing or downloading the project.
The original analysis scripts and reviewed workbooks remain in the separate
TRACE-Q_draft_source_and_analysis.zip delivered with the draft.

Official upload instructions:
https://docs.overleaf.com/managing-projects-and-files/uploading-a-project
Compiler settings:
https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler
