TRACE-Q draft paper — 22 October 2026

Main manuscript: trace_q_draft.tex
Rendered PDF: trace_q_draft.pdf
References: references.bib
Sections: sections/*.tex
Generated result tables: tables/*.tex
Figures: figures/workflow.tex and figures/period_counts.pdf

Build with XeLaTeX and BibTeX:
  bash manuscript/build.sh
Run this command from paper_writting/main, or run bash build.sh here.
The build uses TeX Gyre Termes, TeX Gyre Heros, and Latin Modern Mono.

Reproduce numerical analysis from paper_writting/main:
  Rscript analysis/analyze_results.R
This reads all four final human-review Excel files directly and uses the
archived relationship codes in analysis/candidate_provenance.csv. It writes
analysis CSVs, the analysis summary, tables, a vector PDF plot, and sessionInfo.
Requires R and readxl; the recorded environment is R 4.5.0/readxl 1.5.0.

Refresh provenance when the full original repository is present:
  python3 analysis/collect_provenance.py
This verifies the 44 final report hashes and all 189 direct-source hashes,
copies original candidate relationship codes, counts PDFs/pages and XLSX
worksheets, and records workbook/input hashes. It does not alter sources.
The historical catalogues and article packages are outside this main folder.
They are not required merely to compile the paper or rerun the R analysis
against the saved provenance CSV and the four supplied Excel files.

Analysis choices:
- 44 papers, 440 candidate rows; final human workbook decisions are authoritative.
- Availability sampling, as confirmed by the author during drafting.
- 19 papers in 2018–2019 and 25 in 2024–2025.
- Principal endpoint: retained, confirmed/probable AND substantive statistical
  issues with an original S_C or S_W report relationship.
- Secondary endpoint: retained substantive report-internal inconsistencies
  with an original S_C or S_W relationship.
- Original P_R/P_P relationships stay descriptive even after a human domain edit.
- Exact, two-sided paper-level permutation tests; differences later minus earlier.
- 20,000 within-period paper bootstrap replicates; random seed 20261022.
- P values are exploratory and unadjusted. No accuracy, recall, prevalence,
  causal year effect, or efficiency claim is made.

Original source-file composition:
188 PDFs / 5,559 physical PDF pages, plus 1 XLSX / 1 worksheet.
The historical total of 5,560 is mixed source units, not PDF pages.

The template PDF informed language style, not verbatim wording or journal layout.
Two GPT-6-Astra/high agents assisted writing and quantitative review;
a GPT-6.1-sol/high agent checked scientific English against the template.
Journal source PDFs are not included in the manuscript deliverables.

Before submission, the authors should finalize:
- Names, affiliations, corresponding author, funding, and competing interests.
- Relevant ethics/permissions and data/code release statements.
- Exact historical client/tool versions if recoverable; reviewer training and
  timing details if the paper is to report them.
- Development/pilot history and any exposure of this cohort during rule tuning.
  The draft makes no claim of an independent held-out validation cohort.
- Target-journal formatting, AI disclosure, and author approval of all claims.

No supplied outline, template, source article, workflow, or final human workbook
was changed to generate this draft.
