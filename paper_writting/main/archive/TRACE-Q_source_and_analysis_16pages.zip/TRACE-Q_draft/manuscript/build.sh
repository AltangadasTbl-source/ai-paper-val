#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
xelatex -interaction=nonstopmode -halt-on-error trace_q_draft.tex > xelatex_pass1.log
bibtex trace_q_draft > bibtex_build.log
xelatex -interaction=nonstopmode -halt-on-error trace_q_draft.tex > xelatex_pass2.log
xelatex -interaction=nonstopmode -halt-on-error trace_q_draft.tex > xelatex_pass3.log
if rg -n 'Undefined control sequence|undefined citations|undefined references|Overfull \\hbox|Overfull \\vbox|Missing character' trace_q_draft.log; then
  printf '%s\n' 'Build completed with a layout or reference issue; inspect trace_q_draft.log.' >&2
  exit 1
fi
printf '%s\n' 'XeLaTeX build complete: manuscript/trace_q_draft.pdf'
