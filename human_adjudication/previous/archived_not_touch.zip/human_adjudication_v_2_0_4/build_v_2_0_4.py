#!/usr/bin/env python3
"""Build self-contained v.2.0.4 primary-review and checker HTML files."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote


VERSION = "v.2.0.4"
SCHEMA_VERSION = 7
BASE_VERSION = "v.2.0.3"
BASE_SCHEMA_VERSION = 6
YEARS = ("2018", "2019", "2024", "2025")
EXPECTED_YEAR_COUNTS = {"2018": 119, "2019": 71, "2024": 91, "2025": 131}
EXPECTED_PRIMARY_COUNTS = {"P_R": 45, "P_P": 50, "S_C": 65, "S_W": 252}
EXPECTED_AI_DISPOSITIONS = {"retain": 402, "exclude": 9, "discuss": 1}
STATISTICAL_ROUTING_CATEGORIES = {
    "Statistical reporting inconsistency",
    "Denominator, proportion, or total inconsistency",
    "Numeric or arithmetic inconsistency",
    "Rate-versus-count inconsistency",
    "Analysis-unit or population inconsistency",
}

OUT_DIR = Path(__file__).resolve().parent
ROOT = OUT_DIR.parents[1]
BASE_DIR_OPTIONS = (
    ROOT / "human_adjudication" / "human_adjudication_v_2_0_3",
    ROOT / "human_adjudication" / "previous" / "human_adjudication_v_2_0_3",
)
BASE_DIR = next((path for path in BASE_DIR_OPTIONS if path.is_dir()), BASE_DIR_OPTIONS[0])
BASE_FILES = {
    year: BASE_DIR / f"candidate_flag_review_v_2_0_3_{year}.html" for year in YEARS
}
META_RESULTS_RELATIVE = Path(
    "meta_report/consistency_reclassification_2026-09-04/reclassified_candidates.json"
)
META_RESULTS_PATH = ROOT / META_RESULTS_RELATIVE
TEST_REVIEWER = {"id": "tester", "name": "Workflow Tester"}


def merged_relationship(value: object) -> str:
    relationship = str(value)
    return "P_P" if relationship in {"P_O", "P_B"} else relationship


def suggested_domain(relationship: str, category: object) -> str:
    if relationship == "P_R":
        return "protocol_report"
    if relationship == "P_P":
        return "plan_material"
    if str(category) in STATISTICAL_ROUTING_CATEGORIES:
        return "statistical_results"
    return "internal_nonstatistical"


def read_base_candidates() -> tuple[list[dict[str, object]], str]:
    rows: list[dict[str, object]] = []
    for year, path in BASE_FILES.items():
        if not path.is_file():
            raise RuntimeError(f"Missing v.2.0.3 base HTML: {path}")
        text = path.read_text(encoding="utf-8")
        match = re.search(
            r'<script id="candidate-data" type="application/json">(.*?)</script>',
            text,
            flags=re.DOTALL,
        )
        if not match:
            raise RuntimeError(f"Missing frozen candidate payload in {path}")
        payload = json.loads(match.group(1))
        if payload.get("reviewVersion") != BASE_VERSION:
            raise RuntimeError(f"Unexpected base version in {path}")
        if payload.get("schemaVersion") != BASE_SCHEMA_VERSION:
            raise RuntimeError(f"Unexpected base schema in {path}")
        if payload.get("years") != [year]:
            raise RuntimeError(f"Unexpected base year in {path}")
        candidates = payload.get("candidates")
        if not isinstance(candidates, list):
            raise RuntimeError(f"Invalid candidate payload in {path}")
        if payload.get("keySet") != [row.get("key") for row in candidates]:
            raise RuntimeError(f"Base candidate keys do not reconcile in {path}")
        rows.extend(candidates)
    digest = hashlib.sha256(
        json.dumps(rows, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()
    return rows, digest


def read_meta_results() -> tuple[dict[str, dict[str, object]], str]:
    if not META_RESULTS_PATH.is_file():
        raise RuntimeError(f"Missing meta-report results: {META_RESULTS_PATH}")
    results = json.loads(META_RESULTS_PATH.read_text(encoding="utf-8"))
    if not isinstance(results, list):
        raise RuntimeError("Meta-report results must be a JSON list")
    by_key = {str(item.get("key")): item for item in results}
    if len(results) != 412 or len(by_key) != 412:
        raise RuntimeError("Meta-report results must contain 412 unique candidate keys")
    digest = hashlib.sha256(
        json.dumps(results, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()
    return by_key, digest


def ai_disposition(evidence_state: object) -> str:
    state = str(evidence_state or "recorded_candidate")
    if state == "not_reproduced":
        return "exclude"
    if state == "record_input_error":
        return "discuss"
    return "retain"


def normalize_candidate(
    row: dict[str, object], meta_result: dict[str, object]
) -> dict[str, object]:
    normalized = dict(row)
    relationship = str(row["primary"])
    meta_relationship = merged_relationship(meta_result.get("primary"))
    if meta_relationship != relationship:
        raise RuntimeError(
            f"Meta-report relationship mismatch for {row['key']}: "
            f"{meta_relationship} != {relationship}"
        )
    domain = suggested_domain(relationship, row.get("category", ""))
    source_state = str(meta_result.get("evidence_state", "recorded_candidate"))
    evidence = {
        key: value
        for key, value in dict(row.get("evidence", {})).items()
        if key not in {"Mechanical evidence recheck", "Human verification steps"}
    }
    normalized.pop("duplicateOfCoding", None)
    normalized.pop("evidenceState", None)
    normalized.update(
        {
            "suggestedDomain": domain,
            "evidence": evidence,
            "aiInitialAssessment": {
                "source": META_RESULTS_RELATIVE.as_posix(),
                "relationship": relationship,
                "domain": domain,
                "disposition": ai_disposition(source_state),
            },
        }
    )
    return normalized


HTML_TEMPLATE = r'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>__YEAR__ Two-Stage Flag Review — v.2.0.4</title>
  <style>
    :root { --ink:#17212b; --muted:#617080; --line:#d9e1e6; --paper:#fff; --wash:#f4f7f8; --accent:#176b87; --accent2:#0e536b; --soft:#e7f4f7; --ok:#28764c; --warn:#996300; --bad:#a33e35; --purple:#5d54a4; --shadow:0 5px 20px rgba(24,48,62,.08); }
    * { box-sizing:border-box; } html { scroll-behavior:smooth; } body { margin:0; color:var(--ink); background:var(--wash); font:14px/1.48 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
    button,input,select,textarea { font:inherit; } a { color:var(--accent2); } code { font-size:.92em; }
    .page { width:min(1380px,calc(100% - 30px)); margin:0 auto; }
    header { padding:28px 0 24px; color:#fff; background:linear-gradient(125deg,#103f52,#176b87 60%,#25869b); }
    header h1 { margin:0 0 7px; font:700 clamp(24px,4vw,38px)/1.15 Georgia,serif; } header p { max-width:1000px; margin:0; color:#e5f4f7; }
    .provenance { margin-top:11px; color:#cce6ec; font-size:12px; }
    .reviewer-bar { position:sticky; top:0; z-index:20; padding:10px 0; border-bottom:1px solid var(--line); background:rgba(244,247,248,.97); backdrop-filter:blur(8px); }
    .reviewer-grid { display:grid; grid-template-columns:minmax(130px,.45fr) minmax(180px,.8fr) auto 1fr; gap:8px; align-items:center; }
    .control,.btn { min-height:39px; padding:8px 10px; border:1px solid #b9c6ce; border-radius:8px; color:var(--ink); background:#fff; }
    .btn { cursor:pointer; font-weight:700; } .btn:hover { border-color:var(--accent); color:var(--accent); } .btn.primary { color:#fff; border-color:var(--accent); background:var(--accent); }
    .active-reviewer { color:var(--muted); font-size:12px; text-align:right; }
    .toolbar { display:grid; grid-template-columns:1.5fr repeat(4,minmax(145px,.55fr)) auto; gap:8px; margin:14px 0 10px; }
    .actions { position:relative; } .actions>summary { list-style:none; } .actions>summary::-webkit-details-marker { display:none; }
    .menu { position:absolute; right:0; top:44px; z-index:15; width:270px; padding:8px; border:1px solid var(--line); border-radius:10px; background:#fff; box-shadow:var(--shadow); }
    .menu .btn,.menu label { display:block; width:100%; margin:3px 0; text-align:left; } .menu input[type=file] { display:none; }
    .stats { display:grid; grid-template-columns:repeat(6,1fr); gap:8px; margin:10px 0 14px; }
    .stat { padding:11px 12px; border:1px solid var(--line); border-radius:9px; background:#fff; box-shadow:0 2px 7px rgba(30,50,60,.03); }
    .stat b { display:block; font-size:21px; line-height:1.1; } .stat span { color:var(--muted); font-size:11px; }
    .notice { display:flex; gap:10px; align-items:flex-start; margin:0 0 13px; padding:11px 13px; border-left:4px solid var(--accent); border-radius:4px 8px 8px 4px; background:var(--soft); }
    .notice strong { white-space:nowrap; } #save-status { margin-left:auto; color:var(--muted); font-size:12px; white-space:nowrap; }
    details.group { margin:10px 0; overflow:clip; border:1px solid var(--line); border-radius:10px; background:#fff; box-shadow:0 3px 12px rgba(30,50,60,.04); }
    details.group>summary { padding:13px 15px; cursor:pointer; font-weight:750; background:#f9fbfb; } details.paper { margin:9px 12px 12px; box-shadow:none; }
    .group-count { margin-left:7px; color:var(--muted); font-size:12px; font-weight:550; }
    .candidate-list { margin:0; padding:2px 15px 14px 40px; } .candidate-list>li { margin:7px 0; padding-left:2px; }
    details.candidate { overflow:hidden; border:1px solid var(--line); border-radius:8px; background:#fff; } details.candidate[open] { border-color:#b7cdd5; box-shadow:0 3px 12px rgba(30,50,60,.06); }
    details.candidate>summary { display:flex; gap:8px; align-items:flex-start; padding:10px 11px; cursor:pointer; list-style:none; } details.candidate>summary::-webkit-details-marker { display:none; }
    details.candidate>summary::before { content:"›"; color:var(--accent); font-size:21px; line-height:18px; transition:transform .12s; } details.candidate[open]>summary::before { transform:rotate(90deg); }
    .candidate-id { flex:0 0 auto; color:var(--accent); font-weight:800; } .candidate-title { flex:1 1 auto; font-weight:650; }
    .badge,.analysis-pill,.chip { display:inline-block; border-radius:999px; padding:2px 8px; font-size:11px; font-weight:700; }
    .badge { flex:0 0 auto; color:#fff; background:#687480; } .badge.progress { background:var(--warn); } .badge.complete { background:var(--ok); }
    .analysis-pill { color:#fff; background:#687480; } .analysis-pill.primary { background:var(--purple); } .analysis-pill.secondary { background:var(--accent); } .analysis-pill.protocol { background:#735a2a; }
    .candidate-body { padding:0 13px 14px 40px; border-top:1px solid #edf1f3; }
    .metadata { display:flex; flex-wrap:wrap; gap:6px; padding:11px 0 3px; } .chip { border:1px solid var(--line); color:var(--muted); background:#fafbfb; font-weight:600; }
    .chip.relationship { color:#174f62; border-color:#b8d0d8; background:#eff8fa; } .chip.warning { color:#7d3d12; border-color:#e1c3ad; background:#fff6ef; }
    .statement { max-width:1100px; margin:8px 0; } .source-row { display:flex; flex-wrap:wrap; gap:6px; align-items:center; margin:8px 0 11px; color:var(--muted); font-size:12px; }
    .source-link { display:inline-block; padding:3px 7px; border:1px solid #b8cdd5; border-radius:6px; text-decoration:none; background:#f5fbfc; }
    .evidence-box,.coding-box { margin:8px 0 12px; padding:10px 12px; border:1px solid var(--line); border-radius:8px; background:#fbfcfc; }
    .evidence-box h4 { margin:8px 0 2px; color:#3f505c; font-size:12px; } .evidence-box p { margin:0 0 7px; } .coding-box summary { cursor:pointer; font-weight:700; }
    .coding-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:8px 14px; margin-top:9px; } .coding-grid p { margin:0; }
    .review-panel { padding:12px; border-radius:9px; background:#f4f7f8; } .review-panel.locked { opacity:.58; pointer-events:none; }
    .section-title { margin:0 0 8px; color:#2d4653; font-size:14px; }
    .review-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:10px; margin-bottom:10px; }
    .field { display:flex; flex-direction:column; gap:4px; } .field.wide { grid-column:span 2; } .field.full { grid-column:1/-1; }
    .field label { color:#3e4e59; font-size:12px; font-weight:750; } .field select,.field input,.field textarea { width:100%; padding:7px 8px; border:1px solid #bac7cf; border-radius:7px; background:#fff; }
    .field textarea { min-height:68px; resize:vertical; } .hint { color:var(--muted); font-size:11px; }
    .module { margin-top:10px; padding:10px; border:1px solid #d4e1e5; border-radius:8px; background:#fbfdfd; } .module[hidden] { display:none; }
    .primary-readonly { margin:10px 0; padding:11px 12px; border:1px solid #c8d7dd; border-radius:8px; background:#eef5f7; }
    .primary-readonly h3 { margin:0 0 7px; font-size:14px; color:#244b59; }
    .primary-readonly dl { display:grid; grid-template-columns:minmax(150px,.35fr) 1fr; gap:4px 12px; margin:0; }
    .primary-readonly dt { color:var(--muted); font-size:12px; font-weight:700; }
    .primary-readonly dd { margin:0; white-space:pre-wrap; overflow-wrap:anywhere; }
    .checker-box { margin-top:11px; padding:11px; border:2px solid #b9d5dd; border-radius:9px; background:#f7fcfd; }
    .completion { display:flex; flex-wrap:wrap; gap:8px; align-items:center; margin-top:10px; padding-top:10px; border-top:1px solid var(--line); }
    .validation { color:var(--bad); font-size:12px; } .empty { padding:40px 0; text-align:center; color:var(--muted); }
    footer { padding:25px 0 42px; color:var(--muted); font-size:12px; }
    @media(max-width:1050px) { .toolbar { grid-template-columns:repeat(3,1fr); } .toolbar input[type=search] { grid-column:1/-1; } .stats { grid-template-columns:repeat(3,1fr); } .review-grid { grid-template-columns:repeat(2,1fr); } }
    @media(max-width:700px) { .reviewer-grid,.toolbar,.review-grid,.coding-grid { grid-template-columns:1fr; } .active-reviewer { text-align:left; } .field.wide,.field.full { grid-column:auto; } .stats { grid-template-columns:repeat(2,1fr); } .candidate-body { padding-left:12px; } }
    @media print { .reviewer-bar,.toolbar,.notice,.menu,footer { display:none!important; } body { background:#fff; font-size:10pt; } .page { width:100%; } header { color:#000; background:#fff; padding:0 0 10px; } header p,.provenance { color:#333; } details { break-inside:avoid; } details.group,details.candidate { box-shadow:none; } }
  </style>
</head>
<body>
  <header><div class="page">
    <h1>__YEAR__ Two-Stage Candidate-Flag Review</h1>
    <p>Version v.2.0.4 supports an exploratory primary assessment followed by a visible-answer second-person check. Meta-report results supply editable AI starting values; practitioner judgment determines the final record.</p>
    <div class="provenance">Generated __GENERATED__ · __PACKAGES__ papers · __TOTAL__ candidates · source digest <code>__DIGEST_SHORT__</code></div>
  </div></header>

  <div class="reviewer-bar"><div class="page reviewer-grid">
    <input id="reviewer-id" class="control" placeholder="Reviewer ID (required)" aria-label="Reviewer ID">
    <input id="reviewer-name" class="control" placeholder="Display name (optional)" aria-label="Reviewer name">
    <button id="activate-reviewer" class="btn primary">Create / load primary reviewer</button>
    <div id="active-reviewer" class="active-reviewer">No active reviewer; review fields are locked.</div>
  </div></div>

  <main class="page">
    <div class="toolbar">
      <input id="search" class="control" type="search" placeholder="Search paper, ID, title, category, subtype, or rationale…">
      <select id="progress-filter" class="control"><option value="all">All progress</option><option value="pending">Pending</option><option value="progress">In progress</option><option value="complete">Complete</option></select>
      <select id="relationship-filter" class="control"><option value="all">All relationships</option><option value="S_W">S_W · one report</option><option value="S_C">S_C · report cross-file</option><option value="P_R">P_R · report vs plan</option><option value="P_P">P_P · plan material</option></select>
      <select id="domain-filter" class="control"><option value="all">All review domains</option><option value="statistical_results">Statistical results (S_C / S_W)</option><option value="internal_nonstatistical">Internal nonstatistical (S_C / S_W)</option><option value="protocol_report">Protocol–report (P_R)</option><option value="plan_material">Plan material (P_P)</option></select>
      <select id="analysis-filter" class="control"><option value="all">All analysis labels</option><option value="primary">Primary temporal eligible</option><option value="secondary">Secondary temporal eligible</option><option value="protocol">Protocol–report descriptive</option><option value="plan">Other plan descriptive</option><option value="not_eligible">Not temporal eligible</option><option value="undetermined">Eligibility undetermined</option></select>
      <details class="actions"><summary class="btn primary">Review actions ▾</summary><div class="menu">
        <button id="next-incomplete" class="btn">Next incomplete item</button><button id="expand-visible" class="btn">Expand visible</button><button id="collapse-all" class="btn">Collapse all</button>
        <button id="export-json" class="btn">Export reviewer snapshot (JSON)</button><button id="export-csv" class="btn">Export review table (CSV)</button><button id="download-html" class="btn">Download annotated HTML</button>
        <label class="btn" for="import-json">Import / resume v.2.0.4 JSON</label><input id="import-json" type="file" accept="application/json,.json">
        <button id="load-secondary-test" class="btn" hidden>Load bundled 2018 checker test</button><button id="print" class="btn">Print / Save PDF</button>
      </div></details>
    </div>

    <section class="stats" aria-label="Review progress">
      <div class="stat"><b id="stat-total">0</b><span>Total candidates</span></div><div class="stat"><b id="stat-complete">0</b><span id="stat-complete-label">Primary reviews complete</span></div>
      <div class="stat"><b id="stat-progress">0</b><span>In progress</span></div>
      <div class="stat"><b id="stat-primary">0</b><span>Primary temporal eligible</span></div><div class="stat"><b id="stat-secondary">0</b><span>Secondary temporal eligible</span></div>
      <div class="stat"><b id="stat-protocol">0</b><span>Retained P_R descriptive</span></div>
    </section>

    <div class="notice"><strong id="stage-label">Primary stage:</strong><span id="stage-help">Review the editable AI starting values and export the completed primary record before the visible-answer checker stage. This is an exploratory tool; the final report must retain an appropriate disclaimer.</span><span id="save-status">Waiting for reviewer</span></div>
    <div id="candidate-groups"></div><div id="empty" class="empty" hidden>No candidates match the current filters.</div>
  </main>
  <footer class="page">V.2.0.4 · Exploratory workflow. Candidate keys are year / package / candidate ID. AI starting values, primary records, checker responses, and proposed-final records remain distinguishable; practitioners retain responsibility for interpretation and use.</footer>

  <div id="embedded-review-state" data-state="" hidden></div>
  <script id="candidate-data" type="application/json">__DATA_JSON__</script>
  <script>
  (() => {
    'use strict';
    const dataset = JSON.parse(document.getElementById('candidate-data').textContent);
    const candidates = dataset.candidates;
    const bundledSecondaryTest = dataset.secondaryTestSnapshot||null;
    const VERSION = 'v.2.0.4', SCHEMA = 7;
    const STORAGE_PREFIX = `human-adjudication-${VERSION}-${dataset.years[0]}`;
    let state = null, saveTimer = null;
    const embedded = decodeState(document.getElementById('embedded-review-state').dataset.state);
    const el = id => document.getElementById(id);
    const esc = value => String(value ?? '').replace(/[&<>\"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[ch]));
    const relationLabels = {S_W:'Within one main/non-plan supplement',S_C:'Main vs non-plan supplement / two non-plan supplements',P_R:'Report/results supplement vs protocol/SAP',P_P:'Protocol/SAP and related plan material'};
    const domainLabels = {statistical_results:'Statistical results (S_C / S_W)',internal_nonstatistical:'Internal nonstatistical (S_C / S_W)',protocol_report:'Protocol–report (P_R)',plan_material:'Plan material (P_P)'};
    const opts = {
      disposition:[['pending','Select…'],['retain','Retain candidate flag'],['exclude','Do not retain'],['out_of_scope','Outside the prespecified review scope'],['discuss','Needs discussion']],
      statisticalErrorStatus:[['pending','Select…'],['confirmed_error','Confirmed statistical reporting error'],['probable_error','Probable statistical reporting error'],['not_error','Not a statistical error'],['indeterminate','Indeterminate']],
      substantiveStatus:[['pending','Select…'],['substantive','Substantive'],['minor_presentation','Minor / presentation-only'],['indeterminate','Indeterminate']],
      downstreamImpact:[['pending','Select…'],['direct','Direct extraction/analysis impact'],['possible','Possible downstream impact'],['unlikely','Unlikely downstream impact'],['unknown','Unable to assess']],
      internalStatus:[['pending','Select…'],['substantive_inconsistency','Substantive inconsistency'],['minor_presentation','Minor / presentation-only inconsistency'],['wording_only','Wording-only difference'],['not_inconsistency','Not an inconsistency'],['indeterminate','Indeterminate']],
      documentationStatus:[['pending','Select…'],['explicit','Change explicitly documented'],['partial','Partial or implicit documentation'],['none_located','No documentation located in reviewed materials'],['cannot_assess','Cannot assess'],['not_applicable','Not applicable']],
      justificationStatus:[['pending','Select…'],['explicit','Explicit justification located'],['none_located','No justification located in reviewed materials'],['cannot_assess','Cannot assess'],['not_applicable','Not applicable']],
      protocolInterpretation:[['pending','Select…'],['documented_justified','Documented and justified change'],['documented_no_justification','Documented; no justification located'],['undocumented_change_candidate','Possible undocumented change'],['wording_only','Wording-only / no substantive difference'],['version_timing','Version or timing ambiguity'],['indeterminate','Indeterminate']],
      checkStatus:[['pending','Select…'],['agree','Agree with primary assessment'],['agree_clarification','Agree with clarification'],['disagree','Disagree; proposed final assessment edited below'],['unable','Unable to resolve / refer for discussion']]
    };
    function defaultRecord(c) { const ai=c.aiInitialAssessment||{};return {disposition:ai.disposition||'pending',domain:ai.domain||c.suggestedDomain,relatedClusterId:'',statisticalErrorStatus:'pending',substantiveStatus:'pending',downstreamImpact:'pending',internalStatus:'pending',documentationStatus:'pending',justificationStatus:'pending',protocolInterpretation:'pending',notes:'',reviewComplete:false,updatedAt:''}; }
    function cloneRecord(record,c) { return {...defaultRecord(c),...(record||{})}; }
    function stage() { return state?.stage||'primary'; }
    function primaryRecordFor(c) { return cloneRecord(stage()==='checker'?state?.primary?.reviews?.[c.key]:state?.reviews?.[c.key],c); }
    function checkFor(c) { return state?.checks?.[c.key]||null; }
    function recordFor(c) { return stage()==='checker'?cloneRecord(checkFor(c)?.finalRecord||primaryRecordFor(c),c):primaryRecordFor(c); }
    function normalizeId(value) { return value.trim().replace(/\s+/g,'_'); }
    function stateKey(value) { if(!value)return ''; return value.stage==='checker'?`${STORAGE_PREFIX}::checker::${encodeURIComponent(value.primary.reviewer.id)}::${encodeURIComponent(value.checker.id)}`:`${STORAGE_PREFIX}::primary::${encodeURIComponent(value.reviewer.id)}`; }
    function decodeState(encoded) { if (!encoded) return null; try { const binary=atob(encoded), bytes=new Uint8Array(binary.length); for(let i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i); return JSON.parse(new TextDecoder().decode(bytes)); } catch (_) { return null; } }
    function encodeState(value) { const bytes=new TextEncoder().encode(JSON.stringify(value)); let binary=''; for(const byte of bytes) binary+=String.fromCharCode(byte); return btoa(binary); }
    function exactKeySet(object) { if(!object||typeof object!=='object')return false;const incoming=Object.keys(object).sort(),expected=[...dataset.keySet].sort();return incoming.length===expected.length&&incoming.every((key,index)=>key===expected[index]); }
    function exactReviewKeySet(value) { return exactKeySet(value?.reviews); }
    function validBase(value) { return value && value.schemaVersion===SCHEMA && value.reviewVersion===VERSION && value.year===dataset.years[0]; }
    function validPrimary(value) { return validBase(value) && (value.stage||'primary')==='primary' && value.reviewer && value.reviews && typeof value.reviews==='object' && (value.sourceDigest===dataset.sourceDigest||exactReviewKeySet(value)); }
    function validChecker(value) { return validBase(value) && value.stage==='checker' && value.primary?.reviewer && value.primary?.reviews && value.checker && value.checks && typeof value.checks==='object'; }
    function validAIInitial(value) { return value && value.schemaVersion===1 && value.targetReviewVersion===VERSION && value.year===dataset.years[0] && exactKeySet(value.assessments); }
    function validSnapshot(value) { return validPrimary(value)||validChecker(value); }
    function primaryComplete(value) { return validPrimary(value) && dataset.keySet.every(key=>{const c=candidates.find(candidate=>candidate.key===key),r=cloneRecord(value.reviews[key],c);return value.reviews[key]?.reviewComplete===true&&validate(c,r).length===0;}); }
    function mergePrimary(base,incoming) { if(!validPrimary(incoming)) return base; for(const [key,record] of Object.entries(incoming.reviews)){ if(!dataset.keySet.includes(key)) continue; const old=base.reviews[key]; if(!old || String(record.updatedAt||'')>=String(old.updatedAt||'')) base.reviews[key]=record; } if(incoming.reviewer.name) base.reviewer.name=incoming.reviewer.name; return base; }
    function activateReviewer(id,name,fromImport=null) {
      id=normalizeId(id); if(!id) return alert('Enter a reviewer ID.');
      let fresh={schemaVersion:SCHEMA,reviewVersion:VERSION,sourceDigest:dataset.sourceDigest,year:dataset.years[0],stage:'primary',reviewer:{id,name:name.trim()},reviews:{}};
      try { const local=JSON.parse(localStorage.getItem(stateKey(fresh))||'null'); if(validPrimary(local) && local.reviewer.id===id) fresh=mergePrimary(fresh,local); } catch (_) {}
      if(validPrimary(embedded) && embedded.reviewer.id===id) fresh=mergePrimary(fresh,embedded);
      if(validPrimary(fromImport)) fresh=mergePrimary(fresh,fromImport);
      if(name.trim()) fresh.reviewer.name=name.trim(); state=fresh;
      try { localStorage.setItem(`${STORAGE_PREFIX}::last-state-key`,stateKey(state)); } catch (_) {}
      el('reviewer-id').value=id; el('reviewer-name').value=state.reviewer.name||'';
      el('active-reviewer').textContent=`Active primary reviewer: ${id}${state.reviewer.name?' · '+state.reviewer.name:''}`;
      renderGroups(); updateAll(); saveState();
    }
    function activateChecker(primary,id,name,fromImport=null) {
      id=normalizeId(id); if(!id) return alert('Enter the checker ID before selecting the primary JSON.');
      if(!primaryComplete(primary)) return alert('The primary snapshot is incomplete. Complete all candidates and export it again.');
      if(id===primary.reviewer.id) return alert('The checker ID must differ from the primary reviewer ID.');
      primary={...primary,sourceDigest:dataset.sourceDigest};
      let fresh={schemaVersion:SCHEMA,reviewVersion:VERSION,sourceDigest:dataset.sourceDigest,year:dataset.years[0],stage:'checker',primary:{reviewer:primary.reviewer,reviews:primary.reviews,exportedAt:primary.exportedAt||''},checker:{id,name:name.trim()},checks:{}};
      if(validChecker(fromImport)) fresh=fromImport;
      state=fresh; try { localStorage.setItem(`${STORAGE_PREFIX}::last-state-key`,stateKey(state)); } catch (_) {}
      el('reviewer-id').value=state.checker.id;el('reviewer-name').value=state.checker.name||'';el('active-reviewer').textContent=`Active checker: ${state.checker.id}${state.checker.name?' · '+state.checker.name:''} · primary: ${state.primary.reviewer.id}`;
      renderGroups();updateAll();saveState();
    }
    function saveState() { if(!state) return; clearTimeout(saveTimer); el('save-status').textContent='Saving…'; saveTimer=setTimeout(()=>{ try { const key=stateKey(state);localStorage.setItem(key,JSON.stringify(state));localStorage.setItem(`${STORAGE_PREFIX}::last-state-key`,key);el('save-status').textContent='Saved in browser; export JSON for archival'; } catch (_) { el('save-status').textContent='Browser storage unavailable; export JSON now'; } },160); }
    function progressFor(c) { if(stage()==='checker'){const check=checkFor(c);if(check?.checkComplete)return 'complete';if(check)return 'progress';return 'pending';} const stored=state?.reviews?.[c.key];if(stored?.reviewComplete)return 'complete';if(stored&&Object.keys(stored).some(k=>!['domain','reviewComplete','updatedAt'].includes(k)&&stored[k]&&stored[k]!=='pending'))return 'progress';return 'pending'; }
    function assessmentComplete(c) { return stage()==='checker'?Boolean(checkFor(c)?.checkComplete):Boolean(state?.reviews?.[c.key]?.reviewComplete); }
    function sameAssessment(c) { const primary=primaryRecordFor(c),final=recordFor(c),keys=Object.keys(defaultRecord(c)).filter(key=>!['reviewComplete','updatedAt'].includes(key));return keys.every(key=>String(primary[key]??'')===String(final[key]??'')); }
    function analysisFor(c,r) {
      if(!assessmentComplete(c)) return 'undetermined';
      const retained=r.disposition==='retain';
      if(c.primary==='P_R') return retained?'protocol':'not_eligible';
      if(c.primary==='P_P') return retained?'plan':'not_eligible';
      if(!['S_C','S_W'].includes(c.primary) || !retained) return 'not_eligible';
      if(r.domain==='statistical_results' && ['confirmed_error','probable_error'].includes(r.statisticalErrorStatus) && r.substantiveStatus==='substantive') return 'primary';
      if(r.domain==='internal_nonstatistical' && r.internalStatus==='substantive_inconsistency') return 'secondary';
      return 'not_eligible';
    }
    function analysisLabel(value) { return {primary:'Primary temporal eligible',secondary:'Secondary temporal eligible',protocol:'Protocol–report descriptive',plan:'Other plan-material descriptive',not_eligible:'Not temporal eligible',undetermined:'Eligibility undetermined'}[value]; }
    function domainOptionsFor() { return Object.entries(domainLabels); }
    function selectField(key,field,label,values,current,hint='') { return `<div class="field"><label>${esc(label)}</label><select data-key="${esc(key)}" data-field="${field}">${values.map(([v,l])=>`<option value="${esc(v)}" ${current===v?'selected':''}>${esc(l)}</option>`).join('')}</select>${hint?`<span class="hint">${esc(hint)}</span>`:''}</div>`; }
    function checkSelectField(key,field,label,values,current,hint='') { return `<div class="field"><label>${esc(label)}</label><select data-key="${esc(key)}" data-check-field="${field}">${values.map(([v,l])=>`<option value="${esc(v)}" ${current===v?'selected':''}>${esc(l)}</option>`).join('')}</select>${hint?`<span class="hint">${esc(hint)}</span>`:''}</div>`; }
    function inputField(key,field,label,current,placeholder='',wide='') { return `<div class="field ${wide}"><label>${esc(label)}</label><input data-key="${esc(key)}" data-field="${field}" value="${esc(current)}" placeholder="${esc(placeholder)}"></div>`; }
    function areaField(key,field,label,current,placeholder='',wide='full') { return `<div class="field ${wide}"><label>${esc(label)}</label><textarea data-key="${esc(key)}" data-field="${field}" placeholder="${esc(placeholder)}">${esc(current)}</textarea></div>`; }
    function checkAreaField(key,field,label,current,placeholder='',wide='full') { return `<div class="field ${wide}"><label>${esc(label)}</label><textarea data-key="${esc(key)}" data-check-field="${field}" placeholder="${esc(placeholder)}">${esc(current)}</textarea></div>`; }
    function primarySummary(c) { const r=primaryRecordFor(c), fields=[['Reviewer',state.primary.reviewer.id],['Disposition',r.disposition],['Domain',domainLabels[r.domain]||r.domain],['Related cluster',r.relatedClusterId],['Statistical error status',r.statisticalErrorStatus],['Substantiveness',r.substantiveStatus],['Downstream impact',r.downstreamImpact],['Internal assessment',r.internalStatus],['Protocol documentation',r.documentationStatus],['Protocol justification',r.justificationStatus],['Protocol interpretation',r.protocolInterpretation],['Notes',r.notes]].filter(([,v])=>v&&v!=='pending');return `<div class="primary-readonly"><h3>Locked primary assessment · ${esc(state.primary.reviewer.id)}</h3><dl>${fields.map(([k,v])=>`<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('')}</dl></div>`; }
    function candidateHtml(c) {
      const r=recordFor(c), progress=progressFor(c), analysis=analysisFor(c,r);
      const check=stage()==='checker'?(checkFor(c)||{}):null;
      const evidence=Object.entries(c.evidence).map(([name,value])=>`<h4>${esc(name)}</h4><p>${esc(value)}</p>`).join('');
      const direct=c.sourceLinks.map(link=>`<a class="source-link" href="${esc(link.href)}" target="_blank">${esc(link.label)}</a>`).join('');
      const deeper=c.evidencePaths.map(link=>`<a class="source-link" href="${esc(link.href)}" target="_blank">${esc(link.label.split('/').slice(-2).join('/'))}</a>`).join('');
      const ai=c.aiInitialAssessment||{};
      return `<li data-candidate-key="${esc(c.key)}"><details class="candidate" data-search="${esc([c.year,c.package,c.id,c.sourceId,c.title,c.statement,c.category,c.subtype,c.rationale,c.primary].join(' ').toLowerCase())}">
        <summary><span class="candidate-id">${esc(c.id)}</span><span class="candidate-title">${esc(c.title)}</span><span class="analysis-pill ${analysis}" data-analysis-badge>${esc(analysisLabel(analysis))}</span><span class="badge ${progress}" data-progress-badge>${progress==='complete'?'Complete':progress==='progress'?'In progress':'Pending'}</span></summary>
        <div class="candidate-body">
          <div class="metadata"><span class="chip">${esc(c.year)} / ${esc(c.package)} / ${esc(c.id)}</span><span class="chip relationship">${esc(c.primary)} · ${esc(relationLabels[c.primary]||c.primary)}</span><span class="chip">Original category: ${esc(c.category||'not stated')}</span><span class="chip">Subtype: ${esc(c.subtype||'not coded')}</span></div>
          ${c.statement?`<p class="statement"><strong>Candidate statement:</strong> ${esc(c.statement)}</p>`:''}
          <div class="source-row"><a class="source-link" href="${esc(c.reportHref)}" target="_blank">Open full source report</a>${direct}${c.locations&&!direct?`<span>${esc(c.locations)}</span>`:''}</div>
          ${evidence?`<details class="evidence-box"><summary><strong>Candidate evidence and source guidance</strong></summary>${evidence}</details>`:''}
          <details class="coding-box"><summary>AI starting assessment from the meta report — editable</summary><div class="coding-grid"><p><strong>Relationship:</strong> ${esc(ai.relationship||c.primary)}</p><p><strong>Review domain:</strong> ${esc(domainLabels[ai.domain]||ai.domain)}</p><p><strong>Candidate disposition:</strong> ${esc(ai.disposition||'pending')}</p>${c.legacyRelationship?`<p class="full"><strong>V.2.0.3 consolidation note:</strong> Source routing code ${esc(c.legacyRelationship)} is included in P_P because the former operational/background strata were too sparse for separate classification.</p>`:''}<p class="full"><strong>Relationship rationale:</strong> ${esc(c.rationale)}</p>${c.ambiguity?`<p class="full"><strong>Ambiguity:</strong> ${esc(c.ambiguity)}</p>`:''}${c.planMechanism?`<p><strong>Protocol mechanism:</strong> ${esc(c.planMechanism)}</p>`:''}<div class="source-row">${deeper}</div></div></details>
          ${stage()==='checker'?primarySummary(c):''}
          <div class="review-panel ${state?'':'locked'}" data-review-panel>
            <h3 class="section-title">${stage()==='checker'?'Checker-proposed final assessment':'Primary reviewer assessment'}</h3>
            <div class="review-grid">
              ${selectField(c.key,'disposition','Candidate disposition',opts.disposition,r.disposition)}
              ${selectField(c.key,'domain','Review domain',domainOptionsFor(),r.domain,'AI starting value; the reviewer may select any listed domain.')}
              ${inputField(c.key,'relatedClusterId','Related issue cluster ID',r.relatedClusterId,'Optional; distinct flags may share a cluster')}
            </div>
            <div class="module" data-module="statistical" ${r.domain==='statistical_results'?'':'hidden'}><h3 class="section-title">Statistical-results assessment</h3><div class="review-grid">
              ${selectField(c.key,'statisticalErrorStatus','Statistical error status',opts.statisticalErrorStatus,r.statisticalErrorStatus)}
              ${selectField(c.key,'substantiveStatus','Substantiveness',opts.substantiveStatus,r.substantiveStatus)}
              ${selectField(c.key,'downstreamImpact','Potential downstream impact',opts.downstreamImpact,r.downstreamImpact)}
            </div></div>
            <div class="module" data-module="protocol" ${r.domain==='protocol_report'?'':'hidden'}><h3 class="section-title">Protocol–report discrepancy assessment</h3><div class="review-grid">
              ${selectField(c.key,'documentationStatus','Change documentation',opts.documentationStatus,r.documentationStatus)}
              ${selectField(c.key,'justificationStatus','Change justification',opts.justificationStatus,r.justificationStatus)}
              ${selectField(c.key,'protocolInterpretation','Interpretation',opts.protocolInterpretation,r.protocolInterpretation)}
            </div></div>
            <div class="module" data-module="nonstat" ${['statistical_results','protocol_report'].includes(r.domain)?'hidden':''}><h3 class="section-title">Internal or plan-material assessment</h3><div class="review-grid">
              ${selectField(c.key,'internalStatus','Assessment',opts.internalStatus,r.internalStatus)}
            </div></div>
            <div class="review-grid">${areaField(c.key,'notes','Additional notes',r.notes,'Optional uncertainty or points for discussion')}</div>
            ${stage()==='checker'?`<div class="checker-box"><h3 class="section-title">Second-person check</h3><div class="review-grid">${checkSelectField(c.key,'checkStatus','Check result',opts.checkStatus,check.checkStatus||'pending')}${checkAreaField(c.key,'checkerComment','Checker comment',check.checkerComment||'','Required for clarification, disagreement, or unresolved cases','wide')}</div><button class="btn" data-action="reset-primary" data-key="${esc(c.key)}">Reset proposed final to primary</button></div>`:''}
            <div class="completion"><button class="btn primary" data-action="complete" data-key="${esc(c.key)}">${stage()==='checker'?'Mark second-person check complete':'Mark primary review complete'}</button><button class="btn" data-action="reopen" data-key="${esc(c.key)}" ${progress==='complete'?'':'hidden'}>Reopen</button><span class="analysis-pill ${analysis}" data-analysis-text>${esc(analysisLabel(analysis))}</span><span class="validation" data-validation></span></div>
          </div>
        </div></details></li>`;
    }
    function renderGroups() {
      const packages=[...new Set(candidates.map(c=>c.package))];
      el('candidate-groups').innerHTML=`<details class="group year" open><summary>${dataset.years[0]} <span class="group-count">${packages.length} papers · ${candidates.length} candidates</span></summary>${packages.map(pkg=>{const items=candidates.filter(c=>c.package===pkg); return `<details class="group paper" data-package="${esc(pkg)}"><summary>${esc(pkg)} <span class="group-count">${items.length} candidates</span></summary><ul class="candidate-list">${items.map(candidateHtml).join('')}</ul></details>`;}).join('')}</details>`;
    }
    function validate(c,r) {
      const missing=[]; if(r.disposition==='pending') missing.push('candidate disposition'); if(!Object.hasOwn(domainLabels,r.domain)) missing.push('review domain');
      const active=r.disposition==='retain';
      if(active&&r.domain==='statistical_results'){ if(r.statisticalErrorStatus==='pending') missing.push('statistical error status'); if(r.substantiveStatus==='pending') missing.push('substantiveness'); if(r.downstreamImpact==='pending') missing.push('downstream impact'); }
      else if(active&&r.domain==='protocol_report'){ if(r.documentationStatus==='pending') missing.push('change documentation'); if(r.justificationStatus==='pending') missing.push('change justification'); if(r.protocolInterpretation==='pending') missing.push('protocol interpretation'); }
      else if(active){ if(r.internalStatus==='pending') missing.push('internal or plan-material assessment'); }
      return missing;
    }
    function updateRecord(key,field,value) { if(!state)return;const c=candidates.find(x=>x.key===key),now=new Date().toISOString();if(stage()==='checker'){const old=checkFor(c)||{checkStatus:'pending',checkerComment:'',finalRecord:primaryRecordFor(c),checkComplete:false};state.checks[key]={...old,finalRecord:{...recordFor(c),[field]:value,reviewComplete:true,updatedAt:now},checkComplete:false,updatedAt:now};}else{state.reviews[key]={...recordFor(c),[field]:value,reviewComplete:false,updatedAt:now};}if(field==='domain')updateModules(key,value);updateItem(key);saveState();updateStats();applyFilters(); }
    function updateCheckField(key,field,value) { if(stage()!=='checker')return;const c=candidates.find(x=>x.key===key),old=checkFor(c)||{checkStatus:'pending',checkerComment:'',finalRecord:primaryRecordFor(c),checkComplete:false};state.checks[key]={...old,[field]:value,checkComplete:false,updatedAt:new Date().toISOString()};updateItem(key);saveState();updateStats();applyFilters(); }
    function updateModules(key,domain) { const item=document.querySelector(`[data-candidate-key="${CSS.escape(key)}"]`); if(!item) return; item.querySelector('[data-module="statistical"]').hidden=domain!=='statistical_results'; item.querySelector('[data-module="protocol"]').hidden=domain!=='protocol_report'; item.querySelector('[data-module="nonstat"]').hidden=['statistical_results','protocol_report'].includes(domain); }
    function updateItem(key) { const c=candidates.find(x=>x.key===key),r=recordFor(c),item=document.querySelector(`[data-candidate-key="${CSS.escape(key)}"]`);if(!item)return;const progress=progressFor(c),analysis=analysisFor(c,r),badge=item.querySelector('[data-progress-badge]');badge.className=`badge ${progress}`;badge.textContent=progress==='complete'?'Complete':progress==='progress'?'In progress':'Pending';for(const node of item.querySelectorAll('[data-analysis-badge],[data-analysis-text]')){node.className=`analysis-pill ${analysis}`;node.textContent=analysisLabel(analysis);}const reopen=item.querySelector('[data-action="reopen"]');reopen.hidden=progress!=='complete'; }
    function completeReview(key) { if(!state)return alert('Create or load a reviewer first.');const c=candidates.find(x=>x.key===key),r=recordFor(c),missing=validate(c,r),item=document.querySelector(`[data-candidate-key="${CSS.escape(key)}"]`),message=item.querySelector('[data-validation]');if(stage()==='checker'){const check=checkFor(c)||{};if(!check.checkStatus||check.checkStatus==='pending')missing.push('check result');if(check.checkStatus&&check.checkStatus!=='agree'&&!String(check.checkerComment||'').trim())missing.push('checker comment');if(check.checkStatus==='agree'&&!sameAssessment(c))missing.push('use “Agree with clarification”/“Disagree,” or reset the proposed final to primary');}if(missing.length){message.textContent=`Complete: ${missing.join(', ')}.`;return;}const now=new Date().toISOString();if(stage()==='checker'){const old=checkFor(c)||{};state.checks[key]={...old,finalRecord:{...r,reviewComplete:true,updatedAt:now},checkComplete:true,updatedAt:now};message.textContent='Second-person check marked complete.';}else{state.reviews[key]={...r,reviewComplete:true,updatedAt:now};message.textContent='Primary review marked complete.';}updateItem(key);saveState();updateStats();applyFilters(); }
    function reopenReview(key) { if(!state)return;const c=candidates.find(x=>x.key===key),now=new Date().toISOString();if(stage()==='checker'){const old=checkFor(c)||{checkStatus:'pending',checkerComment:'',finalRecord:primaryRecordFor(c)};state.checks[key]={...old,checkComplete:false,updatedAt:now};}else{state.reviews[key]={...recordFor(c),reviewComplete:false,updatedAt:now};}updateItem(key);saveState();updateStats();applyFilters(); }
    function resetToPrimary(key) { if(stage()!=='checker')return;const c=candidates.find(x=>x.key===key),old=checkFor(c)||{checkStatus:'pending',checkerComment:''};state.checks[key]={...old,finalRecord:{...primaryRecordFor(c),reviewComplete:true},checkComplete:false,updatedAt:new Date().toISOString()};renderGroups();updateAll();saveState(); }
    function domainFilterMatch(domain,filter) { return filter==='all'||domain===filter; }
    function applyFilters() { const query=el('search').value.trim().toLowerCase(),progress=el('progress-filter').value,relationship=el('relationship-filter').value,domain=el('domain-filter').value,analysis=el('analysis-filter').value;let visible=0;
      document.querySelectorAll('[data-candidate-key]').forEach(item=>{const c=candidates.find(x=>x.key===item.dataset.candidateKey),r=recordFor(c),p=progressFor(c),a=analysisFor(c,r),details=item.querySelector('details.candidate');const show=(!query||details.dataset.search.includes(query))&&(progress==='all'||p===progress)&&(relationship==='all'||c.primary===relationship)&&domainFilterMatch(r.domain,domain)&&(analysis==='all'||a===analysis);item.hidden=!show;if(show)visible++;});
      document.querySelectorAll('details.paper').forEach(p=>{const show=[...p.querySelectorAll('[data-candidate-key]')].some(i=>!i.hidden);p.hidden=!show;if(show&&(query||progress!=='all'||relationship!=='all'||domain!=='all'||analysis!=='all'))p.open=true;});el('empty').hidden=visible!==0;
    }
    function updateStats() { const counts={complete:0,progress:0,primary:0,secondary:0,protocol:0}; for(const c of candidates){const r=recordFor(c),p=progressFor(c),a=analysisFor(c,r);if(p==='complete')counts.complete++;if(p==='progress')counts.progress++;if(a==='primary')counts.primary++;if(a==='secondary')counts.secondary++;if(a==='protocol')counts.protocol++;} el('stat-total').textContent=candidates.length;for(const key of ['complete','progress','primary','secondary','protocol'])el(`stat-${key}`).textContent=counts[key]; }
    function updateAll(){const checker=stage()==='checker';el('stage-label').textContent=checker?'Checker stage:':'Primary stage:';el('stage-help').textContent=checker?'Review the locked primary assessment and record agreement or a proposed final revision. Primary answers are never overwritten.':'Review the editable AI starting values and export the completed primary record before the visible-answer checker stage. This is an exploratory tool; the final report must retain an appropriate disclaimer.';el('stat-complete-label').textContent=checker?'Second-person checks complete':'Primary reviews complete';updateStats();applyFilters();}
    function snapshot(){return {...state,exportedAt:new Date().toISOString()};}
    function download(name,content,type){const url=URL.createObjectURL(new Blob([content],{type})),link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
    function requireReviewer(){if(!state){alert('Create or load a reviewer first.');return false;}return true;}
    function csvCell(value){const s=String(value??'');return /[\",\n]/.test(s)?`\"${s.replaceAll('\"','\"\"')}\"`:s;}
    el('activate-reviewer').addEventListener('click',()=>activateReviewer(el('reviewer-id').value,el('reviewer-name').value));
    el('reviewer-name').addEventListener('change',()=>{if(!state)return;const name=el('reviewer-name').value.trim();if(stage()==='checker'){state.checker.name=name;el('active-reviewer').textContent=`Active checker: ${state.checker.id}${name?' · '+name:''} · primary: ${state.primary.reviewer.id}`;}else{state.reviewer.name=name;el('active-reviewer').textContent=`Active primary reviewer: ${state.reviewer.id}${name?' · '+name:''}`;}saveState();});
    document.addEventListener('input',event=>{const t=event.target;if(t.dataset?.field)updateRecord(t.dataset.key,t.dataset.field,t.value);});
    document.addEventListener('change',event=>{const t=event.target;if(t.dataset?.field)updateRecord(t.dataset.key,t.dataset.field,t.value);});
    document.addEventListener('input',event=>{const t=event.target;if(t.dataset?.checkField)updateCheckField(t.dataset.key,t.dataset.checkField,t.value);});
    document.addEventListener('change',event=>{const t=event.target;if(t.dataset?.checkField)updateCheckField(t.dataset.key,t.dataset.checkField,t.value);});
    document.addEventListener('click',event=>{const b=event.target.closest('[data-action]');if(!b)return;if(b.dataset.action==='complete')completeReview(b.dataset.key);if(b.dataset.action==='reopen')reopenReview(b.dataset.key);if(b.dataset.action==='reset-primary')resetToPrimary(b.dataset.key);});
    for(const id of ['search','progress-filter','relationship-filter','domain-filter','analysis-filter'])el(id).addEventListener(id==='search'?'input':'change',applyFilters);
    el('expand-visible').addEventListener('click',()=>document.querySelectorAll('details:not([hidden])').forEach(d=>d.open=true)); el('collapse-all').addEventListener('click',()=>document.querySelectorAll('details.group,details.candidate').forEach(d=>d.open=false));
    el('next-incomplete').addEventListener('click',()=>{const item=[...document.querySelectorAll('[data-candidate-key]')].find(i=>!i.hidden&&progressFor(candidates.find(c=>c.key===i.dataset.candidateKey))!=='complete');if(!item)return alert('No visible incomplete candidates.');let p=item.parentElement;while(p){if(p.tagName==='DETAILS')p.open=true;p=p.parentElement;}item.querySelector('details.candidate').open=true;item.scrollIntoView({behavior:'smooth',block:'center'});});
    function identity(){return stage()==='checker'?`${state.primary.reviewer.id}-checked-by-${state.checker.id}`:state.reviewer.id;}
    el('export-json').addEventListener('click',()=>{if(!requireReviewer())return;download(`flag-review-${VERSION}-${dataset.years[0]}-${identity()}-${new Date().toISOString().slice(0,10)}.json`,JSON.stringify(snapshot(),null,2),'application/json');});
    el('export-csv').addEventListener('click',()=>{if(!requireReviewer())return;const fields=Object.keys(defaultRecord(candidates[0])),base=['year','package','candidate_id','candidate_key','primary_relationship','relations','original_category','subtype','ai_initial_disposition','suggested_domain'];let headers,rows;if(stage()==='checker'){headers=[...base,'primary_reviewer_id','checker_id','check_status','checker_comment','check_complete',...fields.map(f=>`primary_${f}`),...fields.map(f=>`final_${f}`),'derived_analysis_label'];rows=candidates.map(c=>{const p=primaryRecordFor(c),r=recordFor(c),ch=checkFor(c)||{};return [c.year,c.package,c.id,c.key,c.primary,c.relations.join('|'),c.category,c.subtype,c.aiInitialAssessment.disposition,c.suggestedDomain,state.primary.reviewer.id,state.checker.id,ch.checkStatus||'pending',ch.checkerComment||'',Boolean(ch.checkComplete),...fields.map(f=>p[f]),...fields.map(f=>r[f]),analysisFor(c,r)].map(csvCell).join(',');});}else{headers=[...base,'reviewer_id','reviewer_name',...fields,'derived_analysis_label'];rows=candidates.map(c=>{const r=recordFor(c);return [c.year,c.package,c.id,c.key,c.primary,c.relations.join('|'),c.category,c.subtype,c.aiInitialAssessment.disposition,c.suggestedDomain,state.reviewer.id,state.reviewer.name,...fields.map(f=>r[f]),analysisFor(c,r)].map(csvCell).join(',');});}download(`flag-review-${VERSION}-${dataset.years[0]}-${identity()}.csv`,[headers.join(','),...rows].join('\n'),'text/csv;charset=utf-8');});
    el('download-html').addEventListener('click',()=>{if(!requireReviewer())return;const clone=document.documentElement.cloneNode(true),target=clone.querySelector('#embedded-review-state');target.dataset.state=encodeState(snapshot());download(`candidate-flag-review-${VERSION}-${dataset.years[0]}-${identity()}-annotated.html`,'<!doctype html>\n'+clone.outerHTML,'text/html;charset=utf-8');});
    function primaryFromChecker(value){return {schemaVersion:SCHEMA,reviewVersion:VERSION,sourceDigest:dataset.sourceDigest,year:dataset.years[0],stage:'primary',reviewer:value.primary.reviewer,reviews:value.primary.reviews,exportedAt:value.primary.exportedAt||''};}
    function primaryFromAIInitial(value,id,name){const now=new Date().toISOString(),reviews={};for(const c of candidates){const initial=value.assessments[c.key]||{},domain=Object.hasOwn(domainLabels,initial.domain)?initial.domain:c.suggestedDomain;reviews[c.key]={...defaultRecord(c),disposition:initial.disposition||c.aiInitialAssessment.disposition,domain,reviewComplete:false,updatedAt:now};}return {schemaVersion:SCHEMA,reviewVersion:VERSION,sourceDigest:dataset.sourceDigest,year:dataset.years[0],stage:'primary',reviewer:{id,name},reviews};}
    el('import-json').addEventListener('change',async event=>{const file=event.target.files[0];if(!file)return;try{const incoming=JSON.parse(await file.text()),enteredId=normalizeId(el('reviewer-id').value),enteredName=el('reviewer-name').value.trim();if(validAIInitial(incoming)){if(!enteredId)throw new Error('Enter a reviewer ID before importing an AI initial-state JSON.');activateReviewer(enteredId,enteredName,primaryFromAIInitial(incoming,enteredId,enteredName));}else if(validPrimary(incoming)){if(enteredId&&enteredId!==incoming.reviewer.id){if(!primaryComplete(incoming))throw new Error('A different reviewer ID can enter checker stage only from a completed primary snapshot.');activateChecker(incoming,enteredId,enteredName);}else{activateReviewer(incoming.reviewer.id,incoming.reviewer.name||enteredName,incoming);}}else if(validChecker(incoming)){activateChecker(primaryFromChecker(incoming),incoming.checker.id,incoming.checker.name||'',incoming);}else{throw new Error('The JSON must be a matching AI initial state, primary snapshot, or checker snapshot for this year.');}}catch(error){alert(`Could not import JSON: ${error.message}`);}finally{event.target.value='';}});
    if(bundledSecondaryTest){el('load-secondary-test').hidden=false;el('load-secondary-test').addEventListener('click',()=>{if(!validPrimary(bundledSecondaryTest))return alert('The bundled test snapshot is invalid. Rebuild this HTML.');activateChecker(bundledSecondaryTest,el('reviewer-id').value,el('reviewer-name').value);});}
    el('print').addEventListener('click',()=>{document.querySelectorAll('details.group,details.candidate,.evidence-box,.coding-box').forEach(d=>d.open=true);window.print();});
    renderGroups(); updateAll();
    let initial=null;if(validSnapshot(embedded))initial=embedded;else{try{const key=localStorage.getItem(`${STORAGE_PREFIX}::last-state-key`);if(key){const local=JSON.parse(localStorage.getItem(key)||'null');if(validSnapshot(local))initial=local;}}catch(_){}}
    if(validPrimary(initial))activateReviewer(initial.reviewer.id,initial.reviewer.name||'',initial);else if(validChecker(initial))activateChecker(primaryFromChecker(initial),initial.checker.id,initial.checker.name||'',initial);
  })();
  </script>
</body></html>'''


def validate_base(rows: list[dict[str, object]]) -> None:
    if len(rows) != 412:
        raise RuntimeError(f"Expected 412 candidates, found {len(rows)}")
    keys = [str(row["key"]) for row in rows]
    if len(keys) != len(set(keys)):
        raise RuntimeError("Candidate keys are not unique")
    year_counts = Counter(str(row["year"]) for row in rows)
    if dict(year_counts) != EXPECTED_YEAR_COUNTS:
        raise RuntimeError(f"Unexpected year counts: {dict(year_counts)}")
    primary_counts = Counter(str(row["primary"]) for row in rows)
    if dict(primary_counts) != EXPECTED_PRIMARY_COUNTS:
        raise RuntimeError(f"Unexpected primary counts: {dict(primary_counts)}")
    missing = [str(row["reportPath"]) for row in rows if not (ROOT / str(row["reportPath"])).is_file()]
    if missing:
        raise RuntimeError(f"Missing report paths: {missing[:5]}")


def validate_local_links(rows: list[dict[str, object]]) -> int:
    checked = 0
    missing: list[str] = []
    for row in rows:
        links = [str(row["reportHref"])]
        links.extend(str(link["href"]) for link in row["sourceLinks"])
        links.extend(str(link["href"]) for link in row["evidencePaths"])
        for href in links:
            if not href or re.match(r"^[a-z]+://", href, flags=re.IGNORECASE):
                continue
            target = (OUT_DIR / unquote(href.split("#", 1)[0])).resolve()
            checked += 1
            if not target.is_file():
                missing.append(f"{row['key']}: {href}")
    if missing:
        raise RuntimeError("Missing local link targets:\n" + "\n".join(missing[:20]))
    return checked


def validate_portable_locations(rows: list[dict[str, object]]) -> None:
    serialized = json.dumps(rows, ensure_ascii=False)
    forbidden = ("/home/", "file://", "ai-paper-results/")
    found = [value for value in forbidden if value in serialized]
    if found:
        raise RuntimeError(f"Non-portable location markers remain: {found}")
    allowed_prefixes = tuple(f"../../{year}/" for year in YEARS)
    for row in rows:
        if not str(row.get("reportPath", "")).startswith(f"{row['year']}/"):
            raise RuntimeError(f"Non-portable reportPath for {row['key']}")
        links = [str(row["reportHref"])]
        links.extend(str(link["href"]) for link in row["sourceLinks"])
        links.extend(str(link["href"]) for link in row["evidencePaths"])
        for href in links:
            if re.match(r"^[a-z]+://", href, flags=re.IGNORECASE):
                continue
            if not href.startswith(allowed_prefixes):
                raise RuntimeError(f"Unexpected relative link for {row['key']}: {href}")


def assessment_record(
    row: dict[str, object], disposition: str, updated_at: str
) -> dict[str, object]:
    return {
        "disposition": disposition,
        "domain": row["suggestedDomain"],
        "relatedClusterId": "",
        "statisticalErrorStatus": "pending",
        "substantiveStatus": "pending",
        "downstreamImpact": "pending",
        "internalStatus": "pending",
        "documentationStatus": "pending",
        "justificationStatus": "pending",
        "protocolInterpretation": "pending",
        "notes": "",
        "reviewComplete": disposition == "discuss",
        "updatedAt": updated_at,
    }


def write_ai_initial_state(
    year: str, rows: list[dict[str, object]], source_digest: str, meta_digest: str
) -> Path:
    payload = {
        "schemaVersion": 1,
        "targetReviewVersion": VERSION,
        "year": year,
        "sourceDigest": source_digest,
        "metaReportSource": META_RESULTS_RELATIVE.as_posix(),
        "metaReportDigest": meta_digest,
        "assessments": {
            str(row["key"]): row["aiInitialAssessment"] for row in rows
        },
    }
    output = OUT_DIR / f"ai_initial_state_v_2_0_4_{year}.json"
    output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return output


def secondary_test_snapshot(
    rows: list[dict[str, object]], source_digest: str, built_iso: str
) -> dict[str, object]:
    return {
        "schemaVersion": SCHEMA_VERSION,
        "reviewVersion": VERSION,
        "sourceDigest": source_digest,
        "year": "2018",
        "stage": "primary",
        "reviewer": TEST_REVIEWER,
        "reviews": {
            str(row["key"]): assessment_record(row, "discuss", built_iso)
            for row in rows
        },
        "exportedAt": built_iso,
        "testPurpose": "Completed primary snapshot for testing the secondary checker stage; every candidate disposition is Needs discussion.",
    }


def write_secondary_test_snapshot(payload: dict[str, object]) -> Path:
    output = OUT_DIR / (
        "secondary_stage_test_primary_v_2_0_4_2018_all_needs_discussion.json"
    )
    output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return output


def main() -> None:
    rows, base_digest = read_base_candidates()
    validate_base(rows)
    meta_results, meta_digest = read_meta_results()
    if set(meta_results) != {str(row["key"]) for row in rows}:
        raise RuntimeError("Meta-report and v.2.0.3 candidate key sets do not match")
    normalized_rows = [normalize_candidate(row, meta_results[str(row["key"])]) for row in rows]
    validate_portable_locations(normalized_rows)
    effective_primary_counts = Counter(str(row["primary"]) for row in normalized_rows)
    if dict(effective_primary_counts) != EXPECTED_PRIMARY_COUNTS:
        raise RuntimeError(f"Unexpected v.2.0.4 relationship counts: {dict(effective_primary_counts)}")
    ai_disposition_counts = Counter(
        str(row["aiInitialAssessment"]["disposition"]) for row in normalized_rows
    )
    if dict(ai_disposition_counts) != EXPECTED_AI_DISPOSITIONS:
        raise RuntimeError(
            f"Unexpected AI starting dispositions: {dict(ai_disposition_counts)}"
        )
    built_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    built_iso = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    validation_lines = [
        "# V.2.0.4 build validation",
        "",
        f"- Build time: {built_at}",
        f"- Direct candidate base: `{BASE_DIR.relative_to(ROOT)}` frozen v.2.0.3 annual HTML payloads",
        f"- Base candidate SHA256: `{base_digest}`",
        f"- Meta-report results used only for editable AI starting assessments: `{META_RESULTS_RELATIVE}`",
        f"- Meta-report result SHA256: `{meta_digest}`",
        "- Candidate extraction from meta-report/reclassification JSON: none",
        "- Candidate keys: 412 unique keys",
        "- Relationship counts: " + ", ".join(f"{k}={v}" for k, v in EXPECTED_PRIMARY_COUNTS.items()),
        "- AI starting dispositions: " + ", ".join(f"{k}={v}" for k, v in EXPECTED_AI_DISPOSITIONS.items()),
        "- Referenced final-report paths: all present",
        "- Local document locations: portable relative links rooted at ../../YEAR/",
        "- Embedded candidate JSON: parsed and reconciled for every output",
        "- Unified JSON import recognizes AI initial-state, primary, and checker records",
        "- Two-stage workflow markers: primary, checker, locked primary, proposed final, reset action, and bundled 2018 test entry present",
        "- Removed review fields: flag verification, duplicate status/key, potential consequence, evidence checked, and primary rationale",
        "- Review schema: 7 (v.2.0.4 snapshots only; no automatic migration from earlier versions)",
        "",
        "| Year | Papers | Candidates | Output |",
        "|---|---:|---:|---|",
    ]
    checked_links = 0
    test_snapshot: Path | None = None
    bundled_test: dict[str, object] | None = None
    for year in YEARS:
        year_rows = [row for row in normalized_rows if str(row["year"]) == year]
        year_primary_counts = Counter(str(row["primary"]) for row in year_rows)
        unexpected_relationships = set(year_primary_counts) - set(EXPECTED_PRIMARY_COUNTS)
        if unexpected_relationships:
            raise RuntimeError(f"Unmerged relationships remain for {year}: {sorted(unexpected_relationships)}")
        checked_links += validate_local_links(year_rows)
        digest = hashlib.sha256(json.dumps(year_rows, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
        payload = {"schemaVersion": SCHEMA_VERSION, "reviewVersion": VERSION, "sourceDigest": digest, "baseReviewVersion": BASE_VERSION, "baseCandidateDigest": base_digest, "years": [year], "keySet": [row["key"] for row in year_rows], "candidates": year_rows}
        if year == "2018":
            bundled_test = secondary_test_snapshot(year_rows, digest, built_iso)
            payload["secondaryTestSnapshot"] = bundled_test
            test_snapshot = write_secondary_test_snapshot(bundled_test)
        ai_state_output = write_ai_initial_state(year, year_rows, digest, meta_digest)
        data_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
        package_count = len({str(row["package"]) for row in year_rows})
        rendered = (HTML_TEMPLATE.replace("__YEAR__", year).replace("__GENERATED__", built_at).replace("__PACKAGES__", str(package_count)).replace("__TOTAL__", str(len(year_rows))).replace("__DIGEST_SHORT__", digest[:12]).replace("__DATA_JSON__", data_json))
        output = OUT_DIR / f"candidate_flag_review_v_2_0_4_{year}.html"
        output.write_text(rendered, encoding="utf-8")
        check = output.read_text(encoding="utf-8")
        required_markers = [
            "Version v.2.0.4",
            f'"sourceDigest":"{digest}"',
            "Import / resume v.2.0.4 JSON",
            "Load bundled 2018 checker test",
            "Locked primary assessment",
            "Checker-proposed final assessment",
            "Reset proposed final to primary",
            "checkStatus",
            "out_of_scope",
            "AI starting assessment from the meta report",
            "const VERSION = 'v.2.0.4', SCHEMA = 7",
        ]
        missing_markers = [marker for marker in required_markers if marker not in check]
        if missing_markers:
            raise RuntimeError(f"Generated marker validation failed for {output}: {missing_markers}")
        embedded_match = re.search(
            r'<script id="candidate-data" type="application/json">(.*?)</script>',
            check,
            flags=re.DOTALL,
        )
        if not embedded_match:
            raise RuntimeError(f"Embedded candidate JSON not found: {output}")
        embedded_payload = json.loads(embedded_match.group(1))
        if embedded_payload["keySet"] != [row["key"] for row in year_rows]:
            raise RuntimeError(f"Embedded candidate keys do not reconcile: {output}")
        if year == "2018":
            if embedded_payload.get("secondaryTestSnapshot") != bundled_test:
                raise RuntimeError("2018 bundled test snapshot does not reconcile")
        elif "secondaryTestSnapshot" in embedded_payload:
            raise RuntimeError(f"Unexpected bundled test snapshot in {year} HTML")
        forbidden_markers = ["Flag verification", "Duplicate status", "Exact duplicate of candidate key", "Potential consequence", "Evidence personally checked", "Primary assessment rationale", "href=\"/home/", "file://"]
        present_forbidden = [marker for marker in forbidden_markers if marker in check]
        if present_forbidden:
            raise RuntimeError(f"Removed/non-portable markers remain in {output}: {present_forbidden}")
        validation_lines.append(f"| {year} | {package_count} | {len(year_rows)} | `{output.name}`; `{ai_state_output.name}` |")
        print(f"Wrote {output.relative_to(ROOT)}: {package_count} papers, {len(year_rows)} candidates, {digest[:12]}")
    if test_snapshot is None or bundled_test is None:
        raise RuntimeError("2018 secondary-stage test snapshot was not generated")
    test_payload = json.loads(test_snapshot.read_text(encoding="utf-8"))
    if test_payload != bundled_test:
        raise RuntimeError("Separate and bundled 2018 test snapshots differ")
    if len(test_payload["reviews"]) != EXPECTED_YEAR_COUNTS["2018"]:
        raise RuntimeError("2018 secondary-stage test snapshot has the wrong review count")
    if test_payload.get("reviewer") != TEST_REVIEWER:
        raise RuntimeError("2018 secondary-stage test reviewer identity is wrong")
    if not all(
        record.get("disposition") == "discuss" and record.get("reviewComplete") is True
        for record in test_payload["reviews"].values()
    ):
        raise RuntimeError("2018 secondary-stage test records are not all complete Needs discussion records")
    validation_lines.extend([
        "",
        f"Local report/evidence/source links checked: {checked_links}",
        f"Secondary-stage test snapshot: `{test_snapshot.name}`; reviewer `tester` / `Workflow Tester`; 119/119 complete and Needs discussion",
        "",
        "Result: **PASS**",
        "",
    ])
    (OUT_DIR / "VALIDATION.md").write_text("\n".join(validation_lines), encoding="utf-8")


if __name__ == "__main__":
    main()
